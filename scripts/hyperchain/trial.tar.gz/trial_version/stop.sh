#!/usr/bin/env bash

# shellcheck disable=SC1091
source script/function/function.sh


for f in docker/*; do
  docker-compose -f "$f"/docker-compose-production.yaml down
done

if [[ -f ./script/flato/prepare/docker-compose-production.yaml ]]; then
  docker-compose -f ./script/flato/prepare/docker-compose-production.yaml down
fi

print_green "删除docker内部网路"
docker network rm blocface-network

sudo rm -rf docker/baas-go/core/issuer
sudo rm -rf docker/baas-go/core/licensedata
sudo rm -rf docker/baas-go/core/verifier
sudo rm -rf values.toml

echo
echo " _____   _   _   ____   "
echo "| ____| | \ | | |  _ \  "
echo "|  _|   |  \| | | | | | "
echo "| |___  | |\  | | |_| | "
echo "|_____| |_| \_| |____/  "
echo
exit 0

