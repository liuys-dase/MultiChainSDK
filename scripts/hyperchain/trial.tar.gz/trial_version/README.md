## 免费试用版部署手册

### 1.  准备工作

1. 请确保部署主机的Docker版本v 19.03及以上；
2. 请确保部署主机的Docker-compose版本 v1.27.4及以上；
3. 请确保部署主机安装了Python、pip3。

### 2. 正式部署

**步骤一：解压安装包**

安装包名称为 trial.tar.gz。解压完成后将生成Lite文件夹，执行以下命令进入安装目录：

```
cd trial_version
```

**步骤二：下载依赖**

```
# 使用pip或pip3安装对应依赖，如果pip下载失败，请尝试使用pip3进行重试
pip install -i https://mirrors.aliyun.com/pypi/simple/ -r requirements.txt 

```

**步骤三：确认配置**

```
vi conf/values.toml

# 配置项说明
[global]
user = "hyperchain"  	# 安装用户
network = "en0"     	# 网卡配置en0（见下文具体描述）

[console]
port = 30080         	# 系统外部访问端口

# 区块链服务端口配置(配置SDK使用需要)
[flato]
enable=true 			# 是否自动部署flato节点

[flato.node1]
jsonport=43221			# 节点1的访问端口

[flato.node2]
jsonport=43222			# 节点2的访问端口

[flato.node3]
jsonport=43223			# 节点3的访问端口

[flato.node4]
jsonport=43224			# 节点4的访问端口

```

通过`ifconfig`查看当前本机的网卡，选择一张合适的网卡。

```
ifconfig
lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 16384

        options=1203<RXCSUM,TXCSUM,TXSTATUS,SW_TIMESTAMP>

        inet 127.0.0.1 netmask 0xff000000 

        inet6 ::1 prefixlen 128 

en0: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500

        options=400<CHANNEL_IO>

        ether 38:f9:d3:cd:a6:fc 

        inet6 fe80::1cf2:b244:cdff:eb38%en0 prefixlen 64 secured scopeid 0x4 

        inet 10.1.43.232 netmask 0xfffffc00 broadcast 10.1.43.255
```

**步骤四：启动部署**

```
# 启动，等待系统部署完成
./start.sh 
```

### 3. 系统启动

打开浏览器，访问服务器外部IP地址:系统外部访问端口（第二章步骤三中可配置）

打开系统后，参考《使用手册》

### 4. 卸载

```
# 停止组件并且清理数据
./stop.sh 
```
