#!/usr/bin/env bash

docker-compose -f docker-compose-production.yaml down