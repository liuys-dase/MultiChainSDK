#!/usr/bin/env bash

rm -rf data/*
rm -rf data/.user_scripts_initialized
