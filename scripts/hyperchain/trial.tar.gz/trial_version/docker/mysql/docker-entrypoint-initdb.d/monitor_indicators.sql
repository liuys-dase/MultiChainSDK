/*
 Navicat Premium Data Transfer

 Source Server         : test
 Source Server Type    : MySQL
 Source Server Version : 50731
 Source Host           : 172.16.1.121:32388
 Source Schema         : stdb

 Target Server Type    : MySQL
 Target Server Version : 50731
 File Encoding         : 65001

 Date: 29/01/2021 18:43:34
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for monitor_indicators
-- ----------------------------
DROP TABLE IF EXISTS `stdb`.`monitor_indicators`;
CREATE TABLE `stdb`.`monitor_indicators` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `indicator` varchar(4096) DEFAULT NULL,
  `monitor_type` varchar(255) DEFAULT NULL,
  `options_str` varchar(255) DEFAULT NULL,
  `prometheus_sql` varchar(4096) DEFAULT NULL,
  `target_condition` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of monitor_indicators
-- ----------------------------
BEGIN;
INSERT INTO `stdb`.`monitor_indicators` VALUES (1, '区块数', 'CHAIN_NODE', '[\"ChainId\"]', 'chainctl_chainmonitor_block_info{BlockInfo=\"blockLatestNum\",ChainId=\"$ChainId\"}', 'VB', '个');
INSERT INTO `stdb`.`monitor_indicators` VALUES (2, '交易数', 'CHAIN_NODE', '[\"ChainId\"]', 'chainctl_chainmonitor_tx_info{TxInfo=\"valid\",ChainId=\"$ChainId\"}+ignoring(TxInfo)chainctl_chainmonitor_tx_info{TxInfo=\"invalid\",ChainId=\"$ChainId\"}', 'VB', '个');
INSERT INTO `stdb`.`monitor_indicators` VALUES (3, '区块TPS', 'CHAIN_NODE', '[\"ChainId\"]', 'chainctl_chainmonitor_tps_info{ChainId=\"$ChainId\",TPSInfo=\"hpcBlockPerSec\"}', 'VB', 'TPS');
INSERT INTO `stdb`.`monitor_indicators` VALUES (4, '交易TPS', 'CHAIN_NODE', '[\"ChainId\"]', 'chainctl_chainmonitor_tps_info{ChainId=\"$ChainId\",TPSInfo=\"hpcTPS\"}', 'VB', 'TPS');
INSERT INTO `stdb`.`monitor_indicators` VALUES (5, '块平均处理时间', 'CHAIN_NODE', '[\"ChainId\"]', 'chainctl_chainmonitor_block_info{ChainId=\"$ChainId\",BlockInfo=\"blockAvgGenerateTime\"}', 'VB', 'ms');
INSERT INTO `stdb`.`monitor_indicators` VALUES (6, 'CPU占用率', 'CHAIN_NODE', '[\"NodeId\"]', 'hostagent_process_cpu_info{ProcessCPUInfo=\"used\",NodeId=\"$NodeId\"}/100', 'VB', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (7, 'CPU空闲率', 'CHAIN_NODE', '[\"NodeId\"]', '1-hostagent_process_cpu_info{ProcessCPUInfo=\"used\",NodeId=\"$NodeId\"}/100', 'VB', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (8, '内存占用率', 'CHAIN_NODE', '[\"NodeId\"]', 'hostagent_host_process_memory{ProcessMemInfo=\"usedPer\",NodeId=\"$NodeId\"}/100', 'VB', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (9, '内存使用量', 'CHAIN_NODE', '[\"NodeId\"]', 'hostagent_host_process_memory{ProcessMemInfo=\"used\",NodeId=\"$NodeId\"}/1024/1024/1024', 'VB', 'GB');
INSERT INTO `stdb`.`monitor_indicators` VALUES (10, '磁盘使用量', 'CHAIN_NODE', '[\"NodeId\"]', 'hostagent_host_process_storage{ProcessStorage=\"used\",NodeId=\"$NodeId\"}/1024/1024', 'VB', 'GB');
INSERT INTO `stdb`.`monitor_indicators` VALUES (11, '磁盘使用率', 'CHAIN_NODE', '[\"NodeId\"]', 'hostagent_host_process_storage{ProcessStorage=\"used\",NodeId=\"$NodeId\"} *1024/ignoring(ProcessStorage)hostagent_host_process_storage{ProcessStorage=\"total\",NodeId=\"$NodeId\"}', 'VB', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (14, '区块数', 'CHAIN_NODE', '[\"ChainId\"]', 'chainctl_chainmonitor_block_info{BlockInfo=\"blockLatestNum\",ChainId=\"$ChainId\"}', 'K8S', '个');
INSERT INTO `stdb`.`monitor_indicators` VALUES (15, '交易数', 'CHAIN_NODE', '[\"ChainId\"]', 'chainctl_chainmonitor_tx_info{TxInfo=\"valid\",ChainId=\"$ChainId\"}+ignoring(TxInfo)chainctl_chainmonitor_tx_info{TxInfo=\"invalid\",ChainId=\"$ChainId\"}', 'K8S', '个');
INSERT INTO `stdb`.`monitor_indicators` VALUES (16, '区块TPS', '', '[\"ChainId\"]', 'chainctl_chainmonitor_tps_info{ChainId=\"$ChainId\",TPSInfo=\"hpcBlockPerSec\"}', 'K8S', 'TPS');
INSERT INTO `stdb`.`monitor_indicators` VALUES (17, '交易TPS', 'CHAIN_NODE', '[\"ChainId\"]', 'chainctl_chainmonitor_tps_info{ChainId=\"$ChainId\",TPSInfo=\"hpcTPS\"}', 'K8S', 'TPS');
INSERT INTO `stdb`.`monitor_indicators` VALUES (18, '块平均处理时间', '', '[\"ChainId\"]', 'chainctl_chainmonitor_block_info{ChainId=\"$ChainId\",BlockInfo=\"blockAvgGenerateTime\"}', 'K8S', 'ms');
INSERT INTO `stdb`.`monitor_indicators` VALUES (19, 'CPU占用率', 'CHAIN_NODE', '[\"ChainId\",\"NodeId\"]', 'hostagent_k8s_chain_pod_info{Usage=\"cpu\",NodeId=\"$NodeId\",ChainId=\"$ChainId\"}/scalar(sum(hostagent_k8s_all_chain_pod_container_limit_info{Resources=\"cpuLimit\",NodeId=\"$NodeId\",ChainId=\"$ChainId\"}))', 'K8S', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (20, 'CPU空闲率', 'CHAIN_NODE', '[\"ChainId\",\"NodeId\"]', '1-hostagent_k8s_chain_pod_info{Usage=\"cpu\",NodeId=\"$NodeId\",ChainId=\"$ChainId\"}/scalar(sum(hostagent_k8s_all_chain_pod_container_limit_info{Resources=\"cpuLimit\",NodeId=\"$NodeId\",ChainId=\"$ChainId\"}))', 'K8S', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (21, '内存占用率', 'CHAIN_NODE', '[\"ChainId\",\"NodeId\"]', 'hostagent_k8s_chain_pod_info{Usage=\"mem\",NodeId=\"$NodeId\",ChainId=\"$ChainId\"}/scalar(sum(hostagent_k8s_all_chain_pod_container_limit_info{Resources=\"memLimit\",NodeId=\"$NodeId\",ChainId=\"$ChainId\"}))', 'K8S', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (22, '内存使用量', 'CHAIN_NODE', '[\"ChainId\",\"NodeId\"]', '1-hostagent_k8s_chain_pod_info{Usage=\"mem\",NodeId=\"$NodeId\",ChainId=\"$ChainId\"}/scalar(sum(hostagent_k8s_all_chain_pod_container_limit_info{Resources=\"memLimit\",NodeId=\"$NodeId\",ChainId=\"$ChainId\"}))', 'K8S', 'GB');
INSERT INTO `stdb`.`monitor_indicators` VALUES (23, '系统运行时间', 'INSTANCE_SELF', '[\"machineID\"]', 'hostagent_host_uptime{machineID=\"$machineID\",UpInfo=\"upTime\"}/3600/24', 'VB', '天');
INSERT INTO `stdb`.`monitor_indicators` VALUES (24, 'CPU占用率', 'INSTANCE_SELF', '[\"machineID\"]', '(avg by (machineID)(irate(hostagent_host_cpu_seconds_total{CpuMode=\"system\",machineID=\"$machineID\"}[5m]))) +ignoring(CpuMode)(avg by (machineID)(irate(hostagent_host_cpu_seconds_total{CpuMode=\"user\",machineID=\"$machineID\"}[5m])) )+ignoring(CpuMode)(avg by (machineID)(irate(hostagent_host_cpu_seconds_total{CpuMode=\"iowait\",machineID=\"$machineID\"}[5m])) )+ignoring(CpuMode)(avg by (machineID)(irate(hostagent_host_cpu_seconds_total{CpuMode=\"irq\" ,machineID=\"$machineID\"}[5m])) )+ignoring(CpuMode)(avg by (machineID)(irate(hostagent_host_cpu_seconds_total{CpuMode=\"softirq\",machineID=\"$machineID\"}[5m]))) +ignoring(CpuMode)(avg by (machineID)(irate(hostagent_host_cpu_seconds_total{CpuMode=\"nice\",machineID=\"$machineID\"}[5m])) )+ignoring(CpuMode)(avg by (machineID)(irate(hostagent_host_cpu_seconds_total{CpuMode=\"steal\",machineID=\"$machineID\"}[5m]))) +ignoring(CpuMode)(avg by (machineID)(irate(hostagent_host_cpu_seconds_total{CpuMode=\"guest\",machineID=\"$machineID\"}[5m])))', 'VB', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (25, 'CPU空闲率', 'INSTANCE_SELF', '[\"machineID\"]', '1-((avg by (machineID)(irate(hostagent_host_cpu_seconds_total{CpuMode=\"system\",machineID=\"$machineID\"}[5m]))) +ignoring(CpuMode)(avg by (machineID)(irate(hostagent_host_cpu_seconds_total{CpuMode=\"user\",machineID=\"$machineID\"}[5m])) )+ignoring(CpuMode)(avg by (machineID)(irate(hostagent_host_cpu_seconds_total{CpuMode=\"iowait\",machineID=\"$machineID\"}[5m])) )+ignoring(CpuMode)(avg by (machineID)(irate(hostagent_host_cpu_seconds_total{CpuMode=\"irq\",machineID=\"$machineID\"}[5m])))+ignoring(CpuMode)(avg by (machineID)(irate(hostagent_host_cpu_seconds_total{CpuMode=\"softirq\",machineID=\"$machineID\"}[5m]))) +ignoring(CpuMode)(avg by (machineID)(irate(hostagent_host_cpu_seconds_total{CpuMode=\"nice\",machineID=\"$machineID\"}[5m])))+ignoring(CpuMode)(avg by (machineID)(irate(hostagent_host_cpu_seconds_total{CpuMode=\"steal\",machineID=\"$machineID\"}[5m]))) +ignoring(CpuMode)(avg by (machineID)(irate(hostagent_host_cpu_seconds_total{CpuMode=\"guest\",machineID=\"$machineID\"}[5m]))))', 'VB', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (26, '内存占用率', 'INSTANCE_SELF', '[\"machineID\"]', 'hostagent_host_memory{Mem=\"usedPercent\",machineID=\"$machineID\"}/100', 'VB', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (27, '内存使用量', 'INSTANCE_SELF', '[\"machineID\"]', 'hostagent_host_memory{Mem=\"used\",machineID=\"$machineID\"}/1024/1024/1024', 'VB', 'GB');
INSERT INTO `stdb`.`monitor_indicators` VALUES (28, '内存剩余量', 'INSTANCE_SELF', '[\"machineID\"]', '(hostagent_host_memory{Mem=\"total\",machineID=\"$machineID\"}-ignoring(Mem)hostagent_host_memory{Mem=\"used\",machineID=\"$machineID\"})/1024/1024/1024', 'VB', 'GB');
INSERT INTO `stdb`.`monitor_indicators` VALUES (29, '当前打开的文件描述符', 'INSTANCE_SELF', '[\"machineID\"]', 'hostagent_host_fd{machineID=\"$machineID\",FdInfo=\"used\"}/1000', 'VB', 'k');
INSERT INTO `stdb`.`monitor_indicators` VALUES (30, '系统平均负载（1m）', 'INSTANCE_SELF', '[\"machineID\"]', 'hostagent_host_load{LoadAvg=\"1\",machineID=\"$machineID\"}', 'VB', '');
INSERT INTO `stdb`.`monitor_indicators` VALUES (31, '系统平均负载（5m）', 'INSTANCE_SELF', '[\"machineID\"]', 'hostagent_host_load{LoadAvg=\"5\",machineID=\"$machineID\"}', 'VB', '');
INSERT INTO `stdb`.`monitor_indicators` VALUES (32, '系统平均负载（15m）', 'INSTANCE_SELF', '[\"machineID\"]', 'hostagent_host_load{LoadAvg=\"15\",machineID=\"$machineID\"}', 'VB', '');
INSERT INTO `stdb`.`monitor_indicators` VALUES (33, 'cpu iowait', 'INSTANCE_SELF', '[\"machineID\"]', 'avg(irate(hostagent_host_cpu_seconds_total{CpuMode=\"iowait\",machineID=\"$machineID\"}[5m]))by (machineID)', 'VB', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (34, '磁盘总量', 'INSTANCE_SELF', '[\"machineID\"]', 'hostagent_host_disk{DiskSpace=\"total\",machineID=\"$machineID\"}/1024/1024/1024', 'VB', 'GB');
INSERT INTO `stdb`.`monitor_indicators` VALUES (35, '磁盘使用量', 'INSTANCE_SELF', '[\"machineID\"]', 'hostagent_host_disk{DiskSpace=\"used\",machineID=\"$machineID\"}/1024/1024/1024', 'VB', 'GB');
INSERT INTO `stdb`.`monitor_indicators` VALUES (36, '磁盘使用率', 'INSTANCE_SELF', '[\"machineID\"]', 'hostagent_host_disk{DiskSpace=\"used\",machineID=\"$machineID\"}/ignoring(DiskSpace)hostagent_host_disk{DiskSpace=\"total\",machineID=\"$machineID\"}', 'VB', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (37, '磁盘剩余量', 'INSTANCE_SELF', '[\"machineID\"]', '(hostagent_host_disk{DiskSpace=\"total\",machineID=\"$machineID\"}-ignoring(DiskSpace)hostagent_host_disk{DiskSpace=\"used\",machineID=\"$machineID\"})/1024/1024/1024', 'VB', 'GB');
INSERT INTO `stdb`.`monitor_indicators` VALUES (38, '每秒磁盘IO读取量', 'INSTANCE_SELF', '[\"machineID\"]', 'avg(irate(hostagent_host_disk_io{DiskIOInfo=\"readBytes\",machineID=\"$machineID\"}[5m]))by (machineID)', 'VB', 'Bytes/s');
INSERT INTO `stdb`.`monitor_indicators` VALUES (39, '每秒磁盘IO读取次数', 'INSTANCE_SELF', '[\"machineID\"]', 'avg(irate(hostagent_host_disk_io{DiskIOInfo=\"readCount\",machineID=\"$machineID\"}[5m]))by (machineID)', 'VB', '次');
INSERT INTO `stdb`.`monitor_indicators` VALUES (40, '每秒磁盘IO写入量', 'INSTANCE_SELF', '[\"machineID\"]', 'avg(irate(hostagent_host_disk_io{DiskIOInfo=\"writeBytes\",machineID=\"$machineID\"}[5m]))by (machineID)', 'VB', 'Bytes/s');
INSERT INTO `stdb`.`monitor_indicators` VALUES (41, '每秒磁盘IO写入次数', 'INSTANCE_SELF', '[\"machineID\"]', 'avg(irate(hostagent_host_disk_io{DiskIOInfo=\"writeCount\",machineID=\"$machineID\"}[5m]))by (machineID)', 'VB', '次');
INSERT INTO `stdb`.`monitor_indicators` VALUES (42, 'TCP连接数', 'INSTANCE_SELF', '[\"machineID\"]', 'hostagent_host_tcp{ConnectStatus=\"total\",machineID=\"$machineID\"}', 'VB', '个');
INSERT INTO `stdb`.`monitor_indicators` VALUES (43, 'TCP接收包速率', 'INSTANCE_SELF', '[\"machineID\"]', 'avg(irate(hostagent_host_net_info{NetInfo=\"packetRecv\",machineID=\"$machineID\"}[5m]))by (machineID) /1000', 'VB', 'Kbps');
INSERT INTO `stdb`.`monitor_indicators` VALUES (44, 'TCP发送包速率', 'INSTANCE_SELF', '[\"machineID\"]', 'avg(irate(hostagent_host_net_info{NetInfo=\"packetSent\",machineID=\"$machineID\"}[5m]))by (machineID)/1000', 'VB', 'Kbps');
INSERT INTO `stdb`.`monitor_indicators` VALUES (45, '网络速率-进', 'INSTANCE_SELF', '[\"machineID\"]', 'irate(hostagent_host_net_info{NetInfo=\"byteRecv\",machineID=\"$machineID\"}[5m])/1024*8', 'VB', 'kbps/s');
INSERT INTO `stdb`.`monitor_indicators` VALUES (46, '网络速率-出', 'INSTANCE_SELF', '[\"machineID\"]', 'irate(hostagent_host_net_info{NetInfo=\"byteSent\",machineID=\"$machineID\"}[5m])/1024*8', 'VB', 'kbps/s');
INSERT INTO `stdb`.`monitor_indicators` VALUES (47, 'CPU占用率', 'INSTANCE_PROCESS', '[\"machineID\",\"ServiceName\"]', 'hostagent_service_cpu{ServiceCPUInfo=\"used\",ServiceName=\"$ServiceName\",machineID=\"$machineID\"}/100', 'VB', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (48, '内存占用率', 'INSTANCE_PROCESS', '[\"machineID\",\"ServiceName\"]', 'hostagent_service_mem{ServiceMemInfo=\"usedPer\",ServiceName=\"$ServiceName\",machineID=\"$machineID\"}/100', 'VB', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (51, 'CPU占用率', 'INSTANCE_SELF', '[\"machineID\"]', 'sum(hostagent_k8s_all_pod_info{Usage=\"cpu\", machineID=\"$machineID\"})/sum(hostagent_k8s_all_pod_container_limit_info{Resources=\"cpuLimit\",machineID=\"$machineID\"})', 'K8S', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (52, '内存占用率', 'INSTANCE_SELF', '[\"machineID\"]', 'sum(hostagent_k8s_all_pod_info{Usage=\"mem\",machineID=\"$machineID\"})/sum(hostagent_k8s_all_pod_container_limit_info{Resources=\"memLimit\",machineID=\"$machineID\"})', 'K8S', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (53, 'CPU占用率', 'INSTANCE_PROCESS', '[\"machineID\",\"PodName\"]', 'hostagent_k8s_all_pod_info{Usage=\"cpu\",machineID=\"$machineID\",PodName=\"$PodName\"}/scalar(sum(hostagent_k8s_all_pod_container_limit_info{Resources=\"cpuLimit\",machineID=\"$machineID\",PodName=\"$PodName\"}))', 'K8S', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (54, '内存占用率', 'INSTANCE_PROCESS', '[\"machineID\",\"PodName\"]', 'hostagent_k8s_all_pod_info{Usage=\"mem\",machineID=\"$machineID\",PodName=\"$PodName\"}/scalar(sum(hostagent_k8s_all_pod_container_limit_info{Resources=\"memLimit\",machineID=\"$machineID\",PodName=\"$PodName\"}))', 'K8S', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (55, 'CPU占用率', 'REPLICATE', '[\"PodName\"]', 'hostagent_k8s_system_info{PodName=\"$PodName\",Usage=\"cpu\"}/ignoring(Usage,Resources,NameSpace)hostagent_k8s_system_service_limit_info{PodName=\"$PodName\",Resources=\"cpuLimit\"}', 'K8S', '%');
INSERT INTO `stdb`.`monitor_indicators` VALUES (56, '内存占用率', 'REPLICATE', '[\"PodName\"]', 'hostagent_k8s_system_info{PodName=\"$PodName\",Usage=\"mem\"}/ignoring(Usage,Resources,NameSpace)hostagent_k8s_system_service_limit_info{PodName=\"$PodName\",Resources=\"memLimit\"}', 'K8S', '%');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
