/*
 Navicat Premium Data Transfer

 Source Server         : stdb-dev
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : 172.16.1.121:30092
 Source Schema         : stdb

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : 65001

 Date: 30/09/2020 16:53:50
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for grade_group
-- ----------------------------
DROP TABLE IF EXISTS `stdb`.`grade_group`;
CREATE TABLE `stdb`.`grade_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sample_serials` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `rule_num` int(11) DEFAULT NULL,
  `top10rule` text COLLATE utf8_bin,
  `date` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='样本合约评分结果';

-- ----------------------------
-- Records of grade_group
-- ----------------------------
BEGIN;
INSERT INTO `stdb`.`grade_group` VALUES (1, '[1,2,3,4,5,6,7,8,9,10]', 13, '{\"0.0304\":\"S3001\",\"0.0313\":\"S3005\",\"0.0424\":\"S3002\",\"0.0433\":\"L1008\",\"0.0571\":\"L1003\",\"0.0654\":\"S3006\",\"0.0690\":\"S2007\",\"0.0847\":\"L1006\",\"0.1160\":\"S2004\",\"0.1307\":\"L1005\",\"0.1822\":\"L1002\"}', '2018-08-22 21:02:33');
INSERT INTO `stdb`.`grade_group` VALUES (2, '[1,2,3,4,5,6,7,8,9,10]', 13, '{\"0.0304\":\"S3001\",\"0.0313\":\"S3005\",\"0.0424\":\"S3002\",\"0.0433\":\"L1008\",\"0.0571\":\"L1003\",\"0.0654\":\"S3006\",\"0.0690\":\"S2007\",\"0.0847\":\"L1006\",\"0.1160\":\"S2004\",\"0.1307\":\"L1005\",\"0.1822\":\"L1002\"}', '2018-08-22 21:03:23');
INSERT INTO `stdb`.`grade_group` VALUES (3, '298-715', 6, '{\"0.0255\":\"S3005\",\"0.0387\":\"S2005\",\"0.0412\":\"S3001\",\"0.0560\":\"S3002\",\"0.0597\":\"S2007\",\"0.0806\":\"L1003\",\"0.0894\":\"S3006\",\"0.0927\":\"L1006\",\"0.1211\":\"S2004\",\"0.1467\":\"L1005\",\"0.1804\":\"L1002\"}', '2018-09-11 16:24:19');
INSERT INTO `stdb`.`grade_group` VALUES (4, '298-1303', 6, '{\"0.0261\":\"S3005\",\"0.0327\":\"S2005\",\"0.0450\":\"S3001\",\"0.0576\":\"S3002\",\"0.0620\":\"S2007\",\"0.0845\":\"L1003\",\"0.0871\":\"L1006\",\"0.0917\":\"S3006\",\"0.1217\":\"S2004\",\"0.1286\":\"L1005\",\"0.1894\":\"L1002\"}', '2018-09-13 13:10:54');
INSERT INTO `stdb`.`grade_group` VALUES (5, '298-1303', 11, '{\"0.0089\":\"S1001\",\"0.0127\":\"S3004\",\"0.0216\":\"S3003\",\"0.0219\":\"S2002\",\"0.0501\":\"S3005\",\"0.0509\":\"S1004\",\"0.0596\":\"S2005\",\"0.1175\":\"S2007\",\"0.1715\":\"S3006\",\"0.2306\":\"L1005\",\"0.2307\":\"S2004\"}', '2018-09-19 11:21:21');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
