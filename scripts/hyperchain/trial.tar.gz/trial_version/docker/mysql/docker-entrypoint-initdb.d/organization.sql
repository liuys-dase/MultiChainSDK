/*
 Navicat Premium Data Transfer

 Source Server         : stdb-dev
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : 172.16.1.121:30092
 Source Schema         : stdb

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : 65001

 Date: 30/09/2020 16:06:53
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for organization
-- ----------------------------
DROP TABLE IF EXISTS `stdb`.`organization`;
CREATE TABLE `stdb`.`organization` (
  `id` varchar(100) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `managers_json` text,
  `modify_time` datetime DEFAULT NULL,
  `name` varchar(20) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of organization
-- ----------------------------
BEGIN;
INSERT INTO `stdb`.`organization` VALUES ('ORG-cf5b157ff6814c23a3a609a4804f982d', '2020-04-28 13:30:54', '超级管理员机构，管理机构内所有成员和资源', '[{\"accountName\":\"admin01\",\"createTime\":1588132407000,\"id\":\"USER-3f23f7b2904e428ea748421872c96322\"}]', '2020-04-29 11:57:55', '超级管理员机构', 'ADMIN_ORGANIZATION', 'baas.com');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
