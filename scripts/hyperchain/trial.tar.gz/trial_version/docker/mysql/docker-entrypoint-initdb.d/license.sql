/*
 Navicat Premium Data Transfer

 Source Server         : blocface-develop
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : 172.16.1.121
 Source Database       : LICENSE

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : utf-8

 Date: 10/12/2020 12:32:26 PM
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
--  Table structure for `admin`
-- ----------------------------
DROP TABLE IF EXISTS `LICENSE`.`admin`;
CREATE TABLE `LICENSE`.`admin` (
  `Uid` bigint(20) NOT NULL,
  `email` varchar(255) NOT NULL DEFAULT '',
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `login_token` varchar(255) NOT NULL DEFAULT '',
  `last_login` datetime NOT NULL,
  PRIMARY KEY (`Uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
--  Records of `admin`
-- ----------------------------
BEGIN;
INSERT INTO `LICENSE`.`admin` VALUES ('1', 'luqiweihua@hyperchain.cn', '1', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJVSUQiOjEsIm1haWwiOiJsdXFpd2VpaHVhQGh5cGVyY2hhaW4uY24iLCJpc0FkbWluIjp0cnVlLCJleHAiOjE2MDIwNTAxMjksImlzcyI6Imh5cGVyY2hhaW4uY24iLCJuYmYiOjE2MDE0NDUzMjl9.oHfksNRQlTr6NLxjfOucYcfgjVB8BqpmcDbMUx7CNuw', '2020-09-30 13:55:30');
COMMIT;

-- ----------------------------
--  Table structure for `license`
-- ----------------------------
DROP TABLE IF EXISTS `LICENSE`.`license`;
CREATE TABLE `LICENSE`.`license` (
  `license_id` bigint(20) NOT NULL,
  `token_id` bigint(20) NOT NULL DEFAULT '0',
  `uid` varchar(255) NOT NULL DEFAULT '',
  `month` bigint(20) NOT NULL DEFAULT '0',
  `remark` longtext NOT NULL,
  `version` bigint(20) unsigned NOT NULL DEFAULT '0',
  `commercial_version` varchar(255) NOT NULL DEFAULT '',
  `create_time` datetime NOT NULL,
  `issue_time` datetime DEFAULT NULL,
  `need_issue` tinyint(1) NOT NULL DEFAULT '0',
  `pass` tinyint(1) NOT NULL DEFAULT '0',
  `end_time` date NOT NULL,
  `expired` tinyint(1) NOT NULL DEFAULT '0',
  `frozen` tinyint(1) NOT NULL DEFAULT '0',
  `frozen_admin` tinyint(1) NOT NULL DEFAULT '0',
  `to_expired` tinyint(1) NOT NULL DEFAULT '0',
  `check_online` tinyint(1) NOT NULL DEFAULT '0',
  `license` varchar(2048) NOT NULL DEFAULT '',
  `push` tinyint(1) NOT NULL DEFAULT '1',
  `extra` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`license_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
--  Table structure for `preset_user`
-- ----------------------------
DROP TABLE IF EXISTS `LICENSE`.`preset_user`;
CREATE TABLE `LICENSE`.`preset_user` (
  `mail` varchar(255) NOT NULL,
  `uid` bigint(20) NOT NULL DEFAULT '0',
  `pwd` varchar(255) NOT NULL DEFAULT '',
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mail`),
  UNIQUE KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
--  Records of `preset_user`
-- ----------------------------
BEGIN;
INSERT INTO `LICENSE`.`preset_user` VALUES ('luqiweihua@hyperchain.cn', '1', '123456', '1');
COMMIT;

-- ----------------------------
--  Table structure for `product_key_map`
-- ----------------------------
DROP TABLE IF EXISTS `LICENSE`.`product_key_map`;
CREATE TABLE `LICENSE`.`product_key_map` (
  `product_name` varchar(255) NOT NULL,
  `private_key` varchar(255) NOT NULL DEFAULT '',
  `public_key_x` varchar(255) NOT NULL DEFAULT '',
  `public_key_y` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`product_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
--  Table structure for `sign_once`
-- ----------------------------
DROP TABLE IF EXISTS `LICENSE`.`sign_once`;
CREATE TABLE `LICENSE`.`sign_once` (
  `sign` varchar(255) NOT NULL,
  `un_verify` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
--  Table structure for `tag_token_map`
-- ----------------------------
DROP TABLE IF EXISTS `LICENSE`.`tag_token_map`;
CREATE TABLE `LICENSE`.`tag_token_map` (
  `id` varchar(255) NOT NULL,
  `tag_name` varchar(255) NOT NULL DEFAULT '',
  `token_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
--  Records of `tag_token_map`
-- ----------------------------
BEGIN;
INSERT INTO `LICENSE`.`tag_token_map` VALUES ('1|blocface', 'blocface', '1'), ('1|Hyperchain', 'Hyperchain', '1'), ('1|杭州趣链科技有限公司', '杭州趣链科技有限公司', '1');
COMMIT;

-- ----------------------------
--  Table structure for `token`
-- ----------------------------
DROP TABLE IF EXISTS `LICENSE`.`token`;
CREATE TABLE `LICENSE`.`token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL DEFAULT '',
  `key_x` varchar(255) NOT NULL DEFAULT '',
  `key_y` varchar(255) NOT NULL DEFAULT '',
  `nonce` varchar(255) NOT NULL DEFAULT '',
  `creator_id` bigint(20) NOT NULL DEFAULT '0',
  `creator_email` varchar(255) NOT NULL DEFAULT '',
  `num_limit` bigint(20) NOT NULL DEFAULT '0',
  `num` bigint(20) NOT NULL DEFAULT '0',
  `time_limit` bigint(20) NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL,
  `issue_time` datetime DEFAULT NULL,
  `check_online` tinyint(1) NOT NULL DEFAULT '0',
  `threshold` bigint(20) NOT NULL DEFAULT '0',
  `owner_id` bigint(20) NOT NULL DEFAULT '0',
  `owner_email` varchar(255) NOT NULL DEFAULT '',
  `issued` tinyint(1) NOT NULL DEFAULT '0',
  `issuer_email` varchar(255) NOT NULL DEFAULT '',
  `freeze` tinyint(1) NOT NULL DEFAULT '0',
  `pass` tinyint(1) NOT NULL DEFAULT '0',
  `string` longtext NOT NULL,
  `extra` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nonce` (`nonce`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
--  Records of `token`
-- ----------------------------
BEGIN;
INSERT INTO `LICENSE`.`token` VALUES ('1', 'MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEDydiPn/sXE38c26yxVKwmvrRTlCPh33aMcVtSpo7FCIM6M6q6uD6SajFI96z0vUNE0eUQGV8ZSB3T07yIz9mdQ==', 'f27623e7fec5c4dfc736eb2c552b09afad14e508f877dda31c56d4a9a3b1422', 'ce8ceaaeae0fa49a8c523deb3d2f50d13479440657c6520774f4ef2233f6675', '4f-_GOxwOyaxUvUov2mYZE5lgM3uS-ciOwxtlN98V-2vByVChapW4sMFbKkAgXWOG4z40JeA_ozSZi4EtWP33g==', '1', 'luqiweihua@hyperchain.cn', '9223372036854775807', '142', '9223372036854775807', '2020-09-30 13:55:45', null, '0', '9223372036854775807', '0', 'luqiweihua@hyperchain.cn', '0', 'luqiweihua@hyperchain.cn', '0', '1', '测试用例', 'Hyperchain|杭州趣链科技有限公司');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
