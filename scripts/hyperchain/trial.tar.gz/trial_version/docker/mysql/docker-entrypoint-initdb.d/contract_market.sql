/*
 Navicat Premium Data Transfer

 Source Server         : stdb-dev
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : 172.16.1.121:30092
 Source Schema         : stdb

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : 65001

 Date: 30/09/2020 16:07:24
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for contract_market
-- ----------------------------
DROP TABLE IF EXISTS `stdb`.`contract_market`;
CREATE TABLE `stdb`.`contract_market` (
  `id` varchar(100) NOT NULL,
  `contract_id_list` text,
  `created_time` datetime(6) DEFAULT NULL,
  `description` text,
  `language_type` varchar(255) DEFAULT NULL,
  `modified_time` datetime(6) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `platform_type` varchar(255) DEFAULT NULL,
  `third_market_id` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of contract_market
-- ----------------------------
BEGIN;
INSERT INTO `stdb`.`contract_market` VALUES ('CONTRACT-MARKET-096e15b64b854ad9bac554d90598f9b0', '[1]', '2020-09-24 19:59:48.325000', '# 模板说明

本合约为一个写好基本架构的基础合约框架，合约代码内提供注释说明，帮助用户理解该智能合约最基本的结构，熟悉其开发流程和管理流程。

本合约为Solidity类型合约，因为合约较为基础，仅有一份sol合约文件。

# 接口描述示例

| 函数名 | 输入                       | 类型                            | 注释 |
| ------ | -------------------------- | ------------------------------- | ---- |
| query  | id                         | uint256                         |      |
| save   | id, field1, field2, field3 | uint256, bytes32, bytes, string |      |
| chmod  | userAddr, role             | address, unit8                  |      |
', 'SOLIDITY', '2020-09-24 19:59:48.325000', '合约基础框架模板', 'HYPERCHAIN', '0', '1.0');
INSERT INTO `stdb`.`contract_market` VALUES ('CONTRACT-MARKET-726729dd8b0b487abbb1c054a7156015', '[2,3,4,5,6,7]', '2020-09-24 20:00:40.134000', '# 模板说明

本合约为一个写好基本架构的基础合约框架，合约代码内提供注释说明，帮助用户理解该智能合约最基本的结构，熟悉其开发流程和管理流程。

本合约为Java类型合约，内置主合约文件，接口文件和调用文件。



# 接口描述示例

| 函数名           | 输入   | 类型 | 注释 |
| ---------------- | ------ | ---- | ---- |
| FrameworkInvoker | myData | json |      |

', 'JAVA', '2020-09-24 20:00:40.134000', '合约基础框架模板', 'HYPERCHAIN', '0', '1.0');
INSERT INTO `stdb`.`contract_market` VALUES ('CONTRACT-MARKET-8363d873e3d741f5a45266ac220de92a', '[13]', '2020-09-24 20:03:58.032000', '# 模板说明

本合约为基础合约HelloWorld，合约代码内提供注释说明，帮助用户理解该智能合约最基本的结构，熟悉其开发流程和管理流程。

本合约为Solidity类型合约，因为合约较为基础，仅有一份sol合约文件。

# 接口描述示例

| 函数名   | 输入 | 类型        | 注释 |
| -------- | ---- | ----------- | ---- |
| sayHello | -    | Hello World |      |

', 'SOLIDITY', '2020-09-24 20:03:58.032000', 'HelloWorld', 'HYPERCHAIN', '0', '1.0');
INSERT INTO `stdb`.`contract_market` VALUES ('CONTRACT-MARKET-8d29094b66e94b62bb6672b7a6b3561c', '[14]', '2020-09-24 20:05:26.003000', '# 模板说明

本合约主要用于存证业务场景，针对每个证据存储上链并对应生成一个Hash值，可利用Hash值查取证据以及存储时间。



# 接口描述示例

| 函数名       | 输入                     | 输出                            | 注释     |
| ------------ | ------------------------ | ------------------------------- | -------- |
| getUsers     | -                        | users                           | 获取用户 |
| getEvidence  | fileHash                 | code, fUpLoadTime, saverAddress | 获取证据 |
| saveEvidence | fileHash, fileUploadTime | code                            | 存储证据 |
', 'SOLIDITY', '2020-09-24 20:05:26.003000', '存证', 'HYPERCHAIN', '0', '1.0');
INSERT INTO `stdb`.`contract_market` VALUES ('CONTRACT-MARKET-dfa5ea2d8b9f453789b4a65bded1cb7a', '[10,11,12]', '2020-09-24 20:03:33.297000', '# 模板说明

本合约为基础合约HelloWorld，合约代码内提供注释说明，帮助用户理解该智能合约最基本的结构，熟悉其开发流程和管理流程。

本合约为Java类型合约，内置主合约文件，接口文件和调用文件。



# 接口描述示例

| 函数名   | 输入 | 输出        | 注释 |
| -------- | ---- | ----------- | ---- |
| sayHello | -    | Hello World |      |
', 'JAVA', '2020-09-24 20:03:33.297000', 'HelloWorld', 'HYPERCHAIN', '0', '1.0');
INSERT INTO `stdb`.`contract_market` VALUES ('CONTRACT-MARKET-f52b25cb3e274726b795889e971e97a3', '[15]', '2020-09-24 20:06:11.169000', '# 模板说明

本合约主要用于供应链金融场景，合约内设置了4种角色，分别为：生产者、零售商、监管者和普通客户。可以在业务层设置不同角色可调用的方法，在角色权限范围内执行特定操作。

# 接口描述示例

| 函数名                         | 输入                                  | 输出                                                         | 注释           |
| :----------------------------- | ------------------------------------- | ------------------------------------------------------------ | -------------- |
| newUser                        | ID, name, actor                       | bool                                                         | 新增用户       |
| newProduct                     | commodityID, commodityName, timestamp | bool                                                         | 新增商品       |
| retailerInnerToCustomer        | commodityID, timestamp                | bool                                                         | 零售商转让货物 |
| fromRetailToCustomer           | commodityID, timestamp                | bool                                                         | 出售货物       |
| addWhiteList                   | addr                                  | -                                                            | 添加白名单     |
| getCommodityRecordsByWhiteList | commodityID                           | bool, producerName, produceTime, retailerNames, retailerTimes, customerName, sellTime | 获取白名单     |
| getCommodity                   | commodityID, actor                    | bool, producerName, produceTime, retailerNames, retailerTimes, customerName, sellTime | 获取商品       |
', 'SOLIDITY', '2020-09-24 20:06:11.169000', '供应链金融', 'HYPERCHAIN', '0', '1.0');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
