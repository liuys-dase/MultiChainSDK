/*
 Navicat Premium Data Transfer

 Source Server         : stdb-dev
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : 172.16.1.121:30092
 Source Schema         : stdb

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : 65001

 Date: 30/09/2020 16:07:43
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for contract_market_info
-- ----------------------------
DROP TABLE IF EXISTS `stdb`.`contract_market_info`;
CREATE TABLE `stdb`.`contract_market_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content_path` varchar(255) DEFAULT NULL,
  `created_time` datetime(6) DEFAULT NULL,
  `java_file_type` varchar(255) DEFAULT NULL,
  `market_id` varchar(255) DEFAULT NULL,
  `modified_time` datetime(6) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of contract_market_info
-- ----------------------------
BEGIN;
INSERT INTO `stdb`.`contract_market_info` VALUES (1, 'zRBZYbdiTT.txt', '2020-09-24 19:59:47.998000', NULL, 'CONTRACT-MARKET-096e15b64b854ad9bac554d90598f9b0', '2020-09-24 19:59:47.998000', 'Framework.sol');
INSERT INTO `stdb`.`contract_market_info` VALUES (2, 'sDWGZJNfra.txt', '2020-09-24 20:00:39.691000', 'CONTRACT', 'CONTRACT-MARKET-726729dd8b0b487abbb1c054a7156015', '2020-09-24 20:00:39.691000', 'Framework.java');
INSERT INTO `stdb`.`contract_market_info` VALUES (3, 'FetToIGyoe.txt', '2020-09-24 20:00:39.740000', 'INTERFACE', 'CONTRACT-MARKET-726729dd8b0b487abbb1c054a7156015', '2020-09-24 20:00:39.740000', 'FrameworkAdmin.java');
INSERT INTO `stdb`.`contract_market_info` VALUES (4, 'fSUjvxBBsc.txt', '2020-09-24 20:00:39.746000', 'INTERFACE', 'CONTRACT-MARKET-726729dd8b0b487abbb1c054a7156015', '2020-09-24 20:00:39.746000', 'FrameworkClient.java');
INSERT INTO `stdb`.`contract_market_info` VALUES (5, 'aoNBbJZUpc.txt', '2020-09-24 20:00:39.758000', 'INVOKE', 'CONTRACT-MARKET-726729dd8b0b487abbb1c054a7156015', '2020-09-24 20:00:39.758000', 'FrameworkInvoker.java');
INSERT INTO `stdb`.`contract_market_info` VALUES (6, 'JiJhxxYbUt.txt', '2020-09-24 20:00:39.766000', 'OTHERS_CLASS', 'CONTRACT-MARKET-726729dd8b0b487abbb1c054a7156015', '2020-09-24 20:00:39.766000', 'MyData.java');
INSERT INTO `stdb`.`contract_market_info` VALUES (7, 'hygJCIUjXJ.txt', '2020-09-24 20:00:39.773000', 'OTHERS_ENUM', 'CONTRACT-MARKET-726729dd8b0b487abbb1c054a7156015', '2020-09-24 20:00:39.773000', 'Role.java');
INSERT INTO `stdb`.`contract_market_info` VALUES (8, 'ZarleiIVHa.txt', '2020-09-24 20:01:21.626000', NULL, 'CONTRACT-MARKET-9b272d8476a74f34bb3a0bd960050609', '2020-09-24 20:01:21.626000', 'main.go');
INSERT INTO `stdb`.`contract_market_info` VALUES (9, 'BvxjfAEVnU.txt', '2020-09-24 20:02:12.286000', NULL, 'CONTRACT-MARKET-4e41583ac4fe445d9d3590c40de1e1c2', '2020-09-24 20:02:12.286000', 'main.go');
INSERT INTO `stdb`.`contract_market_info` VALUES (10, 'ZWwkqNLyxV.txt', '2020-09-24 20:03:33.163000', 'CONTRACT', 'CONTRACT-MARKET-dfa5ea2d8b9f453789b4a65bded1cb7a', '2020-09-24 20:03:33.163000', 'HelloWorld.java');
INSERT INTO `stdb`.`contract_market_info` VALUES (11, 'cSBvTZIJrL.txt', '2020-09-24 20:03:33.171000', 'INTERFACE', 'CONTRACT-MARKET-dfa5ea2d8b9f453789b4a65bded1cb7a', '2020-09-24 20:03:33.171000', 'HelloWorldInterface.java');
INSERT INTO `stdb`.`contract_market_info` VALUES (12, 'qqVDDKMlRU.txt', '2020-09-24 20:03:33.178000', 'INVOKE', 'CONTRACT-MARKET-dfa5ea2d8b9f453789b4a65bded1cb7a', '2020-09-24 20:03:33.178000', 'HelloWorldInvoke.java');
INSERT INTO `stdb`.`contract_market_info` VALUES (13, 'GbWRrSSSIK.txt', '2020-09-24 20:03:57.762000', NULL, 'CONTRACT-MARKET-8363d873e3d741f5a45266ac220de92a', '2020-09-24 20:03:57.762000', 'HelloWorld.sol');
INSERT INTO `stdb`.`contract_market_info` VALUES (14, 'VPySHXBXUo.txt', '2020-09-24 20:05:25.890000', NULL, 'CONTRACT-MARKET-8d29094b66e94b62bb6672b7a6b3561c', '2020-09-24 20:05:25.890000', 'Traceability.sol');
INSERT INTO `stdb`.`contract_market_info` VALUES (15, 'IQvmfiTbaG.txt', '2020-09-24 20:06:10.985000', NULL, 'CONTRACT-MARKET-f52b25cb3e274726b795889e971e97a3', '2020-09-24 20:06:10.985000', 'SupplyChain.sol');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
