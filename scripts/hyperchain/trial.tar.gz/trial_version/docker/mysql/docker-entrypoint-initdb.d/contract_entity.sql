/*
 Navicat Premium Data Transfer

 Source Server         : 172.16.1.121
 Source Server Type    : MySQL
 Source Server Version : 50731
 Source Host           : 172.16.1.121:31051
 Source Schema         : stdb

 Target Server Type    : MySQL
 Target Server Version : 50731
 File Encoding         : 65001

 Date: 13/10/2020 01:15:55
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for contract_entity
-- ----------------------------
DROP TABLE IF EXISTS `stdb`.`contract_entity`;
CREATE TABLE `stdb`.`contract_entity` (
  `id` varchar(100) NOT NULL,
  `abi` text,
  `address` text,
  `bin` text,
  `chain_id` varchar(255) DEFAULT NULL,
  `configuration_json` text,
  `create_time` datetime DEFAULT NULL,
  `file_ids` varchar(255) DEFAULT NULL,
  `freeze_reason` text,
  `invoke_configuration` text,
  `jar` text,
  `language_type` varchar(255) DEFAULT NULL,
  `message` text,
  `modify_time` datetime DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `platform_type` varchar(255) DEFAULT NULL,
  `process_number` double DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `b20id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
