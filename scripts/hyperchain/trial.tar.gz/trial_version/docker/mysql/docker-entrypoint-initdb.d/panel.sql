/*
 Navicat Premium Data Transfer

 Source Server         : develop
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : 172.16.1.124:30092
 Source Schema         : stdb

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : 65001

 Date: 07/01/2021 11:56:29
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for panel
-- ----------------------------
DROP TABLE IF EXISTS `stdb`.`panel`;
CREATE TABLE `stdb`.`panel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `options_str` varchar(255) DEFAULT NULL COMMENT 'sql中的占位符',
  `title` varchar(64) DEFAULT NULL COMMENT '监控图表名称',
  `user_id` varchar(128) DEFAULT NULL COMMENT 'default or 用户ID',
  `not_expose` bit(1) DEFAULT NULL COMMENT '是否对外暴露',
  `compounded` bit(1) DEFAULT NULL COMMENT '0 表示不是多个sql的结果',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of panel
-- ----------------------------
BEGIN;
INSERT INTO `stdb`.`panel` VALUES (1, '[\"resourceType\", \"resourceId\"]', '主机CPU占用率', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (2, '[\"resourceType\", \"resourceId\"]', '主机内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (3, '[\"resourceType\", \"resourceId\"]', '主机存储空间', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (4, NULL, '主机StateDB存储空间', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (5, NULL, '主机账本存储空间', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (6, NULL, '节点CPU占用率', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (7, NULL, '节点内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (8, NULL, '节点存储空间占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (9, NULL, '节点StateDB存储空间占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (10, NULL, '节点账本空间存储占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (11, NULL, '节点网络进出速率', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (12, NULL, '节点通道接受交易计数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (13, NULL, '节点块处理时间', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (14, NULL, '节点接收的块计数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (15, NULL, '节点JVM内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (16, NULL, '节点GC时间消耗', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (17, NULL, 'topic消息进出流量', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (18, NULL, 'topic生产字节数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (19, NULL, 'topic消费字节数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (20, NULL, 'Health Check(Ticktime)', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (21, NULL, '平均请求延时', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (22, NULL, 'Znode次数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (23, NULL, '连接情况', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (24, NULL, 'Pending session revalidations', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (25, NULL, 'Outstanding Request', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (26, NULL, 'Watch count', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (27, NULL, 'GC Time', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (28, NULL, 'GC Count', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (29, NULL, 'Heap Used vs Max', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (30, NULL, '联盟链节点健康状态', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (31, NULL, '整体网络进出情况', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (32, NULL, '各节点CPU占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (33, NULL, '各节点内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (34, NULL, '各节点网络I/O', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (35, NULL, '各节点文件系统使用情况', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (36, NULL, '各节点吞吐率', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (37, NULL, '联盟链健康状态', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (40, NULL, '节点通道广播的块计数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (41, NULL, '节点通道广播的交易计数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (43, '', '浏览器实时总览数据', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (44, NULL, '主机系统运行时间', 'default', b'1', NULL);
INSERT INTO `stdb`.`panel` VALUES (45, '', '主机总数', 'default', b'1', NULL);
INSERT INTO `stdb`.`panel` VALUES (46, NULL, '主机CPU核数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (47, NULL, '主机CPUiowait', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (48, NULL, '主机系统平均负载', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (49, NULL, '主机各分区可用空间', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (50, NULL, '主机CPU占用详细', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (51, NULL, '主机当前打开文件描述符', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (52, NULL, '主机根分区使用率', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (53, NULL, '主机最大分区(/etc/hostname)', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (54, NULL, '主机磁盘总空间', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (55, NULL, '主机内存占用详细', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (56, NULL, '主机磁盘io', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (57, NULL, '主机磁盘占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (58, NULL, '主机网络进出速率', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (59, NULL, '主机网络进出数据', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (60, NULL, '主机tcp连接数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (61, NULL, '主机网络概览', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (62, NULL, '主机文件系统', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (63, NULL, '主机健康状态', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (64, NULL, '主机系统占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (65, NULL, '主机存储空间详情', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (66, NULL, '主机内存占用折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (67, NULL, '主机主机CPU占用率折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (68, NULL, '主机服务CPU占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (69, NULL, '主机内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (70, NULL, '服务概览CPU占用率', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (71, NULL, '服务概览内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (72, NULL, '服务概览网络进出速率', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (73, NULL, '主机使用情况CPU', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (74, NULL, '联盟链健康状态', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (75, NULL, '联盟链节点健康状态', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (76, NULL, '联盟链整体网络进出情况', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (77, NULL, '联盟链各节点CPU占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (78, NULL, '联盟链各节点内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (79, NULL, '联盟链各节点网络I/O', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (80, NULL, '联盟链各节点存储空间占用情况', 'default ', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (81, NULL, '节点监控详情节点CPU占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (82, NULL, '节点内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (83, NULL, '节点存储空间', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (84, NULL, '节点CPU占用折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (85, NULL, '节点内存占用折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (86, NULL, '节点存储空间占用折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (87, NULL, '节点State存储空间占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (88, NULL, '节点Filelog文件存储占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (89, NULL, '节点网络进出速率', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (90, NULL, '成功交易计数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (91, NULL, '交易总数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (92, NULL, '区块高度', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (93, NULL, '区块TPS折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (94, NULL, '交易TPS折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (95, NULL, '主机监控服务概览网络进出', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (99, NULL, '节点监控CPU占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (100, NULL, '节点监控内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (101, NULL, '节点监控存储空间', 'default ', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (102, NULL, '节点监控网络进出', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (103, NULL, '节点交易成功验证率', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (104, NULL, '节点交易成功数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (105, NULL, '节点交易总数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (106, NULL, '节点区块高度', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (107, NULL, '节点块处理时间', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (108, NULL, '链概览区块TPS折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (109, NULL, '链概览交易TPS折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (110, NULL, '命名空间块平均处理时间折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (111, NULL, '命名空间验证交易成功率', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (112, NULL, 'k8s当前CPU核数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (113, NULL, 'k8s当前内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (114, NULL, 'k8s主机当前pods个数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (115, NULL, 'k8sCPU占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (116, NULL, 'k8s内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (117, NULL, 'k8sCPU占用折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (118, NULL, 'pod监控列表CPU占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (119, NULL, 'pod监控列表内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (120, NULL, '服务监控CPU占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (121, NULL, '服务监控内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (122, NULL, '服务监控CPU占用折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (123, NULL, 'pod服务监控内存占用折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (124, NULL, 'pod监控详情CPU占用折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (125, NULL, 'pod监控详情内存占用折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (126, NULL, 'k8s内存占用折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (127, NULL, '服务监控内存占用折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (128, NULL, 'fabric各节点CPU占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (129, NULL, 'fabric各节点内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (130, NULL, 'fabric节点监控CPU占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (131, NULL, 'fabric节点监控内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (132, NULL, 'fabricpeer节点CPU占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (133, NULL, 'fabricpeer节点内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (134, NULL, 'fabric接受交易数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (135, NULL, 'fabric接受块计数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (136, NULL, 'peercpu折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (137, NULL, 'peer内存折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (138, NULL, '非peercpu折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (139, NULL, '非peer内存折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (140, NULL, '非peercpu', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (141, NULL, '非peer内存', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (142, NULL, '联盟链pod个数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (143, NULL, 'fabric交易TPS折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (145, NULL, '主机监控k8列表CPU', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (146, NULL, '主机监控k8列表内存', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (147, NULL, '主机监控k8列表服务CPU', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (148, NULL, '主机监控k8列表服务内存', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (149, NULL, 'fabric peer交易验证成功率', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (150, NULL, 'fabric 验证交易成功数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (151, NULL, 'fabric 交易总数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (152, NULL, 'fabric 区块高度', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (153, NULL, 'hpcK8节点监控详情cpu', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (154, NULL, 'hpcK8节点监控详情内存', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (155, NULL, 'hpcK8节点监控详情CPU折线', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (156, NULL, 'hpcK8节点监控详情内存折线', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (157, NULL, '系统监控副本列表CPU占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (158, NULL, '系统监控副本列表内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (159, NULL, '系统运行时间', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (160, NULL, '系统监控副本详情当前CPU', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (161, NULL, '系统监控副本详情当前内存', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (162, NULL, '当前pods个数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (163, NULL, '系统监控副本详情CPU表盘', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (164, NULL, '系统监控副本详情内存表盘', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (165, NULL, '系统监控副本详情CPU折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (166, NULL, '系统监控副本详情内存折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (167, NULL, 'VB系统监控副本列表CPU占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (168, NULL, 'VB系统监控副本列表内存占用', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (169, NULL, 'VB系统运行时间', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (170, NULL, 'VB系统监控副本详情当前CPU', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (171, NULL, 'VB系统监控副本详情当前内存', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (172, NULL, 'VB系统当前pods个数', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (173, NULL, 'VB系统监控副本详情CPU表盘', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (174, NULL, 'VB系统监控副本详情内存表盘', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (175, NULL, 'VB系统监控副本详情CPU折线图', 'default', b'0', NULL);
INSERT INTO `stdb`.`panel` VALUES (176, NULL, 'VB系统监控副本详情内存折线图', 'default', b'0', NULL);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
