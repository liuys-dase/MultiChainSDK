/*
 Navicat Premium Data Transfer

 Source Server         : stdb-dev
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : 172.16.1.121:30092
 Source Schema         : stdb

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : 65001

 Date: 30/09/2020 16:54:09
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for rule
-- ----------------------------
DROP TABLE IF EXISTS `stdb`.`rule`;
CREATE TABLE `stdb`.`rule` (
  `rule_no` varchar(10) COLLATE utf8_bin NOT NULL,
  `rule_name` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `rule_type` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `rule_risk` text COLLATE utf8_bin,
  `rule_rank` int(11) DEFAULT NULL,
  PRIMARY KEY (`rule_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='规则表';

-- ----------------------------
-- Records of rule
-- ----------------------------
BEGIN;
INSERT INTO `stdb`.`rule` VALUES ('L1001', '明确声明编译器版本', '语法风格', '不同编译器支持的Solidity语法和底层功能不同，如果你不显示的声明编译器版本，那么将使得任何版本的编译器都可以编译，造成当前编译器不能识别当前Solidity源代码的语法或支持更丰富的功能，使得代码执行不符合预期。', 0);
INSERT INTO `stdb`.`rule` VALUES ('L1002', '状态变量名规范', '语法风格', 'solidity中变量分为状态变量和局部变量，我们希望你在合约中用严格的代码规范来区分这两类变量。因为状态变量具有持久话特性，而局部变量并不具有该特性。', 0);
INSERT INTO `stdb`.`rule` VALUES ('L1003', '函数/事件/修饰器命名规范', '语法风格', 'solidity中的定义事件和函数的方式极其相似，使用方式相同。如果你定义了相似的函数与时间(参数相同名称相似)，可能会造成错误的调用，编译器不会阻止这种行为通过编译，合约部署后可会造成未知的风险。', 0);
INSERT INTO `stdb`.`rule` VALUES ('L1004', '弃用suicide函数', '不稳定或过时的方法', '在EIP6中提出了重命名SUICIDE操作码为SELFDESTRUCT的意见，初衷是尽全力保护Solidity的开发者社区中那些受到抑郁困扰或者还沉浸在身边亲人自杀带来的痛苦中的人。该意见的实现方式是新增了SELFDESTRUCT作为SUICIDE操作码的别名（不是替换），但是考虑到suicide已经被弃用，所以为了安全起见，杜绝使用析构函数suicide。', 1);
INSERT INTO `stdb`.`rule` VALUES ('L1005', '函数可见性', '身份及权限问题', '函数默认是public类型，但是为了安全起见要求明确声明函数可见性，避免因为疏忽导致对外暴露了内部方法，造成不必要的损失。', 2);
INSERT INTO `stdb`.`rule` VALUES ('L1006', 'if结构', '语法风格', 'EVM执行这段程序时会进行同等if条件语句次数的判断。', 0);
INSERT INTO `stdb`.`rule` VALUES ('L1007', '变量与关键字重名', '变量/参数命名问题', '声明变量时，建议变量的名称不要与关键字（如msg与this）重复', 1);
INSERT INTO `stdb`.`rule` VALUES ('L1008', '变量之间重名', '变量/参数命名问题', '声明变量时，建议变量的名称不要与其它变量重复', 1);
INSERT INTO `stdb`.`rule` VALUES ('L4001', '过于相似的变量名', '变量/参数命名问题', '声明变量时，使用了过于相似的变量名容易造成混淆。', 0);
INSERT INTO `stdb`.`rule` VALUES ('S1001', '使用弱类型', '数值溢出', '弱类型变量由编译器按初始值决定其变量类型，其具体类型一方面依赖于编译器，另一方面依赖于开发者，这让变量类型变得不明确，容易造成该类型变量范围溢出等安全问题。', 3);
INSERT INTO `stdb`.`rule` VALUES ('S1002', '加密函数', '不稳定或过时的方法', '在EIP6中提出了重命名sha3哈希加密函数的意见，初衷是为了减少SHA-3加密标准的冲突，避免和sha256哈希加密函数混淆。该意见的实现方案是新增了keccak256哈希加密函数作为sha3哈希加密函数的别名（不是替换），但是考虑到sha3已经被弃用，同时容易和sha256哈希加密函数混淆，所以为了安全起见，杜绝使用sha3加密函数。', 2);
INSERT INTO `stdb`.`rule` VALUES ('S1003', 'fallback函数', '重入攻击', 'Solidity支持在合约执行消息发送没有携带参数或没有匹配的函数可供调用时，调用fallback函数作相应处理。\n\nfallback函数可以不显式声明，也可以显式声明成不带方法名的函数。\n\nfallback应该尽可能简单，\n', 2);
INSERT INTO `stdb`.`rule` VALUES ('S1004', '函数递归调用', 'EVM堆栈局限性', 'Solidity基于EVM虚拟机执行，其堆栈有限制，不建议执行函数递归调用这样的消耗资源的代码。递归调用时结束条件和嵌套深度无法控制，容易因为资源不足造成虚拟机执行中断。', 3);
INSERT INTO `stdb`.`rule` VALUES ('S1005', '布尔类型使用非逻辑操作符', '其它', '原则上布尔类型的操作符仅限于逻辑操作符和相等比较操作符。为了让开发者对布尔类型的操作符不产生困惑，同时更出于安全考虑，应该杜绝对布尔类型使用非逻辑操作符。', 2);
INSERT INTO `stdb`.`rule` VALUES ('S1006', 'call.value()', '重入攻击', '切忌不可让raw address类型的变量直接调用call.value()()方法。此方法的基本功能是发送指定数量的Ether并且触发对应代码的执行，由此被调用的外部智能合约代码将享有所有剩余的gas。但通过这种方式转账会有极大的可能暴露可重入性的漏洞，必须严谨使用。', 3);
INSERT INTO `stdb`.`rule` VALUES ('S1007', 'mulmod()函数的使用', '数值溢出', 'Solidity的mulmod(a, b, c)方法相当于执行了如下的运算：\n\n    mulmod(a, b, c) <=> a * b % c\n\n如上所示，mulmod函数的第二个数值运算是取余运算。一旦c值为零，则直接报Arithmetic类型错误。\n', 2);
INSERT INTO `stdb`.`rule` VALUES ('S1008', 'addmod()函数的使用', '数值溢出', '使用addmod(a, b, c)相当于执行了如下的运算：\n\n    addmod(a, b, c) <=> (a + b) % c\n\n如上所示，addmod函数的第二个数值运算是取余运算。一旦c值为零，则直接报Arithmetic类型错误。\n', 2);
INSERT INTO `stdb`.`rule` VALUES ('S1009', '幂操作', 'EVM堆栈局限性', '一旦涉及到大计算量，便不能使用幂操作符。使用幂操作符来运算大计算量将导致智能合约代码在编译时使编译器死机。值得注意的是，这个校验需要在编译之前就进行。', 3);
INSERT INTO `stdb`.`rule` VALUES ('S1010', '调用外部合约后维护状态变量', '重入攻击', '在Solidity智能合约中，诸如send、transfer、call.value等函数都可以调用外部合约。以上代码中，将userBalances[msg.sender]清零的行为，发生在msg.sender.call.value函数之后。这样暴露了一个问题——在这之前可以成功递归调用很多次withdrawBalance()函数。与之类似的Solidity安全漏洞是针对DAO的攻击。', 3);
INSERT INTO `stdb`.`rule` VALUES ('S2001', '时间戳依赖', '操纵区块属性', '在一般情况下，不建议您在赋值变量的时候依赖now（除非您确实需要这样做）。因为now值在一定程度上可以被不诚实的节点影响。若有节点恶意修改系统时间，那么这个节点完全可能控制这个函数从而生成指定的数值来发起攻击。', 2);
INSERT INTO `stdb`.`rule` VALUES ('S2002', '区块信息依赖', '操纵区块属性', '在一般情况下，不建议您在赋值变量的时候依赖block.difficulty等区块信息（凡是用到block的皆为区块信息，如block.hash）。因为相关区块信息在一定程度上可以被不诚实的节点影响。如果有节点控制了区块链属性，那么这个节点完全可能控制这个函数从而生成指定的数值来发起攻击。', 2);
INSERT INTO `stdb`.`rule` VALUES ('S2003', '循环次数', '死循环', '若合约中的函数有for/while/dowhile循环语句，且其循环次数依赖于外部传递的参数（如上例中的uintArray），则攻击者便能够恶意地传递一个非常巨大的参数使得合约陷入长时间的循环等待中。除非外部严格限制了入参的规格，否则非常不建议循环次数直接依赖于外部传递的参数。', 3);
INSERT INTO `stdb`.`rule` VALUES ('S2004', '数值运算', '数值溢出', '在Solidity智能合约中，任何数值的加减乘除幂以及左值运算，都需要考虑溢出问题，否则一旦溢出将造成不可挽回的后果，尤其是对于资金管理等严格复杂的业务场景。', 3);
INSERT INTO `stdb`.`rule` VALUES ('S2005', 'throw关键字', '不稳定或过时的方法', 'throw关键字在高版本的编译器（从0.4.13开始）中已经被淘汰。对于使用已经淘汰的方法可能会出现安全隐患。', 1);
INSERT INTO `stdb`.`rule` VALUES ('S2006', 'tx.origin的使用', '身份及权限问题', 'tx.origin是交易的发送者（全调用链上），msg.sender 是消息的发送者（当前调用）。即如果有A->B->C->D调用。对于D来说tx.origin为A，msg.sender为C，上述错误合约利用tx.origin进行授权，如果你是A，当你调用B合约(恶意攻击者编写)时，B转发给C合约，C中调用以上不安全合约(D)的transferTo方法。D中授权时tx.origin等于D合约owner,你不预期的转账将会发生。造成你的财产流失。', 3);
INSERT INTO `stdb`.`rule` VALUES ('S2007', '函数参数', '其它', '函数的入参理应在函数调用前逻辑处理完毕，函数体内仅作为影响全局变量或函数中变量的存在，如果你必须要对函数的参数进行逻辑处理，我们推荐你使用全新的变量来作为该次逻辑处理的返回。', 1);
INSERT INTO `stdb`.`rule` VALUES ('S2008', '内联汇编', '其它', '内联编译是一种非常底层的方式来访问EVM虚拟机。他没有Solidity提供的多种安全机制。', 2);
INSERT INTO `stdb`.`rule` VALUES ('S2009', 'for循环体', '死循环', '在for循环体内修改循环变量，for循环可能会失去控制。', 3);
INSERT INTO `stdb`.`rule` VALUES ('S2010', '修饰器语法', '语法风格', 'solidity修改器被广泛用于函数的限制访问。如上修改器要求被修饰的函数调用者支付200ether来使用该修饰函数。functionUseCosts调用者如果支付了超过200ether，超过的部分在函数体(修改器的_会被修饰函数的函数体替代)执行完毕后将返还给调用者。但是在solidity版本0.4.0前，函数的意外返回会跳过修改器_后的代码执行直接返回。尽管0.4.0版本后修复了该bug，但是我们仍然不推荐你在修改器_后编写任何代码，因为函数修改器本身就是作为限制函数访问的存在，你只需在修改器中增加你需要的限制，然后_(会被修饰函数的函数体替代)结束修改器。', 0);
INSERT INTO `stdb`.`rule` VALUES ('S3001', '继承', '不安全的编程模式', 'Solidity支持多继承和多态，实现的方式是通过直接的代码拷贝，当一个合约从多个合约继承的时候，只有一个合约（子类）会被部署到区块链上，而其他的代码会被拷贝到这个合约中去。因此换句话说，继承的写法总是能够写成一个单独的合约。solidity的继承并不是十分成熟，可能会出现一些奇怪的机制从而改变你的智能合约本身的逻辑。(上述不安全合约会让你误认为调用useEmergencyCode方法即可成为owner，实则不然，solidity会在拷贝基类代码时，对每个storage变量分配一个slot id，当然这与变量命名没有关系。所以你在调用withdraw方法后仍然无法通过owner身份验证)。', 1);
INSERT INTO `stdb`.`rule` VALUES ('S3002', '抽象方法', '不安全的编程模式', '抽象方法出现在抽象合约或者是在接口中。其中抽象合约可以有其它非抽象方法，接口只能有抽象方法。若抽象合约中只有抽象方法，那么这个合约是无法被编译的，只能用作父合约。而要实现这个父合约，必然要有一个子合约来继承它。在S3001【谨慎】使用继承一节中已经解释了尽量不要使用继承的原因。因此我们同样建议您少使用抽象方法。', 1);
INSERT INTO `stdb`.`rule` VALUES ('S3003', '位运算', '数值溢出', '在Solidity中，右移和除是等价的。但有符号整数类型负值右移所产生的结果跟其它语言中所产生的结果是不同的。移位运算的结果取决于运算符左边的类型，且对一个负数进行移位会导致其符号消失，因此有可能会引发运行时异常（如上例所示）。同时，若移位符右边的数是负数，也会抛出运行时异常。', 2);
INSERT INTO `stdb`.`rule` VALUES ('S3004', '函数参数声明', '变量/参数命名问题', '在Solidity智能合约中，若函数的参数与状态变量声明同名，编译器不会报错。如上例中，状态变量与函数参数同时命名为stateVariavle，此时在函数体内部，stateVariavle指的是函数参数而不是状态变量，即参数会将同名的状态变量覆盖。这种情况下便不能在函数体内部使用那个同名的状态变量了。', 1);
INSERT INTO `stdb`.`rule` VALUES ('S3005', '整数类型', 'EVM堆栈局限性', '在Solidity合约中，int与uint分别表示有符号和无符号的不同位数的整型变量。 支持关键字uint8到uint256（无符号，从8位到256位）以及int8到int256，以8位为步长递增。uint和int分别是uint256和int256的别名。声明整数时，若不小心超过了类型（如uint24）的上限，则会报错。使用uint256/int256则可以兼容所有整数类型。一般合约中涉及到计算与函数选择器时，都会使用256位的整数类型。尤其是在循环中，若声明的整数位数过小，其很有可能因为达不到循环次数上限而陷入无限循环（如上例所示）。且EVM实际上出于运算速度和效率方面考虑，采用了256bit整数类型来实现数学运算，合约中小于256位的整数类型在运算过程中都会被打包成256位。因此建议您一开始就直接将整数声明成256位。', 3);
INSERT INTO `stdb`.`rule` VALUES ('S3006', '函数返回参数', '变量/参数命名问题', '在Solidity合约中，声明函数的同时需要设定其返回值。若有返回值，则需要加returns关键字（若没有，则不需要加，默认返回空）。同时Solidity支持批量返回与批量接收函数返回值。在上述合约中，以func函数的返回参数命名为stateVariable，其会覆盖相应的状态变量，导致函数体内不可使用状态变量stateVariable。且声明返回值的本质与returns(uint)其实是一样的，多加一个限制只会带来更多可能的错误。', 1);
INSERT INTO `stdb`.`rule` VALUES ('S3007', 'raw address操作底层方法', '重入攻击', '直接使用raw address上执行操作的底层方法（如`address.call()`, `address.callcode()`, `address.delegatecall()`, `address.send()`）很容易出现安全问题，这些底层方法不会抛出异常(throw)，只是会在遇到错误时返回false。因此开发者很容易忽视这些方法执行的返回值，如果返回false则表明本次执行失败，需要作相应的处理。', 3);
INSERT INTO `stdb`.`rule` VALUES ('S4002', '未接收函数的返回值', '不安全的编程模式', '对于有返回值的函数，应当接收函数的返回值并对返回值进行检查。', 1);
INSERT INTO `stdb`.`rule` VALUES ('S4003', 'delete语句造成内存碎片', '其它', '使用delete语句删除了数组元素后，数组占据的长度不会进行改变。', 1);
INSERT INTO `stdb`.`rule` VALUES ('S4004', 'bytes与string长度不同', '其它', 'bytes和string类型长度不同，因为string是UTF-8编码，一个字符不一定被编码为一个字节。', 1);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
