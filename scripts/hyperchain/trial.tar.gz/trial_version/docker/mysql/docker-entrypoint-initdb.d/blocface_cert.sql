# ************************************************************
# Sequel Pro SQL dump
# Version 5446
#
# https://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 172.16.30.74 (MySQL 5.7.31)
# Database: blocface
# Generation Time: 2021-10-11 07:01:51 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table cert
# ------------------------------------------------------------

DROP TABLE IF EXISTS `blocface`.`cert`;

CREATE TABLE `blocface`.`cert` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time_create` datetime DEFAULT NULL,
  `time_update` datetime DEFAULT NULL,
  `time_delete` datetime DEFAULT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `time_issue` datetime DEFAULT NULL,
  `time_expiration` datetime DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `message` text,
  `file_name` varchar(255) DEFAULT NULL,
  `node_id` int(11) DEFAULT NULL,
  `chain_id` int(11) DEFAULT NULL,
  `user_id` char(64) DEFAULT "USER-3f23f7b2904e428ea748421872c96322",
  `group_id` char(64) DEFAULT "ORG-cf5b157ff6814c23a3a609a4804f982d",
  `viewer` char(32) DEFAULT "USER",
  PRIMARY KEY (`id`),
  KEY `IDX_cert_time_delete` (`time_delete`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

use blocface;

DELIMITER ||
create trigger blocface_cert_permission
before insert on `blocface`.`cert`
for each row 
begin
set new.user_id = "USER-3f23f7b2904e428ea748421872c96322";
set new.group_id = "ORG-cf5b157ff6814c23a3a609a4804f982d";
set new.viewer = "USER";
end;
||
DELIMITER ;

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
