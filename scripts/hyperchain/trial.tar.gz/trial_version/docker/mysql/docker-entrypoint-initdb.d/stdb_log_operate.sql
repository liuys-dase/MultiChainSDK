# ************************************************************
# Sequel Pro SQL dump
# Version 5446
#
# https://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 172.16.1.129 (MySQL 5.7.31-log)
# Database: stdb
# Generation Time: 2021-10-12 08:50:49 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table log_operate
# ------------------------------------------------------------

DROP TABLE IF EXISTS `stdb`.`log_operate`;

CREATE TABLE `stdb`.`log_operate` (
  `id` varchar(100) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `error_code` int(11) DEFAULT NULL,
  `error_message` text,
  `function_module` varchar(255) DEFAULT NULL,
  `life_cycle_uuid` varchar(255) DEFAULT NULL,
  `operate_name` varchar(255) DEFAULT NULL,
  `operate_object` varchar(255) DEFAULT NULL,
  `operate_person` varchar(255) DEFAULT NULL,
  `operate_results` bit(1) DEFAULT NULL,
  `organization_id` varchar(255) DEFAULT NULL,
  `organization_name` varchar(255) DEFAULT NULL,
  `resource_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
