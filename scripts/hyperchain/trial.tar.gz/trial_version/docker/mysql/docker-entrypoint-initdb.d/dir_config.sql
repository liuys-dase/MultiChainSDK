/*
 Navicat Premium Data Transfer

 Source Server         : blocface-test
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : 172.16.1.121
 Source Database       : blocface

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : utf-8

 Date: 10/09/2020 19:38:22 PM
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
--  Table structure for `blocface`.dir_config`
-- ----------------------------
DROP TABLE IF EXISTS `blocface`.`dir_config`;
CREATE TABLE `blocface`.`dir_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time_create` datetime DEFAULT NULL,
  `time_update` datetime DEFAULT NULL,
  `time_delete` datetime DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `side_type` int(11) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `recommend` tinyint(1) DEFAULT NULL,
  `display` tinyint(1) DEFAULT NULL,
  `sideType` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_dir_config_time_delete` (`time_delete`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `blocface`.dir_config`
-- ----------------------------
BEGIN;
INSERT INTO `blocface`.`dir_config` VALUES ('1', '2020-09-02 13:51:58', '2020-09-16 21:04:46', null, 'Blocface', '1', '1Blocface/', '1', '1', '1');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
