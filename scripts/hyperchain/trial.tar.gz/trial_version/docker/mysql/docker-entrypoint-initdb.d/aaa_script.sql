--
create database IF NOT EXISTS  `blocface` default character set utf8mb4 collate utf8mb4_general_ci;
create database IF NOT EXISTS  `stdb` default character set utf8mb4 collate utf8mb4_general_ci;
create database IF NOT EXISTS  `LICENSE` default character set utf8mb4 collate utf8mb4_general_ci;
create database IF NOT EXISTS  `verifier` default character set utf8mb4 collate utf8mb4_general_ci;