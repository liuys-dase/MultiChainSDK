/*
 Navicat Premium Data Transfer

 Source Server         : 172.16.1.124
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : 172.16.1.124:30092
 Source Schema         : stdb

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : 65001

 Date: 12/10/2020 14:31:58
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for driver
-- ----------------------------
DROP TABLE IF EXISTS `stdb`.`driver`;
CREATE TABLE `stdb`.`driver` (
  `id` varchar(100) NOT NULL,
  `actions` text,
  `b20id` varchar(100) DEFAULT NULL,
  `created_time` datetime(6) DEFAULT NULL,
  `driver_desc` text,
  `driver_name` varchar(255) DEFAULT NULL,
  `extra` varchar(255) DEFAULT NULL,
  `logo` text,
  `status` varchar(255) DEFAULT NULL,
  `stop_reason` text,
  `sub_status` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_jq90pn5t2tkeeay8x8vxhvlwo` (`b20id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


SET FOREIGN_KEY_CHECKS = 1;
