/*
 Navicat Premium Data Transfer

 Source Server         : stdb-dev
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : 172.16.1.121:30092
 Source Schema         : stdb

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : 65001

 Date: 30/09/2020 16:54:21
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for rule_type
-- ----------------------------
DROP TABLE IF EXISTS `stdb`.`rule_type`;
CREATE TABLE `stdb`.`rule_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `risk` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of rule_type
-- ----------------------------
BEGIN;
INSERT INTO `stdb`.`rule_type` VALUES (1, '语法风格', '不具备良好的语法风格容易造成逻辑上的错误');
INSERT INTO `stdb`.`rule_type` VALUES (2, '不稳定或过时的方法', '使用不稳定或过时的方法可能会发生未知的错误');
INSERT INTO `stdb`.`rule_type` VALUES (3, '身份及权限问题', '合约的调用必须要有明确的权限划分以及身份验证，否则黑客极易利用此漏洞发起攻击');
INSERT INTO `stdb`.`rule_type` VALUES (4, '变量/参数命名问题', '若合约中的变量、参数等发生重名或与关键字产生冲突，则总会使其中一个的作用域失效，从而造成逻辑上的错误');
INSERT INTO `stdb`.`rule_type` VALUES (5, '数值溢出', '合约中的数值一旦溢出，将会产生极其严重的后果，尤其是在涉及到金额时最为严重');
INSERT INTO `stdb`.`rule_type` VALUES (6, '重入攻击', '在进行合约间的调用时容易被攻击者找到漏洞从而进行重复调用，后果严重');
INSERT INTO `stdb`.`rule_type` VALUES (7, 'EVM堆栈局限性', 'EVM本身有一定局限性，如栈的深度很小，容易溢出等');
INSERT INTO `stdb`.`rule_type` VALUES (8, '操纵区块属性', '攻击者可利用恶意节点修改区块属性，从而对合约发起攻击');
INSERT INTO `stdb`.`rule_type` VALUES (9, '死循环', '若函数发生死循环，整个合约将会瘫痪');
INSERT INTO `stdb`.`rule_type` VALUES (10, '不安全的编程模式', '不推荐使用【继承】、【抽象方法】这两种不安全的编程模式，除非你特别了解它们在Solidity语言中的特点');
INSERT INTO `stdb`.`rule_type` VALUES (11, '其它', '其它');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
