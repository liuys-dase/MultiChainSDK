/*
 Navicat Premium Data Transfer

 Source Server         : 172.16.1.124
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : 172.16.1.124:30092
 Source Schema         : stdb

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : 65001

 Date: 12/10/2020 21:50:34
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for secretkey
-- ----------------------------
DROP TABLE IF EXISTS `stdb`.`secretkey`;
CREATE TABLE `stdb`.`secretkey` (
  `id` varchar(100) NOT NULL,
  `create_method` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `encryption_algorithm` varchar(255) DEFAULT NULL,
  `key_address` varchar(50) DEFAULT NULL,
  `key_name` varchar(50) DEFAULT NULL,
  `secret_key` text,
  `update_key_time` datetime DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of secretkey
-- ----------------------------
BEGIN;
INSERT INTO `stdb`.`secretkey` VALUES ('KEY-1f5904c51eee4e79a078b5048347ea3b', 'SYSTEM', '2020-09-29 12:56:59', 'SM2', '0xff6279edcab0ee10c8925a27cbc91b82ce44d5e8', 'SM2密钥', '{\"address\":\"0xff6279edcab0ee10c8925a27cbc91b82ce44d5e8\",\"algo\":\"0x13\",\"version\":\"4.0\",\"publicKey\":\"04fd509280c3e6d0b7e27240522d5191333aff6de767e13fe0a20e81714b8aa03787e074dee5ea0d8cdf3038f3d13e82d452c6a6de8b953a91e5dc1efb1825bf35\",\"privateKey\":\"e410327aaccf7926ca453ea0a9bdee8c91c51983f59b1a72a8886a3647718d5e\"}', '2020-09-29 12:56:59', 'USER-3f23f7b2904e428ea748421872c96322');
INSERT INTO `stdb`.`secretkey` VALUES ('KEY-b04f9419c5614ccca08757d25fa5ae0b', 'SYSTEM', '2020-09-29 12:57:00', 'ECDSA', '0x5f7ad12c6a408321bacea07ff0f6c4dad8d16e9f', 'ECDSA密钥', '{\"address\":\"0x5f7ad12c6a408321bacea07ff0f6c4dad8d16e9f\",\"algo\":\"0x03\",\"version\":\"4.0\",\"publicKey\":\"044debadbf96ff3fdf6490f55569891eaa0d513e4150a4ad0da4d70350a50d42c5e2dc9bdb6bfe297802875055281c61cd645c5a06d7e5739b1a187d312145a351\",\"privateKey\":\"f19afaf56f75424951d22807058b5867208eee819636355f6073b605c5642a79\"}', '2020-09-29 12:57:00', 'USER-3f23f7b2904e428ea748421872c96322');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
