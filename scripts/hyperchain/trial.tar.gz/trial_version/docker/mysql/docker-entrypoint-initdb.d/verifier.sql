/*
 Navicat Premium Data Transfer

 Source Server         : blocface-develop
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : 172.16.1.121
 Source Database       : verifier

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : utf-8

 Date: 10/12/2020 12:32:47 PM
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
--  Table structure for `exception`
-- ----------------------------
DROP TABLE IF EXISTS `verifier`.`exception`;
CREATE TABLE `verifier`.`exception` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `exception_type` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `license_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `time` datetime NOT NULL,
  `other_info` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
--  Table structure for `license_prefix`
-- ----------------------------
DROP TABLE IF EXISTS `verifier`.`license_prefix`;
CREATE TABLE `verifier`.`license_prefix` (
  `license_id` bigint(20) unsigned NOT NULL,
  `time` datetime NOT NULL,
  `usable` tinyint(1) NOT NULL DEFAULT '0',
  `prefix` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`license_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
--  Table structure for `validation`
-- ----------------------------
DROP TABLE IF EXISTS `verifier`.`validation`;
CREATE TABLE `verifier`.`validation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `license_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  `time` bigint(20) NOT NULL DEFAULT '0',
  `ip` varchar(255) NOT NULL DEFAULT '',
  `usable` tinyint(1) NOT NULL DEFAULT '0',
  `request` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

SET FOREIGN_KEY_CHECKS = 1;
