/*
 Navicat Premium Data Transfer

 Source Server         : 172.16.1.124
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : 172.16.1.124:30092
 Source Schema         : blocface

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : 65001

 Date: 12/10/2020 14:31:34
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for driver
-- ----------------------------
DROP TABLE IF EXISTS `blocface`.`driver`;
CREATE TABLE `blocface`.`driver` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time_create` datetime DEFAULT NULL,
  `time_update` datetime DEFAULT NULL,
  `time_delete` datetime DEFAULT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `driver_name` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `logo` text,
  `driver_type` varchar(255) DEFAULT NULL,
  `exe_path` varchar(255) DEFAULT NULL,
  `resources` text,
  `actions` longtext,
  `file_name` varchar(255) DEFAULT NULL,
  `readme` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_driver_uuid` (`uuid`),
  KEY `IDX_driver_time_delete` (`time_delete`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

SET FOREIGN_KEY_CHECKS = 1;
