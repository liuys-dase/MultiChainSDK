#!/usr/bin/env bash

sudo rm -rf prometheus/data/* 
sudo rm -rf pushgateway/data/*
