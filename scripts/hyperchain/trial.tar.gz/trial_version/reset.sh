#!/usr/bin/env bash

# shellcheck disable=SC1091
source script/function/function.sh

print_green "执行重置脚本会清空持久化数据，确定要清空吗？[Y/N]"
read answer;

if [[ "${answer}" != "Y" && "${answer}" != "y" ]]; then
    print_green "已取消重置"
    exit 0
fi

print_red "正在重置.."

sudo rm -rf docker/mysql/data/* && rm -rf docker/mysql/data/.user_scripts_initialized 
sudo rm -rf docker/minio/data/* && rm -rf docker/minio/data/.minio.sys
sudo rm -rf docker/etcd/data/*
sudo rm -rf docker/prometheus/prometheus/data/*
sudo rm -rf docker/prometheus/pushgateway/data/*
sudo rm -rf script/flato/prepare

print_green "重置完成"

exit 0

