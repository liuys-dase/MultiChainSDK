#!/usr/bin/env bash
echo "开始启动........"
echo
echo " ____    _____      _      ____    _____ "
echo "/ ___|  |_   _|    / \    |  _ \  |_   _|"
echo "\___ \    | |     / _ \   | |_) |   | |  "
echo " ___) |   | |    / ___ \  |  _ <    | |  "
echo "|____/    |_|   /_/   \_\ |_| \_\   |_|  "
echo
echo "Build your servers"
echo

# shellcheck disable=SC1091
source script/function/function.sh

# 判断是否安装了docker
if ! docker -v; then
  print_red "docker没有安装,请先安装docker"
  exit 1
fi

if ! docker-compose -v; then
  print_red "docker-compose没有安装,请先安装docker-compose"
  exit 1
fi

echo
print_green "获取服务的配置文件"
./script/init_config.sh

echo
print_green "创建docker内部网路"
network_exist=$(docker network ls | grep blocface-network) || true
if [[ "$network_exist" == "" ]]; then
  #--gateway "$(get_properity "docker.network.gateway")" --subnet "$(get_properity "docker.network.subnet")"
  docker network create -d bridge blocface-network
else
  print_red "docker内部网路blocface-network已经存在"
fi

echo
print_green "启动组件镜像服务"
./script/install_mysql.sh
./script/install_etcd.sh
./script/install_nats.sh
./script/install_traefik.sh
./script/install_prometheus.sh
./script/install_minio.sh
print_red "所有三方组件已经全部启动!"

echo
print_green "获取服务的配置文件"
./script/conf.sh

./script/config_chainctl.sh
./script/config_core.sh
./script/config_dbproxy.sh
./script/config_docset.sh
./script/config_gateway.sh
./script/config_logger.sh
./script/config_monitor.sh
./script/config_hostagent.sh
print_green "更新配置完成"

./script/install_baas-go.sh
sleep 15 
print_red "baas-go服务已经启动!"

./script/install_oauth.sh
print_red "oauth服务已经启动!"

./script/install_stdb.sh
print_red "stdb服务已经启动!"

./script/install_meshsec.sh
print_red "meshsec服务已经启动!"

./script/install_console.sh
sleep 20
print_red "console服务已经启动!"

flato="$(get_properity "flato.enable")"
if [ "${flato}" == "true" ]; then
  ./script/install_flato.sh
  print_red "flato服务已经启动!"
fi

./script/health_check.sh

network="$(get_properity "global.network")"
ip=$(ifconfig ${network} | grep inet | grep -v inet6 | awk '{print $2}')
port="$(get_properity "console.port")"
print_green "启动完毕，可以通过 http://${ip}:${port} 访问趣链区块链服务平台！"

