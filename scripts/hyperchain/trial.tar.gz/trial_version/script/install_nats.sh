#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh

docker_compose_production=$(cat ./docker/nats/docker-compose.yaml)

docker_compose_production=$(replace_bracket "${docker_compose_production}" NATS_IMAGE "$(getImage image_version nats)")

echo "${docker_compose_production}" > ./docker/nats/docker-compose-production.yaml

docker-compose -f ./docker/nats/docker-compose-production.yaml up -d