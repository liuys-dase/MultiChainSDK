#!/usr/bin/env bash

# shellcheck disable=SC1091
source script/function/function.sh

image="baas-go"
name="baas-go-conf"
docker run --rm -itd --entrypoint /bin/sh --name "$name" "$(getImage image_version "$image")" -c "tail -f /dev/null"
for file in docker/baas-go/*; do
  {
    if [ -d "$file" ]; then
      server="${file##*/}"
      
      mkdir -p docker/baas-go/"$server"/conf
      docker cp "$name":/root/"$server"/conf/cfg.toml docker/baas-go/"$server"/conf/cfg.toml
      if [[ "$server" == core ]]; then
        mkdir -p docker/baas-go/"$server"
        docker cp "$name":/root/"$server"/issuer docker/baas-go/"$server"
        docker cp "$name":/root/"$server"/verifier docker/baas-go/"$server"
      fi

      # print_blue 获取"$server"服务的默认配置文件成功!
    fi
  } &#多线程跑，获取每个docker服务的配置文件
done
docker stop "$name"
wait
print_green 获取服务的配置文件完成!


