#!/usr/bin/env bash

# shellcheck disable=SC1091
source script/function/function.sh

default=$(cat ./conf/default.toml)
values=$(cat ./conf/values.toml)
echo "${values}" > ./values.toml
echo "${default}" >> ./values.toml

