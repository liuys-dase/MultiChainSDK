#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh

chmod -R 0777 ./docker/mysql/data

docker_compose_production=$(cat ./docker/mysql/docker-compose.yaml)

docker_compose_production=$(replace_bracket "${docker_compose_production}" MYSQL_IMAGE "$(getImage image_version mysql)")

docker_compose_production=$(replace_bracket "${docker_compose_production}" MYSQL_PASSWORD "$(get_properity 'mysql.password')")

echo "${docker_compose_production}" > ./docker/mysql/docker-compose-production.yaml

docker-compose -f ./docker/mysql/docker-compose-production.yaml up -d

print_blue "正在等待数据库安装完成（请耐心等待）..."
db=0
i=1
while [[ $i -le 100 ]]; do
  sleep 5
  curl -o .tmp http://127.0.0.1:3306 >>/dev/null 2>&1 || touch .tmp1
  # shellcheck disable=SC2181
  if [[ ! -f .tmp1 ]]; then
    print_red "数据库成功启动!"
    db=1
    rm -rf .tmp
    break
  fi
  print_red "数据库还在启动中 ..."
  rm -rf .tmp1
  ((i++))
done
if [[ "$db" -eq 1 ]]; then
  print_blue "数据库初始化已经完成!"
else
  print_red "数据库初始化没有完成,请检查问题"
fi
