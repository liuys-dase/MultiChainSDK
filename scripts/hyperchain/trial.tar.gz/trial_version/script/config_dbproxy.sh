#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh

rootdir="$(pwd)"

cd docker/baas-go/dbproxy/conf || exit 0

replace_line_in_toml cfg.toml etcd.host "[\"http://etcd:2379\"]" --no-quoto

replace_line_in_toml cfg.toml grpc.port "$(get_properity 'dbproxy.grpc.port')" --no-quoto

replace_line_in_toml cfg.toml grpc.host "$(get_properity 'dbproxy.grpc.host')" --quoto

replace_line_in_toml cfg.toml http.port "$(get_properity 'dbproxy.http.port')" --no-quoto

replace_line_in_toml cfg.toml http.host "$(get_properity 'dbproxy.http.host')" --quoto

replace_line_in_toml cfg.toml MYSQL_PASSWORD "$(get_properity 'mysql.password')" --quoto

