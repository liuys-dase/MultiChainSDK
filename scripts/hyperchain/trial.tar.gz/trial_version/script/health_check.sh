#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh

print_blue "正在等待组件启动成功（请耐心等待）..."
network="$(get_properity "global.network")"
ip=$(ifconfig ${network} | grep inet | grep -v inet6 | awk '{print $2}')
port="$(get_properity "console.port")"

i=1
while [[ $i -le 100 ]]; do
  sleep 5
  res=$(curl --silent -H 'Cache-Control: no-cache' "http://${ip}:${port}/stdb/api/v1.0/user/info")
  # print_red "res = ${res}"

  # shellcheck disable=SC2181
  if [[ "${res}" =~ "403"  ]]; then
    # print_red "403"
    break
  fi
  # print_red "404"
  ((i++))
done

