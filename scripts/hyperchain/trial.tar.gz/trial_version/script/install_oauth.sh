#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh

docker_compose_production=$(cat ./docker/oauth/docker-compose.yaml)

docker_compose_production=$(replace_bracket "${docker_compose_production}" OAUTH_HTTP_PORT "$(get_properity 'oauth.http.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" OAUTH_HTTP_HOST "$(get_properity 'oauth.http.host')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" OAUTH_GRPC_PORT "$(get_properity 'oauth.grpc.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" OAUTH_GRPC_HOST "$(get_properity 'oauth.grpc.host')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" MYSQL_PASSWORD "$(get_properity 'mysql.password')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" OAUTH_IMAGE "$(getImage image_version oauth)")

echo "${docker_compose_production}" > ./docker/oauth/docker-compose-production.yaml

docker-compose -f ./docker/oauth/docker-compose-production.yaml up -d
