#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh

chmod -R 0777 ./docker/etcd/data

docker_compose_production=$(cat ./docker/etcd/docker-compose.yaml)

docker_compose_production=$(replace_bracket "${docker_compose_production}" ETCD_IMAGE "$(getImage image_version etcd)")

echo "${docker_compose_production}" > ./docker/etcd/docker-compose-production.yaml

docker-compose -f ./docker/etcd/docker-compose-production.yaml up -d
