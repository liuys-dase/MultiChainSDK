#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh

rootdir="$(pwd)"

cd docker/baas-go/docset/conf || exit 0

replace_line_in_toml cfg.toml etcd.host "[\"http://etcd:2379\"]" --no-quoto

replace_line_in_toml cfg.toml grpc.port "$(get_properity 'docset.grpc.port')" --no-quoto

replace_line_in_toml cfg.toml grpc.host "$(get_properity 'docset.grpc.host')" --quoto

replace_line_in_toml cfg.toml http.port "$(get_properity 'docset.http.port')" --no-quoto

replace_line_in_toml cfg.toml http.host "$(get_properity 'docset.http.host')" --quoto

replace_line_in_toml cfg.toml gin.addr ":$(get_properity 'docset.gin.port')" --quoto

