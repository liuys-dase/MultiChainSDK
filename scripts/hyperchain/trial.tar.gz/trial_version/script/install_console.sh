#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh

docker_compose_production=$(cat ./docker/console/docker-compose.yaml)

docker_compose_production=$(replace_bracket "${docker_compose_production}" CONSOLE_HTTP_PORT "$(get_properity 'console.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" CONSOLE_IMAGE "$(getImage image_version console)")

echo "${docker_compose_production}" > ./docker/console/docker-compose-production.yaml

docker-compose -f ./docker/console/docker-compose-production.yaml up -d