#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh

custom_shell=$(cat ./docker/stdb/custom-template.sh)

custom_shell=$(replace_bracket "${custom_shell}" JSONRPC "$(get_properity 'flato.node1.jsonport')")

custom_shell=$(replace_bracket "${custom_shell}" GRPC "8081")

echo "${custom_shell}" > ./docker/stdb/custom.sh

docker_compose_production=$(cat ./docker/stdb/docker-compose.yaml)

docker_compose_production=$(replace_bracket "${docker_compose_production}" MYSQL_PASSWORD "$(get_properity 'mysql.password')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" STDB_GRPC_PORT "$(get_properity 'stdb.grpc.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" STDB_GRPC_HOST "$(get_properity 'stdb.grpc.host')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" STDB_HTTP_PORT "$(get_properity 'stdb.http.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" STDB_HTTP_HOST "$(get_properity 'stdb.http.host')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" STDB_WEBSOCKET_PORT "$(get_properity 'stdb.ws.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" STDB_WEBSOCKET_HOST "$(get_properity 'stdb.ws.host')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" HOST_IP "$(get_host_ip "$(get_properity 'global.network')")")

docker_compose_production=$(replace_bracket "${docker_compose_production}" STDB_IMAGE "$(getImage image_version stdb)")

echo "${docker_compose_production}" > ./docker/stdb/docker-compose-production.yaml

docker-compose -f ./docker/stdb/docker-compose-production.yaml up -d
