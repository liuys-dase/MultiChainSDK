#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh

chmod -R 0777 ./docker/minio/data

docker_compose_production=$(cat ./docker/minio/docker-compose.yaml)

docker_compose_production=$(replace_bracket "${docker_compose_production}" MINIO_IMAGE "$(getImage image_version minio)")

echo "${docker_compose_production}" > ./docker/minio/docker-compose-production.yaml

docker-compose -f ./docker/minio/docker-compose-production.yaml up -d
