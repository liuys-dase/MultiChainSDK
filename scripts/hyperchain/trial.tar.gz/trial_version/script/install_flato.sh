#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh

WorkDir=$(pwd)

# echo "PWD=${WorkDir}"

# 节点初始化
cd ./script/flato
python3 -m main.deploy

cd ${WorkDir}
# echo "PWD=${WorkDir}"

# 读取模板
docker_compose_production=$(cat ./script/flato/pkg/docker-compose.yaml)

# 参数替换
docker_compose_production=$(replace_bracket "${docker_compose_production}" NODE1_JSONRPC_PORT "$(get_properity 'flato.node1.jsonport')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" NODE2_JSONRPC_PORT "$(get_properity 'flato.node2.jsonport')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" NODE3_JSONRPC_PORT "$(get_properity 'flato.node3.jsonport')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" NODE4_JSONRPC_PORT "$(get_properity 'flato.node4.jsonport')")

# 镜像替换
docker_compose_production=$(replace_bracket "${docker_compose_production}" FLATO_IMAGE "$(getImage image_version centos)")

cp ./script/flato/pkg/solc ./script/flato/prepare/solc

# 生成最终运行文件
echo "${docker_compose_production}" > ./script/flato/prepare/docker-compose-production.yaml

docker-compose -f ./script/flato/prepare/docker-compose-production.yaml up -d

