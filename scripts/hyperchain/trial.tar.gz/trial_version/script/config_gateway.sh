#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh

rootdir="$(pwd)"

cd docker/baas-go/gateway/conf || exit 0

replace_line_in_toml cfg.toml etcd.host "[\"http://etcd:2379\"]" --no-quoto

replace_line_in_toml cfg.toml grpc.port "$(get_properity 'gateway.grpc.port')" --no-quoto

replace_line_in_toml cfg.toml grpc.host "$(get_properity 'gateway.grpc.host')" --quoto

replace_line_in_toml cfg.toml http.port "$(get_properity 'gateway.http.port')" --no-quoto

replace_line_in_toml cfg.toml http.host "$(get_properity 'gateway.http.host')" --quoto

replace_line_in_toml cfg.toml traefik.forwardauth "[\"http://oauth:8080/api/v1.0/auth\"]" --no-quoto

replace_line_in_toml cfg.toml minio.addr "[\"$(get_host_ip "$(get_properity 'global.network')"):9000\"]" --no-quoto

replace_line_in_toml cfg.toml pushgateway.addr "[\"$(get_host_ip "$(get_properity 'global.network')"):9091\"]" --no-quoto

replace_line_in_toml cfg.toml prometheus.addr "[\"$(get_host_ip "$(get_properity 'global.network')"):9090\"]" --no-quoto

replace_line_in_toml cfg.toml mysql.master "$(get_host_ip "$(get_properity 'global.network')"):3306" --quoto
replace_line_in_toml cfg.toml mysql.slave "$(get_host_ip "$(get_properity 'global.network')"):3306" --quoto

replace_line_in_toml cfg.toml nats.addr "[\"$(get_host_ip "$(get_properity 'global.network')"):4222\"]" --no-quoto

replace_line_in_toml cfg.toml console.domain "$(get_host_ip "$(get_properity 'global.network')")" --quoto

