#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh

docker_compose_production=$(cat ./docker/traefik/docker-compose.yaml)

docker_compose_production=$(replace_bracket "${docker_compose_production}" TRAEFIK_IMAGE "$(getImage image_version traefik)")

echo "${docker_compose_production}" > ./docker/traefik/docker-compose-production.yaml

docker-compose -f ./docker/traefik/docker-compose-production.yaml up -d