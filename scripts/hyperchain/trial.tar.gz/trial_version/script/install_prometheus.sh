#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh

chmod -R 0777 ./docker/prometheus/prometheus/data

docker_compose_production=$(cat ./docker/prometheus/docker-compose.yaml)

docker_compose_production=$(replace_bracket "${docker_compose_production}" PROMETHEUS_IMAGE "$(getImage image_version prometheus)")
docker_compose_production=$(replace_bracket "${docker_compose_production}" PUSHGATEWAY_IMAGE "$(getImage image_version pushgateway)")

echo "${docker_compose_production}" > ./docker/prometheus/docker-compose-production.yaml

docker-compose -f ./docker/prometheus/docker-compose-production.yaml up -d
