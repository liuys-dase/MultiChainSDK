# !/usr/bin/env python
# -*- coding:utf-8 -*-

import ConfigParser
import sys
import os

# 使用系统库ConfigParser解析values.toml,读取请求配置项，返回对应的值 
# 请求 service.db.host
# 支持配置：最多几层目录查找values.toml配置文件，读取配置文件优先级
def readConfig():
  level = 2        # 最多找N级目录
  priority = True # 越外层优先级越高. True/False
  target = "values.toml"
  # 去掉python调用自己的参数
  if 'readConfig.py' in sys.argv[0]:
    sys.argv=sys.argv[1:]

  # 一层层往外搜索values.toml,  
  config_path = sys.path[0]  # py脚本所在目录
  bc = config_path.count('/') # 防止找到根目录

  # 目录往上返回level层
  while(level > 0 and bc > 1):
    level = level - 1 
    bc = bc - 1 
    config_path = os.path.dirname(config_path)
  
  # 找value.toml文件，放到list中
  values_list = []
  for path_name, dir, files_name in os.walk(config_path):
    for file in files_name:
      # 设置了优先级，找到就退出（剪枝）
      if len(values_list) > 0 and priority:
        break
      if os.path.isfile(os.path.join(path_name, file)) and file == target:
        values_list.append(os.path.join(path_name, file))
        

  if len(values_list) == 0:
    print 'can\'t find values.toml.'
    return 

  # 根据优先级
  if not priority:
    values_list.reverse()

  # print values_list[0]

  mk = sys.argv[0]
  i = mk.rfind('.')
  if i == -1:
    print 'can\'t find . in properity.'
    return

  cf = ConfigParser.ConfigParser()
  try:
    cf.read(values_list[0])
    val = cf.get(mk[:i], mk[i+1:])
    print val.strip('"')
  except BaseException, e:
    print ''

# 函数入口
if __name__=='__main__':
  if len(sys.argv) < 1:
    print 'argments error'
  else:
    readConfig()
