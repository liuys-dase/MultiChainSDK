#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh

modify_network "$1"