#!/usr/bin/env bash

function getScriptPath() {
  # 操作系统类型
  os_name=$(uname)

  # 脚本名称
  local bash_source_name=${BASH_SOURCE[0]}
  #echo "origin file path ==========> ${bash_source_name}"

  local script_file=''

  # Linux 系统通过 readlink 来获取脚本文件完整路径
  if [[ "${os_name}" == "Linux" ]]; then
    script_file=$(dirname "$(readlink -f "${bash_source_name}")")
  fi

  # macOS 系统（也可以通过 brew install coreutils 安装 greadlink 的方式解决）
  if [[ "${os_name}" == "Darwin" ]]; then
    # 如果以 / 开头则认为是绝对路径
    if [[ $(echo "${bash_source_name}" | awk '/^\//') == "${bash_source_name}" ]]; then
      script_file=${bash_source_name}
    else # 否则在脚本路径前面加上 当前路径
      script_file=$PWD/${bash_source_name}
    fi
    script_file=${script_file%\/*}
  fi

  echo "${script_file}"
}

EXEC_PATH="$(getScriptPath)"
sys="$(uname)"

# 例如：getImage image_version core
# 根据cfg文件，获取image_version下core的image地址
function getImage() {
  image=""
  image_start=0
  while read -r line || [[ -n ${line} ]]; do
    if [[ image_start -eq 1 ]]; then

      if [[ "${line:0:1}" == '#' ]]; then
        continue
      fi
      if [[ ${line:0:1} == '[' || ${line} == "" ]]; then
        break
      fi
      component="${line%% *}"
      if [[ $component == "$2" ]]; then
        image_quoto="${line##* }"
        image_quoto="${image_quoto%?}"
        image="${image_quoto:1}"
        break
      fi
    fi

    if [[ ${line} == "[$1]" ]]; then
      image_start=1
    fi
  done <cfg.toml
  echo "$image"
}

# toml中指定的标签下增加key=value 使用方法：add_line_in_toml cfg.toml db.host 127.0.0.1 --quoto
function add_line_in_toml() {
  file="$1"
  array=${2//./ }
  key1=$(echo "${array[@]}" | awk -F " " '{print $1}')
  key2=$(echo "${array[@]}" | awk -F " " '{print $2}')
  value="$3"
  quoto="$4"
  #shellcheck disable=SC2002
  n1=$(cat "$file" | grep -n "\[$key1\]" | awk -F ":" '{print $1}')
  n11=$((n1 + 1))
  if [[ "$quoto" == "--quoto" ]]; then
    sed -i "${n11}i$key2 = \"$value\"" "$file"
  else
    sed -i "${n11}i$key2 = $value" "$file"
  fi
}

# 替换toml中指定的key；单个key 使用方法：modify_in_toml cfg.toml db 127.0.0.1 --quoto
function modify_in_toml() {
  file="$1"

  key="${2}"

  value="$3"
  quoto="$4"
  #shellcheck disable=SC2002
  lineNo="$(cat "$file" | grep -n "$key" | awk -F ":" '{print $1}')"

  if [[ "$quoto" == "--quoto" ]]; then
    if [[ "$sys" == "Darwin" ]]; then
      #shellcheck disable=SC2086
      #shellcheck disable=SC1003
      sed -i '' ''${lineNo}'c\'$'\n'$key' = \"'$value'\"
      ' "$file"
    else
      sed -i "${lineNo}c$key = \"$value\"" "$file"
    fi
  else
    if [[ "$sys" == "Darwin" ]]; then
      #shellcheck disable=SC2086
      #shellcheck disable=SC1003
      sed -i '' ''${lineNo}'c\'$'\n'$key' = '$value'
      ' "$file"
    else
      sed -i "${lineNo}c$key = $value" "$file"
    fi
  fi
}

# 替换toml中指定的key；使用方法：replace_line_in_toml cfg.toml db.host 127.0.0.1 --quoto
function replace_line_in_toml() {
  file="$1"

  key1=${2%.*}
  key2=${2##*.}

  value="$3"
  quoto="$4"

  if [[ "$key2" == "" ]]; then
    modify_in_toml "$file" "$key1" "$value" "$quoto"
    return
  fi

  #shellcheck disable=SC2002
  n1=$(cat "$file" | grep -n "\[$key1\]" | awk -F ":" '{print $1}')
  lineNo=0
  #shellcheck disable=SC2002
  #shellcheck disable=SC2013
  for n2 in $(cat "$file" | grep -n "$key2" | awk -F ":" '{print $1}'); do
    if [[ $n2 -gt $n1 ]]; then
      line=$(sed -n "$n2,${n2}p" "$file")
      if [[ ${line:0:1} == "#" ]]; then
        continue
      fi
      lineNo=$n2
      break
    fi
  done

  if [[ "$quoto" == "--quoto" ]]; then
    if [[ "$sys" == "Darwin" ]]; then
      #shellcheck disable=SC2086
      #shellcheck disable=SC1003
      sed -i '' ''${lineNo}'c\'$'\n'$key2' = \"'$value'\"
      ' "$file"
    else
      sed -i "${lineNo}c$key2 = \"$value\"" "$file"
    fi
  else
    if [[ "$sys" == "Darwin" ]]; then
      #shellcheck disable=SC2086
      #shellcheck disable=SC1003
      sed -i '' ''${lineNo}'c\'$'\n'$key2' = '$value'
      ' "$file"
    else
      sed -i "${lineNo}c$key2 = $value" "$file"
    fi
  fi
}

# 获取values.toml中的kv
function get_properity() {
  key=$1
  python "${EXEC_PATH}"/readConfig.py "${key}"
}

# 替换{{ TEST }}
# 用法：replace_bracket yaml TEST 121
function replace_bracket() {
  f=$1
  IMAGE_TAG=$2
  IMAGE_VALUE=$3
  a=${f//\{\{ ${IMAGE_TAG} \}\}/${IMAGE_VALUE}}

  echo "$a"
}

# get_host_ip en0（网卡）
function get_host_ip() {
  if [[ "$sys" == Darwin ]]; then
    #shellcheck disable=SC2005
    echo "$(ifconfig "$1" | grep broadcast | awk '{print $2}')"
  else
    #shellcheck disable=SC2005
    echo "$(ifconfig "$1" | grep broadcast | awk '{print $2}')"
  fi
}

# 修改网卡
function modify_network(){
  replace_line_in_toml values.toml global.network "$1" --quoto
}

# 修改网卡
function remove_server(){
  docker rmi --force "$(docker images | grep "$1" | awk '{print $3}')"
  print_green "删除镜像${1}成功"
}

RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

function print_blue() {
  printf "${BLUE}%s${NC}\n" "$1"
}

function print_green() {
  printf "${GREEN}%s${NC}\n" "$1"
}

function print_red() {
  printf "${RED}%s${NC}\n" "$1"
}
