#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh

docker_compose_production=$(cat ./docker/meshsec/docker-compose.yaml)

docker_compose_production=$(replace_bracket "${docker_compose_production}" MYSQL_PASSWORD "$(get_properity 'mysql.password')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" MESHSEC_GRPC_PORT "$(get_properity 'meshsec.grpc.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" MESHSEC_GRPC_HOST "$(get_properity 'meshsec.grpc.host')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" MESHSEC_HTTP_PORT "$(get_properity 'meshsec.http.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" MESHSEC_HTTP_HOST "$(get_properity 'meshsec.http.host')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" MESHSEC_NODE_PORT "$(get_properity 'meshsec.node.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" MESHSEC_NODE_HOST "$(get_properity 'meshsec.node.host')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" MESHSEC_IMAGE "$(getImage image_version meshsec)")

echo "${docker_compose_production}" > ./docker/meshsec/docker-compose-production.yaml

docker-compose -f ./docker/meshsec/docker-compose-production.yaml up -d
