#!/bin/bash

/opt/flato/tools/bin/flato stop
