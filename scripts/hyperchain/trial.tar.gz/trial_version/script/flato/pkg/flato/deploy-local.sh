#!/bin/bash

install_root=$(cd $(dirname ${BASH_SOURCE[0]}); pwd)

flato_script_path=$install_root/tools/bin/flato
monitor_script_path=$install_root/tools/bin/fltMonitor

validateDir() {
  rc=$(echo $target_path | grep -E "^.{0,2}/*.*")
  if [ $? -eq 0 ]; then
      if [ -d $target_path ] && [ $(du -s $target_path | awk '{print $1'}) -gt 4 ]; then
      if [ "$target_path" != "." -a "$install_root" != "$target_path" ]; then
        now=`date '+%Y-%m-%d-%H-%M-%S'`
        echo -e "\033[33m$target_path is not empty, please move data to a backup directory before installing ... \033[0m"
        exit 39
        # plan b: backup to a directory automatically
        #mv $target_path $HOME/flato-backup-$now || exit $?
        #echo -e "\033[32mdone\033[0m"
      fi
    fi

    echo -n -e "Make a clean directory $target_path ..."
    mkdir -p $target_path
    if [ $? -eq 0 ]; then
      echo -e "\033[32mdone\033[0m"
    else
      echo -e "\033[33mDeployment exited\033[0m"
      exit 1
    fi


    actual_path=$(cd $target_path; pwd)
    sed -i "s,EXEC_PATH=.*,EXEC_PATH=$actual_path,g" $flato_script_path
    sed -i "s,EXEC_PATH=.*,EXEC_PATH=$actual_path,g" $monitor_script_path

    echo "#!/bin/bash" > $install_root/start.sh
    echo "$actual_path/tools/bin/flato start" >> $install_root/start.sh

    echo "#!/bin/bash" > $install_root/stop.sh
    echo "$actual_path/tools/bin/flato stop" >> $install_root/stop.sh

    echo "#!/bin/bash" > $install_root/restart.sh
    echo "$actual_path/tools/bin/flato restart" >> $install_root/restart.sh

    echo "#!/bin/bash" > $install_root/status.sh
    echo "$actual_path/tools/bin/flato status" >> $install_root/status.sh

    echo "#!/bin/bash" > $install_root/check.sh
    echo "$actual_path/tools/bin/flato check" >> $install_root/check.sh

    # Make scripts executable
    chmod +x $flato_script_path
    chmod +x $monitor_script_path
    chmod +x $install_root/start.sh
    chmod +x $install_root/stop.sh
    chmod +x $install_root/restart.sh
    chmod +x $install_root/status.sh
    chmod +x $install_root/check.sh

    # Make binary executable
    chmod +x $install_root/flato
  else
    help
  fi
}

setup() {

  if [ "$target_path" != "." -a "$install_root" != "$target_path" ]; then
    cp -r $install_root/* $target_path
  fi

  echo
  echo -e "\033[32mflato has been successfully installed in: $actual_path \033[0m"
  echo
  echo "Please run these commands to start flato process:"
  echo -e "\033[32mcd $actual_path \033[0m"
  echo -e "\033[32m./start.sh \033[0m"
}

help() {
  echo
  echo "  Usage: ${BASH_SOURCE[0]} {-d} [-h]"
  echo "   -d|--directory {dir_path}  flato installation directory"
  echo "   -h|--help                  display this help"
  echo
  echo "   Example1: "
  echo "     ${BASH_SOURCE[0]} -d /opt/flato"
  echo "   Example2: "
  echo "     ${BASH_SOURCE[0]} -d ./"
  echo
  exit 1
}

if [ $# -gt 1 ]; then
  while [ $# -gt 0 ]; do
    case $1 in
      -d|--directory)
        shift
        if [ $# -gt 0 ]; then
          target_path=$(echo $1 | tr -s /)
          target_path=${target_path%%/}
          shift
        else
          help
        fi
        ;;
      -h|--help)
        help
        ;;
      *)
        echo "unsupported options"
        help
        exit 1
        ;;
    esac
  done
else
  help
fi

validateDir
setup
