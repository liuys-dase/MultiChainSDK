# coding=UTF-8

import os
import toml
import time
import json
import requests, math
from termcolor import colored
from obj.case import Case
from obj.case import ChaosCase
from obj.conf_test import ConfTest
import prometheus_client.parser as prometheus
import utils.util as util
import log.Logger as Logger

logger = Logger.init_log()


def post_RPC(url, method, params, timeout=60, ns="global"):
    '''
    :param url:
    :param method:
    :param params:
    :param timeout: 接口返回的超时时间
    :return:
    '''
    data = {"jsonrpc": "2.0", "method": method, "namespace": ns, "id": 1, "params": params}
    json_data = json.dumps(data)
    logger.debug("curl " + url + " --data '" + json_data + " '")
    response = requests.post(url=url, data=json_data, timeout=timeout).json()
    logger.info(response)
    return response


