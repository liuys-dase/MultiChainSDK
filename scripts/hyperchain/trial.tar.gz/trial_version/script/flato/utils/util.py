# coding=UTF-8

import termcolor
import toml

import os
import toml
import time
import random

from termcolor import colored
from obj.case import Case
from obj.case import ChaosCase
from obj.case import StableCase
from obj.conf_test import ConfTest
from log.Logger import init_log

logger = init_log()


def load_conf(conf_path):
    if not os.path.exists(conf_path):
        logger.error("########### %s doesn't exist,please check!!!!#######" % (conf_path))
        return
    with open(conf_path, 'r') as f:
        config = toml.loads(f.read())
        # print(config)
        return config


def load_global_conf(conf_path):
    global_config = load_conf(conf_path)
    global_config["blockchain"]["name"] = global_config["blockchain"]["name"] \
        if "name" in global_config["blockchain"] else "flato"
    if "jsonrpc_start" not in global_config["blockchain"]:
        global_config["blockchain"]["jsonrpc_start"]=8080
    if "websocket_start" not in global_config["blockchain"]:
        global_config["blockchain"]["websocket_start"] = 10000
    if "jvm_start" not in global_config["blockchain"]:
        global_config["blockchain"]["jvm_start"] = 20000
    if "ledger_start" not in global_config["blockchain"]:
        global_config["blockchain"]["ledger_start"] = 30000
    if "grpc_start" not in global_config["blockchain"]:
        global_config["blockchain"]["grpc_start"] = 40000
    global_config["blockchain"]["env"] = global_config["blockchain"]["env"] \
        if "env" in global_config["blockchain"] else "server"

    if "network" not in global_config["blockchain"]:
        global_config["blockchain"]["network"] = {}
        for i, ip in enumerate(global_config["blockchain"]["server"]["ips"]):
            name = "node" + str(i + 1)
            global_config["blockchain"]["network"][name] = {"domain": "1", "addrs": {"1": ip + ":" + str(global_config["blockchain"]["grpc_start"] + i+1)}}

    if "ns_count" not in global_config["blockchain"]:
        global_config["blockchain"]["ns_count"] = 1
    ns = ["global"]
    for i in range(1, global_config["blockchain"]["ns_count"]):
        ns.append("ns" + str(i))
    global_config["blockchain"]["namespaces"] = ns
    if "config" not in global_config:
        global_config["config"] = {}
    if "local" not in global_config["blockchain"]:
        global_config["blockchain"]["local"] = {}

    # 初始化特殊的config配置
    if "at" not in global_config["config"]:
        global_config["config"]["at"] = []
    if "indexdb" not in global_config["config"]:
        global_config["config"]["indexdb"] = {}
    global_config["config"]["indexdb"]["enable"] = global_config["config"]["indexdb"]["enable"] \
        if "enable" in global_config["config"]["indexdb"] else False
    global_config["config"]["indexdb"]["active"] = global_config["config"]["indexdb"]["active"] \
        if "active" in global_config["config"]["indexdb"] else []
    if "tcert" not in global_config["config"]:
        global_config["config"]["tcert"] = False
    if "https" not in global_config["config"]:
        global_config["config"]["https"] = False
    if "file_mgr" not in global_config["config"]:
        global_config["config"]["file_mgr"] = False

    # 初始化Log配置
    if "log_level" not in global_config["config"]:
        global_config["config"]["log_level"] = {}
    modules = ["p2p", "flatodb", "eventhub", "executor", "buckettree", "radar", "private", "midware",
               "state", "node", "api", "nvp", "db", "execmgr", "filemgr", "syncmgr"] #没加consensus,consensus使用默认的INFO，->端豪要求
    # 初始化上述所有日志模块为NOTICE
    for module in modules:
        global_config["config"]["log_level"][module] = "NOTICE"
    global_config["config"]["log_level"]["consensus"] = "INFO"
    # 初始化指定日志模块为指定级别
    if "modules" in global_config["config"]["log_level"]:
        modules = global_config["config"]["log_level"]["modules"]
        for m in modules:
            global_config["config"]["log_level"][m] = global_config["config"]["log_level"]["default"]  # 设置指定modules为default
        del global_config["config"]["log_level"]["modules"]
        del global_config["config"]["log_level"]["default"]

    # 初始化debug配置
    if "debug" not in global_config["config"]:
        global_config["config"]["debug"] = {}
    global_config["config"]["debug"]["enable"] = global_config["config"]["debug"]["enable"] \
        if "enable" in global_config["config"]["debug"] else False
    global_config["config"]["debug"]["duration"] = global_config["config"]["debug"]["duration"] \
        if "duration" in global_config["config"]["debug"] else "1m"
    global_config["config"]["debug"]["metrics"] = global_config["config"]["debug"]["metrics"] \
        if "metrics" in global_config["config"]["debug"] else False
    global_config["config"]["debug"]["metrics_exp"] = global_config["config"]["debug"]["metrics_exp"] \
        if "metrics_exp" in global_config["config"]["debug"] else False

    # 是否备份 默认只备份error情况
    global_config["blockchain"]["server"]["backup"] = global_config["blockchain"]["server"]["backup"] \
        if "backup" in global_config["blockchain"]["server"] else "all"
    global_config["blockchain"]["server"]["backup_dir"] = global_config["blockchain"]["server"][
        "backup_dir"] if "backup_dir" in global_config["blockchain"]["server"] else "/backup"
    global_config["blockchain"]["local"]["fetch"] = global_config["blockchain"]["local"]["fetch"] \
        if "fetch" in global_config["blockchain"]["local"] else True
    global_config["blockchain"]["local"]["certs"] = global_config["blockchain"]["local"]["certs"] \
        if "certs" in global_config["blockchain"]["local"] else True
    global_config["blockchain"]["local"]["prepare_dir"] = global_config["blockchain"]["local"][
        "prepare_dir"] if "prepare_dir" in global_config["blockchain"]["local"] else os.path.abspath('.') + "/prepare"
    if global_config["blockchain"]["local"]["fetch"]:
        if "fetch_url" not in global_config["blockchain"]["local"]:
            global_config["blockchain"]["local"][
                "fetch_url"] = "http://nexus.hyperchain.cn/repository/hyper-test/binary/flato/Centos7/flato00.tar.gz"
        if "fetch_name" not in global_config["blockchain"]["local"]:
            global_config["blockchain"]["local"]["fetch_name"] = "flato0.0"

    # 交易版本号
    if "frigate" in global_config:
        if "target_ips" not in global_config["frigate"]:
            global_config["frigate"]["target_ips"] = "all"
        global_config["frigate"]["tx_version"] = global_config["frigate"]["tx_version"] \
            if "tx_version" in global_config["frigate"] else "2.5"
        global_config["frigate"]["fetch"] = global_config["frigate"]["fetch"] \
            if "fetch" in global_config["frigate"] else True
        if global_config["frigate"]["fetch"]:
            if "fetch_url" not in global_config["frigate"]:
                global_config["frigate"][
                    "fetch_url"] = "http://nexus.hyperchain.cn/repository/hyper-test/perfTest/frigate/frigate"
            if "fetch_name" not in global_config["frigate"]:
                global_config["frigate"]["fetch_name"] = "frigate"

        # 节点远程目录
        global_config["frigate"]["remote_dir"] = global_config["frigate"]["remote_dir"] \
            if "remote_dir" in global_config["frigate"] else "/frigate_dir"
        frigate_ips = global_config["frigate"]["ips"]
        user_names = global_config["frigate"]["user_name"] if "user_name" in global_config["frigate"] else []
        passwords = global_config["frigate"]["password"] if "password" in global_config["frigate"] else []
        if len(frigate_ips) > len(user_names):
            default_username=user_names[0] if len(user_names)>0 else "hyperchain"
            user_names.extend([default_username] * (len(frigate_ips) - len(user_names)))
            global_config["frigate"]["user_name"] = user_names
        if len(frigate_ips) > len(passwords):
            default_username=passwords[0] if len(passwords)>0 else "hyperchain"
            passwords.extend([default_username] * (len(frigate_ips) - len(passwords)))
            global_config["frigate"]["password"] = passwords

    # 初始化threshold
    if "threshold" not in global_config:
        global_config["threshold"] = {}
    global_config["threshold"]["success"] = global_config["threshold"]["success"] \
        if "success" in global_config["threshold"] else 0.98
    global_config["threshold"]["exit"] = global_config["threshold"]["exit"] \
        if "exit" in global_config["threshold"] else 0.98
    global_config["threshold"]["no_confirm_exit"] = global_config["threshold"]["no_confirm_exit"] \
        if "no_confirm_exit" in global_config["threshold"] else True
    global_config["threshold"]["binary_search_exit"] = global_config["threshold"]["binary_search_exit"] \
        if "binary_search_exit" in global_config["threshold"] else 0.05

    # 初始化user_name和password
    flato_ips = global_config["blockchain"]["server"]["ips"]
    user_names = global_config["blockchain"]["server"]["user_name"] \
        if "user_name" in global_config["blockchain"]["server"] else []
    passwords = global_config["blockchain"]["server"]["password"] \
        if "password" in global_config["blockchain"]["server"] else []

    if len(flato_ips) > len(user_names):
        default_username = user_names[0] if len(user_names) > 0 else "hyperchain"

        user_names.extend([default_username] * (len(flato_ips) - len(user_names)))
        global_config["blockchain"]["server"]["user_name"] = user_names
    if len(flato_ips) > len(passwords):
        default_pswd = passwords[0] if len(passwords) > 0 else "hyperchain"

        passwords.extend([default_pswd] * (len(flato_ips) - len(passwords)))
        global_config["blockchain"]["server"]["password"] = passwords

    # 初始化nvp配置
    global_config["nvp"] = global_config["nvp"] if "nvp" in global_config else {}
    global_config["nvp"]["ips"] = global_config["nvp"]["ips"] if "ips" in global_config["nvp"] else []
    global_config["nvp"]["tx_ratio"] = global_config["nvp"]["tx_ratio"] if "tx_ratio" in global_config["nvp"] else 0

    N = len(global_config["blockchain"]["server"]["ips"])
    for i, ip in enumerate(global_config["nvp"]["ips"]):
        name = "nvp" + str(i + 1)
        global_config["blockchain"]["network"][name] = {"domain": "1", "addrs": {"1": ip + ":" + str(50011 + i + N)}}
    # 初始化cvp配置
    global_config["cvp"] = global_config["cvp"] if "cvp" in global_config else {}
    global_config["cvp"]["ips"] = global_config["cvp"]["ips"] if "ips" in global_config["cvp"] else []
    for i, ip in enumerate(global_config["cvp"]["ips"]):
        name = "cvp" + str(i + 1)
        global_config["blockchain"]["network"][name] = {"domain": "1", "addrs": {
            "1": ip + ":" + str(50011 + i + N + len(global_config["nvp"]["ips"]))}}
    # 初始化source_dir
    if os.path.exists(global_config["blockchain"]["local"]["prepare_dir"]):
        logger.info("部署目录已存在，跳过")
        return global_config
    os.system("rm -rf " + global_config["blockchain"]["local"]["prepare_dir"])
    if global_config["blockchain"]["local"]["fetch"]:
        source_dir = wgetSource(global_config["blockchain"]["local"]["fetch_url"],
                                global_config["blockchain"]["local"]["prepare_dir"],
                                global_config["blockchain"]["local"]["fetch_name"]) + "/*"
        global_config["blockchain"]["local"]["source_dir"] = source_dir
    return global_config


def load_jmeter_conf(conf_path):
    jmeter_config = load_conf(conf_path)
    jmeter_config["jmeter"]["local"]["prepare_dir"] = jmeter_config["jmeter"]["local"][
        "prepare_dir"] if "prepare_dir" in jmeter_config["jmeter"]["local"] else os.path.abspath('.') + "/jmeter"
    jmeter_config["jmeter"]["romote_dir"] = jmeter_config["jmeter"]["romote_dir"] if "romote_dir" in jmeter_config[
        "jmeter"] else "/home/hyperchain/litesdkStress"
    return jmeter_config


def load_testcases(testcases_path, case_type="Case") -> list:
    '''
    # 加载testcases.toml，返回[case]
    :param testcases_path: 测试用例的配置文件路径
    :param case_type: 加载的测试用例类型 可选 'Case'  'ChaosCase' 'StableCase'
    :return: 加载完成后的测试用例对象数组

    【【注】】 有个小缺陷，在for循环遍历的时候，必须要使用特定名称才会出现代码提示，如stable_case,chaos_case
    '''
    cases = []
    testcases = load_conf(testcases_path)

    for case in testcases["case"]:
        # 初始化case_type对象 以后多了直接eval

        # case_obj = eval(case_type+'(case["case_name"], duration=case["duration"])')
        change_hash_size = False

        if "change_hash_size" in case: change_hash_size = case["change_hash_size"]  # change_hash_size必须写在初始化前
        case_obj = Case(case["case_name"], duration=case["duration"], change_hash_size=change_hash_size)

        # 'ChaosCase'属性初始化
        if case_type == "ChaosCase":
            case_obj = ChaosCase(case["case_name"], duration=case["duration"])
            case_obj.experiment = case["experiment"]
            case_obj.chaos_start = case["start_chaos"]
            case_obj.chaos_end = case["end_chaos"]
            case_obj.chaos_incre = case["increment_chaos"]
        # 'StableCase'属性初始化
        elif case_type == "StableCase":
            case_obj = StableCase(case["case_name"], duration=case["duration"])
            case_obj.tps_jitter = case["tps_jitter"]
            case_obj.duration_jitter = case["duration_jitter"]
            case_obj.interval_time = case["interval_time"]
            case_obj.interval_time_jitter = case["interval_time_jitter"]
        # Case 属性初始化
        if "tps" in case: case_obj.tps = case["tps"]
        if "size" in case: case_obj.size = case["size"]
        # 运行时start_tps+increment ,直到end_tps
        if "start_tps" in case: case_obj.start_tps = case["start_tps"]
        if "increment" in case: case_obj.increment = case["increment"]
        if "end_tps" in case: case_obj.end_tps = case["end_tps"]
        if "testplan" in case: case_obj.testplan = case["testplan"]
        if "sign" in case: case_obj.sign = case["sign"]
        if "simulate" in case: case_obj.simulate = case["simulate"]
        if "deploy" in case: case_obj.deploy = case["deploy"]
        if "size_incre_times" in case and case["size_incre_times"] > 1: case_obj.size_incre_times = case[
            "size_incre_times"]
        size_measure = case["size_measurement"] if "size_measurement" in case else 1024
        case_obj.size_start = int(case["size_start"] * size_measure) if "size_start" in case else 512
        case_obj.size_end = int(case["size_end"] * size_measure) if "size_end" in case else 512
        if "namespaces" in case:
            nmsp = []
            for i in case["namespaces"]:
                if i == 1:
                    nmsp.append("global")
                else:
                    nmsp.append("ns" + str(i - 1))
            case_obj.namespaces = nmsp

        if not case_obj.change_hash_size:
            case_obj.size_start = -1
            case_obj.size_end = -1
            case_obj.size_incre_times = -1
        cases.append(case_obj)
    logger.info("测试用例加载成功")
    return cases


def load_conf_tests(conf_tests_path):
    configs_to_test = load_conf(conf_tests_path)
    cases = []

    for configTest in configs_to_test["config"]:
        temp = []
        logger.debug("当前配置测试为：", configTest)
        for i in range(len(configTest["kvs"][0]["values"])):
            confs = []
            # 初始化

            for j in range(len(configTest["kvs"])):
                # 【精简配置】允许下面的配置只有一个值，比如下面的"100s"
                '''
                [[config]]
                conf_path="configuration/global/ns_dynamic.toml"
                [[config.kvs]]
                key="consensus.set.set_size"
                values=[1,2,5,10,15,25,30,50,100,200,400,500,600]
                [[config.kvs]]
                conf_path="configuration/global/ns_static.toml"
                key="consensus.set.set_timeout"
                values=["100s"]
                '''
                if len(configTest["kvs"][0]["values"]) > len(configTest["kvs"][j]["values"]) and len(
                        configTest["kvs"][j]["values"]) == 1:
                    ct = ConfTest(configTest["conf_path"], configTest["kvs"][j]["key"],
                                  configTest["kvs"][j]["values"][0])
                else:
                    ct = ConfTest(configTest["conf_path"], configTest["kvs"][j]["key"],
                                  configTest["kvs"][j]["values"][i])
                # 如果在kvs指定了conf_path,用kvs指定的。
                if "conf_path" in configTest["kvs"][j]:
                    ct.path = configTest["kvs"][j]["conf_path"]
                confs.append(ct)
            temp.append(confs)
        cases.append(temp)
    return cases


def load_diy_configs_from_dict(config_dict):
    configs = []
    if "diy" in config_dict["config"]:
        for config in config_dict["config"]["diy"]:
            logger.debug("当前配置为：", config)
            conf_obj = ConfTest(config["conf_path"], config["key"],
                                config["value"])
            configs.append(conf_obj)
        return configs
    else:
        return []


def change_config(path, key, value):
    logger.info("修改节点配置path=%s,key=%s,value=%s" % (path, key, value))
    content = load_conf(path)
    keys = key.split(".")
    set_value_recursive(content, keys, value)
    with open(path, 'w') as conf:
        toml.dump(content, conf)


def mkdir(path):
    if os.path.exists(path):
        os.system("rm -rf " + path)
    os.makedirs(path)


def mkdir_if_not_exists(path):
    if not os.path.exists(path):
        os.makedirs(path)


def now_str():
    return time.strftime('%Y-%m-%d_%H:%M:%S', time.localtime(time.time()))


def check_tps(result, threshold):
    if type(result["actual_tps"]) is int:
        actual_tps = [result["actual_tps"]]
    else:
        actual_tps = result["actual_tps"].split("/")
    for tps in actual_tps:
        if int(tps) / (result["tps"]) < threshold:
            logger.warning("实际tps/指定tps小于" + str(threshold) + "，退出当前测试用例执行")
            return False
    return True


def write_file(path, data):
    """写文件"""
    file_name = path.split("/")[-1]
    dir_path = path.replace("/" + file_name, "")

    if not os.path.exists(dir_path):
        os.makedirs(dir_path)

    with open(path, "w") as f:
        f.write(data)


def wgetSource(url, path, name):
    mkdir_if_not_exists(path)
    file_name = url.split("/")[-1]
    # 把原来的先删除掉
    os.system("cd " + path + " && rm -rf " + file_name + "*")
    cmd = "cd " + path + " && wget -q " + url
    logger.debug("wget 命令：" + cmd)
    os.system(cmd)
    if "tar.gz" in file_name or ".tg" in file_name:
        cmd = "cd " + path + " && tar -zxf " + file_name
        os.system(cmd)
    download_path = path + "/" + name
    logger.debug("wget download path:" + download_path)
    return download_path


def set_value_recursive(content, keys, val):
    if len(keys) == 1:
        content[keys[0]] = val
        logger.debug("节点配置修改成功")
        return content[keys[0]]
    else:
        if keys[0] not in content:
            content[keys[0]]={}
        content = content[keys[0]]
        keys = keys[1:]
        return set_value_recursive(content, keys, val)


def time_transfer(time_str):
    time = 0
    if "d" in time_str:
        time = int(time_str[:-1]) * 24 * 3600
    if "h" in time_str:
        time = int(time_str[:-1]) * 3600
    if "m" in time_str:
        time = int(time_str[:-1]) * 60
    if "s" in time_str:
        time = int(time_str[:-1])
    return time


def check_id(target_id, range):
    if target_id < 1 or target_id > range:
        logger.error(colored("Error,target id 为 %s ,range 为1 - %s" % (target_id, range), 'red'))
        return False
    return True


def load_conf_remote(client, conf_path):
    sftp_client = client.sftp
    remote_file = sftp_client.open(conf_path)  # 文件路径
    return toml.loads(bytes.decode(remote_file.read()))


def gen_conn_graph(items, type="random", rel=-1):
    """
        生成一个连通图，结果为：{"1": {"2": 1, "3": 2}}
        若元素为节点，1和2没有差别；
        若元素为域，其中1表示连接方式为非转发；2表示连接方式为转发；
    :param items:
    :param type:
    :param rel:
    :return:
    """
    graph = {}
    random.shuffle(items)
    if type == "star":
        star = random.choice(items)
        graph[star] = {star: 1}
    for i, item in enumerate(items):
        graph.setdefault(item, {item: 1})
        relation = random.randint(1, 2) if rel == -1 else rel
        if type == "ring":
            num = len(items)
            graph[item][items[(i + num + 1) % num]] = relation
        if type == "star":
            if item == star:
                continue
            graph[star][item] = relation
        if type == "random":
            r = random.randint(0, 1)
            if i > 0:
                conn = items[random.randint(0, i - 1)]
                if r:
                    graph[conn][item] = relation
                else:
                    graph[item][conn] = relation
    logger.debug("节点（域）连接关系：", graph)
    return graph


