# coding=UTF-8

import logging

from jinja2 import Environment, FileSystemLoader
import utils.util as util
import time,math,os
from selenium import webdriver
from termcolor import colored

logger = logging.getLogger("frigateDynamic.indexdb")


def __generate_html(statistic, starttime, template="template.html"):
    util.mkdir_if_not_exists("reports")
    stoptime=util.now_str()
    env = Environment(loader=FileSystemLoader('./templates'))
    template = env.get_template(template)
    report_name = "reports/report_"+stoptime+".html"
    with open(report_name, 'w+') as fout:
        html_content = template.render(start_time=starttime,
                                       stop_time=stoptime,
                                       statistic=statistic)
        fout.write(html_content)
        logger.info("测试报告生成...请在" + report_name + "中查看测试结果")


def statistics(details, global_config, notification="无",template="template.html",server_detail=False):
    if details is None or len(details) == 0:
        print(colored("性能测试报告数据为空，请检查！！！！！", 'red'))
        return
    print(colored("测试详细结果为：%s"%details,"green"))
    starttime = time.strftime('%Y-%m-%d_%H:%M:%S', time.localtime(time.time()))
    statistic = {"baseline_msg": "非性能基准测试", "baseline_results": [], "notification": notification}
    hosts = global_config["blockchain"]["server"]["ips"]
    logger.info("所有hosts为: %s", hosts)
    statistic["details"] = details
    results = __get_results_from_details(details)
    statistic["results"] = results
    # 生成html报告
    __generate_html(statistic, starttime,template=template)



def __get_results_from_details(details):
    ''' 根据details数据生成结论数据'''
    results={}
    for detail in details:
        key = detail["case_name"] + "_" + str(detail["hash_size"]) + "_" + detail["sign"] + "_" + detail["duration"]
        if detail["success"]=="success":
            results[key]=detail
        else:
            if key not in results or results[key]["success"]=="fail":
                results[key]=detail
    return results
