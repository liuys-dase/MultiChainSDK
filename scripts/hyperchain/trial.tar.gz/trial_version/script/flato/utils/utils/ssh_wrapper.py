# -*- coding: utf-8 -*-
#
# Copyright © 2017 Qulian Technologies Co., Ltd.  All rights reserved.
#
# Proprietary and confidential.  Unauthorized copying of this file, via
# any medium is strictly prohibited.
#
# 版权所有 © 2017 杭州趣链科技有限公司。保留所有权利。
# 专有和保密。严禁通过任何媒介对本文件进行未经授权的复制。
#
# @Time    : 2018/4/11 下午2:34
# @Author  : Xiaofeng Chen(Alfred)
# @Site    : http://www.hyperchain.cn/
# @File    : agile_conf_parser.py
# @Software: PyCharm

import logging
import os

import paramiko
import select
from termcolor import colored

# logger = logging.getLogger("paramiko")
# logger.setLevel(logging.WARNING)


class SSHWrapper(object):
    """A paramiko wrapper aim to execute shell commands or sftp protocol
    commands on remote host.
    """

    def __init__(self, ip_addr, port, username, password):
        """Initializate a ssh client object and a sftp client object.

        Args:
            ip_addr: A str type parameter. IP address or hostname of
                     remote host.
            port: A number type parameter stands to connection port.
            username: A str type parameter stands to connection username.
            password: A str type parameter stands to connection password.

        Returns:
            None.

        Raises:
            paramiko.AuthenticationException
            paramiko.BadHostKeyException
            paramiko.SSHException
            socket.error
        """
        self.ip_addr = ip_addr
        self.port = port
        self.username = username
        self.password = password

        self.client = paramiko.SSHClient()
        self.client.load_system_host_keys()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.client.connect(self.ip_addr,
                            port=self.port,
                            username=self.username,
                            password=self.password)

        self.sftp = self.client.open_sftp()
        self.logger = logging.getLogger("frigateDynamic.ssh")

    # def __del__(self):
    #     try:
    #         self.sftp.close()
    #         self.client.close()
    #     except AttributeError:
    #         pass

    def exec_cmd(self, cmd):
        # type: (object) -> object
        """Execute shell command on remote host. Will return immediately.

        Args:
            cmd: A str type parameter. Shell command to be executed.

        Returns:
            None.

        Raises:
            None.
        """
        self.logger.debug('\t\t远程执行命令:%s ' % cmd)
        return self.client.exec_command(cmd)

    def exec_cmd_wait(self, cmd):
        """Execute shell command on remote host. Wait for the command return.

        Args:
            cmd: A str type parameter.  Shell command to be executed.

        Returns:
            A number, for the exit status of remote.

        Raises:
            None.
        """
        # (_, stdout, stderr) = self.client.exec_command(cmd)
        #
        # # Should read stdout and stderr here to ignore deadlock.
        # #
        # # When stdout and/or stderr was redirected and the child process
        # # generates enough output to a pipe such that it blocks waiting
        # # for the OS pipe buffer to accept more data, it will lead to
        # # deadlock.
        # #
        # # See
        # # http://docs.python.org/2/library/subprocess.html#subprocess.Popen.wait
        # # for more details.
        # stdout.read()
        # logger.info(stdout)
        # stderr.read()
        # exit_code = stdout.channel.recv_exit_status()
        # return exit_code
        self.logger.debug('\t\t远程执行命令:%s ' % cmd)

        (stdin, stdout, stderr) = self.client.exec_command(cmd)
        channel = stdout.channel
        while True:
            # 判断退出的准备状态
            if channel.exit_status_ready():
                break
            try:
                rl, wl, el = select.select([channel], [], [])
                # if len(rl) > 0:
                #     recv = channel.recv(1024)
                #     print(recv)
            # 键盘终端异常
            except KeyboardInterrupt:
                self.logger.error("Caught control-C")
                channel.send("\x03")  # 发送 ctrl+c
                channel.close()
        exit_code = stdout.channel.recv_exit_status()
        stdout = bytes.decode(stdout.read()).replace("\x1b[0m", "").strip()
        return exit_code, stdout, stderr

    def exec_cmd_wait_with_pty(self, cmd):
        """Execute shell command on remote host. Wait for the command return.

        Args:
            cmd: A str type parameter. Shell command to be executed.

        Returns:
            A tuple, (exit_code, stdout, stderr), including the remote's
            exit status in number type, the remote's stdout and stderr
            in str type.

        Raises:
            None.
        """
        (stdin, stdout, stderr) = self.client.exec_command(cmd, get_pty=True)
        # stdin.write(self.password+'\n')
        # stdin.flush()
        channel = stdout.channel
        while True:
            # 判断退出的准备状态
            if channel.exit_status_ready():
                break
            try:
                rl, wl, el = select.select([channel], [], [])
                if len(rl) > 0:
                    recv = channel.recv(1024)
                    self.logger.debug(recv)
            # 键盘终端异常
            except KeyboardInterrupt:
                self.logger.error("Caught control-C")
                channel.send("\x03")  # 发送 ctrl+c
                channel.close()

        exit_code = stdout.channel.recv_exit_status()
        return exit_code, stdout, stderr

    def sftp_get(self, remote_file, local_file):
        """Copy a remote file to local host. Wait for it's finish.

        Args:
            remote_file: A str type parameter. Full path of a remote file.
            local_file: A str type parameter. Full path of destination
                        local file.

        Returns:
            None.

        Raises:
            None.
        """
        self.sftp.get(remote_file, local_file)

    def sftp_put(self, local_file, remote_file):
        """Send a local file a to remote. Wait for it's finish.

        Args:
            local_file: A str type parameter. Full path of local file.
            remote_file: A str type parameter. Full path of destination
                         remote file.

        Returns:
            None.

        Raises:
            None.
        """
        self.sftp.put(local_file, remote_file)

    def dir_exists(self, path):
        """os.path.exists for paramiko's SCP object
        """
        try:
            self.sftp.stat(path)
        except IOError as e:
            if 'No such file' in str(e):
                return False
            raise
        else:
            return True

    def sftp_make_dir(self, path, ignore_existing=False):
        """create remote directory

        :param path: 
        :return: 
        """
        try:
            self.sftp.mkdir(path)
        except IOError:
            if ignore_existing:
                pass
            else:
                raise

    def sftp_put_dir(self, source, target):
        """Uploads the contents of the source directory to the target path. The
            target directory needs to exists. All subdirectories in source are 
            created under target.
        """
        for item in os.listdir(source):
            if os.path.isfile(os.path.join(source, item)):
                self.sftp_put(os.path.join(source, item), '%s/%s' % (target, item))
            else:
                self.sftp_make_dir('%s/%s' % (target, item), ignore_existing=True)
                self.sftp_put_dir(os.path.join(source, item), '%s/%s' % (target, item))

