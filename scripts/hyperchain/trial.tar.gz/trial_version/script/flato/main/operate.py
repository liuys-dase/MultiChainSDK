from classes.Factory import get_platform
import utils.util as util
import argparse,logging
from log.Logger import init_log
init_log()
logger = logging.getLogger("frigateDynamic.operate_node")
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='测试')
    parser.add_argument('--global_config', type=str, default='conf/flato.toml', help='全局配置路径')
    parser.add_argument('--ids', type=str, default='3,5,6', help="要操作的节点id,如1,2,3")
    parser.add_argument('--type', type=str, default='vp',help="节点类型，vp/nvp")
    parser.add_argument('--op_code', type=str, default='restart', help='要进行的操作，start/stop')
    args = parser.parse_args()
    global_config = args.global_config
    ids=args.ids
    type=args.type
    op_code=args.op_code
    config = util.load_global_conf(global_config)
    blockchain = get_platform(config)
    nodes_to_op=[]
    ids=str.split(ids,",")

    if type=="vp":
        for id in ids:
            for node in blockchain.nodes:
                if node.id == int(id):
                    nodes_to_op.append(node)
    elif type == "nvp":
        for id in ids:
            for node in blockchain.nvps:
                if node.id - len(blockchain.nodes) ==  int(id):
                    nodes_to_op.append(node)
    if op_code=="stop":
        for blockchain_node in nodes_to_op:
            blockchain_node.stop()
    if op_code=="start":
        for blockchain_node in nodes_to_op:
            blockchain_node.start()
    if op_code=="restart":
        for blockchain_node in nodes_to_op:
            blockchain_node.stop()
            blockchain_node.start()
    if op_code == "nodes":
        vps,nvps=blockchain.get_all_nodes_in_blockchain()
        logger.critical("当前全部节点有%s个"%(len(vps)+len(nvps)))
        for vp in vps:
            logger.debug("%s : %s "%(vp,vps[vp]))
        for nvp in nvps:
            logger.debug("%s : %s "%(nvp,nvps[nvp]))




