from classes.Factory import get_platform
import utils.util as util
import argparse
import logging

from log.Logger import init_log
init_log()
logger = logging.getLogger("frigateDynamic.deploy")

#执行方法： python -m main.deploy  --global_config="conf/global.toml"
if __name__ == '__main__':
    logger.info("deploy.main...")
    parser = argparse.ArgumentParser(description='测试')
    logger.info("deploy.main1...")
    parser.add_argument('--global_config', type=str, default='conf/flato.toml', help='全局配置路径')
    args = parser.parse_args()
    logger.info("deploy.main2...")
    global_config = args.global_config
    logger.info("deploy.main3...")
    config = util.load_global_conf(global_config)
    logger.info("deploy.main4...")
    blockchain = get_platform(config)
    logger.info("blockchain.prepare_nodes_locally...")
    blockchain.prepare_nodes_locally()




