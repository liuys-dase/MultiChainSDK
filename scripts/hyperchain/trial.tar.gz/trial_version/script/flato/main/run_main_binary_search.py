# coding=UTF-8
import utils.report as report
import utils.util as util
import argparse,logging
from log.Logger import init_log
from classes.runner import Runner

# 执行方法： python -m main.run_main_binary_search --testsuite="testsuites/standard.toml" --global_config="conf/global.toml"
if __name__ == '__main__':

    logger=init_log()
    # logger = logging.getLogger("rr.run_main_binary_search")
    parser = argparse.ArgumentParser(description='测试')
    parser.add_argument('--testsuite', type=str, default='testsuites/5m_basic.toml', help='测试套件路径')
    parser.add_argument('--global_config', type=str, default='conf/flato.toml', help='全局配置路径')
    parser.add_argument('-r', type=str, default='inc', help='二分查找')
    parser.add_argument('-n', type=int, default=1, help='jenkins build number')

    args = parser.parse_args()
    testcases = util.load_testcases(args.testsuite)
    config = util.load_global_conf(args.global_config)
    runner = Runner(testcases, config, args.n)
    results=[]
    if args.r=="bi":
        results = runner.run_binary_search()
    elif args.r=="inc":
        while True:
            results+=runner.run_increment(background=[False,"metrics"])
    # logger.info("执行正常结束：results: %s", results)
    report.statistics(results,config,config["blockchain"]["local"]["source_dir"])



