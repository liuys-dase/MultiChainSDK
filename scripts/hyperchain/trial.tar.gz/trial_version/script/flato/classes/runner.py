# coding=UTF-8
import logging,traceback
from classes.Factory import get_platform
from classes.frigate import Frigate
import utils.util as util
from concurrent import futures
import time
from log.Logger import init_log
class Runner(object):
    def __init__(self,testsuite,global_config,build_number=1):
        self.testcases = testsuite
        self.config = global_config
        self.build_number = build_number
        self.logger = logging.getLogger("frigateDynamic.runner")
        self.frigate = Frigate(self.config)
        self.blockchain = get_platform(self.config)
        with futures.ThreadPoolExecutor(2) as executor:
            f=executor.submit(self.frigate.upload_frigate())

    def run_binary_search(self,config_test=None,syncChain={},block_msg=False):
        '''
        二分查找
        退出规则为binary_search_exit设定的值，如设定0.03,则表示当当前tps与上一次查找的tps之间 ，误差不超过0.03时，退出。
        :return:
        '''
        try:
            results=[]
            self.logger.info("开始执行二分查找..")
            binary_search_exit = self.config["threshold"]["binary_search_exit"]
            for testcase in self.testcases:
                self.logger.info("当前测试用例为：%s", testcase)
                size_start = testcase.size_start
                size_end = testcase.size_end
                while size_start <= size_end:
                    start_tps = testcase.start_tps
                    end_tps = testcase.end_tps
                    while start_tps <= end_tps:
                        if (end_tps - start_tps) / start_tps < binary_search_exit:
                            self.logger.info("二分查找结束，start_tps=%s,end_tps=%s"%(start_tps,end_tps))
                            break
                        mid_tps = int((start_tps + end_tps) / 2)
                        testcase.tps=mid_tps
                        testcase.size=size_start
                        result=self.deploy_and_run_frigate(testcase,config_test,syncChain,block_msg)
                        result["build_number"] = self.build_number
                        results.append(result)
                        threshold = self.config["threshold"]["exit"]
                        if not util.check_tps(results[-1], threshold):
                            end_tps = mid_tps
                        else:
                            start_tps = mid_tps
                    # 当不需要修改size时，size_start=size_end=-1,size_incre_times=-1可以正常退出while
                    size_start = size_start * testcase.size_incre_times
                    size_start = int(size_start)
            self.logger.info("执行正常结束")
            return results
        except Exception:
            self.logger.error("traceback.print_exc():%s",traceback.print_exc())
            self.logger.error("执行中发生异常，请检查")
            return results


    def run_increment(self, config_test=None,background=[False,"syncChain","args"],block_msg=True):
        '''
         递增跑，从start_tps跑到end_tps，每次增加testcase.increment
         :return:
         '''
        try:
            results=[]
            self.logger.info("开始执行递增测试..")
            for testcase in self.testcases:
                self.logger.info("当前测试用例为：%s", testcase)
                size_start = testcase.size_start
                size_end = testcase.size_end
                while size_start <= size_end:
                    start_tps = testcase.start_tps
                    while start_tps <= testcase.end_tps:
                        testcase.tps = start_tps
                        testcase.size = size_start
                        result=self.deploy_and_run_frigate(testcase,config_test,background,block_msg)
                        results.append(result)
                        threshold = self.config["threshold"]["exit"]
                        if not util.check_tps(result, threshold):
                            break
                        start_tps += testcase.increment
                    # 当不需要修改size时，size_start=size_end=-1,size_incre_times=-1可以正常退出while
                    size_start = size_start * testcase.size_incre_times
                    size_start = int(size_start)
            self.logger.info("执行正常结束")
            return results
        except Exception:
            self.logger.error("traceback.print_exc():%s",traceback.print_exc())
            self.logger.error("执行中发生异常，请检查")
            return results


    def deploy_and_run_frigate(self,testcase,config_test,background,block_msg=False):
        ''' 公共代码抽出
        :param config_test:
        :param testcase:
        :return: result
        '''
        if self.blockchain.deploy(config_test):  # 每次测试需要重新部署Flato
        # if True:
            if len(background)!=0 and background[0]:
                fs = self.frigate.run_multi_frigates(testcase, background=True)  # 后台跑frigate
                if background[1]== "syncChain": #进行syncChain的情况
                    self.logger.debug("syncChain ...")
                    syncChain=background[2]
                    if "timeout" not in syncChain:
                        syncChain["timeout"] = util.time_transfer(testcase.duration)*2
                    if "sleep_time" not in syncChain: #没指定sleep_time就默认等frigate跑完再syncChain
                        syncChain["sleep_time"]=util.time_transfer(testcase.duration)+60 #+60确保frigate执行完成
                    print("sleep %s "%syncChain["sleep_time"])
                    time.sleep(syncChain["sleep_time"])
                    sync_results = self.blockchain.specify_node_to_syncchain(syncChain["node_id"],
                                                                         namespaces=syncChain["namespaces"],
                                                                         timeout=syncChain["timeout"])
                    static={}
                    static['syncChain'] = sync_results
                result = self.frigate.get_frigate_result(testcase, fs) #获取frigate结果
                result["static"] = static
            else: #不进行syncChain的情况
                result = self.frigate.run_multi_frigates(testcase)
                static = self.blockchain.get_blockchain_msg(block_msg=block_msg)
                result["static"] = static
            result["monitor"]={"description":""}
            self.blockchain.destroy()  # 清除flato
            return result