# coding=UTF-8
import logging

from obj.node import Node
from termcolor import colored

import time
import random
import datetime
import utils.util as util
import utils.web_api as web

ipc = "-s --ipc=hpc_1.ipc --nit --cmd="


class BlockchainNode(Node):
    def __init__(self, ip, id, remote_dir, chain_name="flato", node_type="node", username="hyperchain",
                 password="hyperchain", name="",jsonrpc_start=8080,grpc_start=40000):
        # 对于节点而言 id 是用来标志端口次序的
        # 操作节点用 host
        super().__init__(ip, id, remote_dir, node_type, username, password, name)
        self.chain_name = chain_name
        self.logger = logging.getLogger("frigateDynamic.BlockchainNode")
        self.jsonrpc_port=jsonrpc_start+id
        self.grpc_port=grpc_start+id
        self.set_url()
    def set_url(self):
        self.url = "http://" + self.ip + ":" + str(self.jsonrpc_port)


    def start(self):
        self.logger.debug("正在启动节点%s..." % self.host)
        docker_pre = ""
        docker_suf = ""
        # 若name不为空，则需要在容器中执行节点启动的命令
        if self.name != "":
            docker_pre = "docker exec -d %s bash -c '" % self.name
            docker_suf = "'"
            time.sleep(random.randint(0, 15))

        self.client.exec_cmd("%scd %s && chmod +x %s && ./%s >> %s.log 2>&1 &%s" %
                             (docker_pre, self.node_dir, self.chain_name, self.chain_name, self.host, docker_suf))

    def stop(self):
        self.logger.debug("正在停止节点%s..." % self.host)
        docker_pre = ""
        docker_suf = ""
        # 若name不为空，则需要在容器中执行节点启动的命令
        if self.name != "":
            docker_pre = "docker exec -d %s bash -c '" % self.name
            docker_suf = "'"
        kill_by_port="netstat -tnlp | grep :%s|awk '{print$7}'|awk -F '/' '{print $1}' | xargs kill -9" % self.grpc_port
        self.client.exec_cmd_wait(
            "%s %s %s" % (
                docker_pre, kill_by_port ,docker_suf))

    def delete_data(self):
        self.logger.debug("正在删除%s节点的数据" % str(self.host))
        self.client.exec_cmd_wait("cd %s && rm -rf namespaces/%s/data/public " % (self.node_dir, self.namespace))

    def get_data_size(self):
        code, out, err = self.client.exec_cmd_wait(
            "cd %s && du -sh namespaces/%s/data/public | awk '{print $1}'" % (self.node_dir, self.namespace))
        self.logger.debug("当前data/public目录大小为:" + out)
        return out

    def backup(self, backup_dir=""):
        if backup_dir == "":
            backup_dir = "/".join(self.node_dir.split("/")[:-1]) + "/backup/" + self.host
        if not self.client.dir_exists(backup_dir):
            self.client.exec_cmd_wait("mkdir -p " + backup_dir)
        # self.delete_data()
        cp_cmd = "cp -r " + self.node_dir + "/*  " + backup_dir
        self.logger.info("正在备份节点：%s %s %s", self.host, " ", cp_cmd)
        self.client.exec_cmd_wait(cp_cmd)

    def block_getChainHeight(self):
        return self.__node_query_return_int("block_getChainHeight")

    def tx_getTransactionsCount(self):
        return self.__node_query_return_int("tx_getTransactionsCount")

    def __node_query_return_int(self, method_name, timeout=5):
        response = web.post_RPC(self.url, method_name, [], timeout=2, ns=self.namespace)
        try:
            if "count" in response["result"]:
                return int(response["result"]["count"], 16)
            else:
                return int(response["result"], 16)
        except:
            self.logger.warning("%s调用%s接口发生异常，将会在1秒后重试" % (self.host, method_name))
            time.sleep(1)
            timeout -= 1
            if timeout == 0:
                self.logger.warning("查询超时，集群状态不正常或开启了tcert或https，请检查")
                return -1
            return self.__node_query_return_int(method_name, timeout)

    def check_data_size(self, size="50G", timeout=3600 * 24):
        size_int = int(size[:-1])
        measure = size[-1:]
        times = 0
        while True:
            times += 1
            out = self.get_data_size()
            self.logger.debug(
                colored("第" + str(times) + "次检查，当前" + self.namespace + "/data/public目录大小为:" + out + ",目标大小为:" + size),
                'yellow')
            if out.endswith(measure):
                act_size = float(out[:-1])
                if act_size >= size_int:
                    break
                if timeout < 0:
                    self.logger.debug(colored("数据量在超时时间%s内无法达到%s，check_data_size失败" % (timeout, size), 'red'))
            timeout -= 5
            time.sleep(5)  # 每5秒check一次

    def get_states(self, retry_times=10, nmsp="global"):
        """
            调用node_getNodeStates接口，获取集群状态
        :param retry_times: 重试的次数
        :param id: 查询的节点id
        :return:
        """
        try:
            self.logger.info('向%s查询节点状态...' % self.host)
            response = web.post_RPC(self.url, "node_getNodeStates", [], timeout=3, ns=nmsp)
            if 'result' in response:
                return response
            else:
                retry_times -= 1
                if retry_times < 0:
                    self.logger.error('获取节点状态失败，retry times=%s，退出' % retry_times)
                    return None
                time.sleep(3)
                return self.get_states(retry_times=retry_times, nmsp=nmsp)
        except:
            retry_times -= 1
            if retry_times == 0:
                return None
            self.logger.warning("获取节点状态失败发生异常，进行重试")
            time.sleep(8)
            return self.get_states(retry_times=retry_times, nmsp=nmsp)

    def sync_chain_return_time(self, timeout=3600 * 24):
        '''
        :param timeout:超时时间
        :return: syncChain花费的时间和syncChain的tps
        '''
        self.logger.debug("正在进行syncChain ,namespace=%s" % self.namespace)
        target_id = self.id % 4  # 后一个节点
        start_timeout = 120
        interval = 3
        while True:
            if 'TIMEOUT' in self.get_states(nmsp=self.namespace)['result'][target_id]['status']:
                if start_timeout < 0:
                    return -2, -2, self.namespace
            if self.get_states(nmsp=self.namespace)['result'][self.id % 4]['status'] == 'NORMAL':
                target = self.get_states(nmsp=self.namespace)['result'][target_id]['blockHeight']
                break
            elif self.get_states(nmsp=self.namespace)['result'][self.id + 1 % 4]['status'] == 'NORMAL':  # 再后一个节点
                target = self.get_states(nmsp=self.namespace)['result'][self.id + 1 % 4]['blockHeight']
                break
            time.sleep(interval)
            start_timeout -= interval
        times = 1
        while True:
            count1 = self.block_getChainHeight()
            self.logger.debug(
                "%s 节点%s第%d次查询区块高度,当前区块高度为%s,目标区块高度为%s" % (self.namespace, self.host, times, count1, target))
            if count1 >= target:
                tx_count = self.tx_getTransactionsCount()
                self.logger.info("%s 节点%s完成区块同步,耗时%d秒，tps=%d" % (
                    self.namespace, self.host, times * interval, int(tx_count / (times * interval))))
                return round(times * interval / 60, 2), int(tx_count / (times * interval)), self.namespace
            time.sleep(interval)  # 每隔5s查询一次
            times += 1
            if times * interval > timeout:
                print(colored("%s ERROR: 节点区块同步超时，超时时间:%s秒" % (self.namespace, str(timeout)), 'red'))
                return -1, -1, self.namespace

    def restart_docker(self):
        self.logger.debug("正在重启节点容器%s..." % self.host)
        self.client.exec_cmd_wait("sudo docker restart %s" % self.name)

    def ping(self, hosts, namespace="global", timeout=180):
        hostnames = hosts.copy()
        if hostnames == []:
            return True

        self.logger.debug("检查是否连接%s..." % hostnames)
        start = datetime.datetime.now()
        while True:
            end = datetime.datetime.now()
            if (end - start).seconds < timeout:
                time.sleep(6)
                result = self.get_states(nmsp=namespace)['result']
                for state in result:
                    if state['hostname'] in hostnames:
                        if "TIMEOUT" in state['status']:
                            continue
                        else:
                            hostnames.remove(state['hostname'])
                            if len(hostnames) == 0:
                                return True
            else:
                break
        if len(hostnames) > 0:
            return False
        return True

    def check_dynamic(self, expectations):
        remote_dynamic = util.load_conf_remote(self.client, self.node_dir + "/configuration/dynamic.toml")
        remote_hosts = remote_dynamic['p2p']['ip']['remote']['hosts'].sort()
        exp_hosts = expectations['p2p']['ip']['remote']['hosts'].sort()
        if remote_hosts != exp_hosts:
            return False
        remote_addrs = remote_dynamic['p2p']['ip']['self']['addrs'].sort()
        exp_addrs = expectations['p2p']['ip']['self']['addrs'].sort()
        if remote_addrs != exp_addrs:
            return False
        return True

    def check_log(self, target_str, start=None):
        for i in range(5):
            remote_logs = self.node_dir + "/" + self.host + ".log"
            exit_code, stdout, stderr = self.client.exec_cmd_wait('cat %s|grep "%s"' % (remote_logs, target_str))
            if stdout != "":
                if start is None:
                    return True
                last = stdout.split("\n")[-1]
                time_str = last.split(" ")[1][1:-1]
                time_rel = datetime.datetime.strptime(time_str, '%Y-%m-%dT%H:%M:%S.%f')
                if time_rel > start:
                    return True
            time.sleep(8)
        return False

    def ipc_list(self):
        docker_pre = ""
        docker_suf = ""
        if self.name != "":
            docker_pre = "docker exec %s bash -c '" % self.name
            docker_suf = "'"
        _, stdout, stderr = self.client.exec_cmd_wait('%scd %s && ./%s %s"network list"%s' %
                                                      (docker_pre, self.node_dir, self.chain_name, ipc, docker_suf))
        if stdout != "":
            print(stdout)
            clients = []
            for conn in stdout.split("\n")[1:]:
                info = conn[1:-1].split(", ")
                if info[2].split(": ")[-1] == "client":
                    clients.append(info[0].split(": ")[-1])
            print(clients)
            return clients

    def ipc_address_insert(self, info):
        docker_pre = ""
        docker_suf = ""
        if self.name != "":
            docker_pre = "docker exec -d %s bash -c '" % self.name
            docker_suf = "'"
        for ip in info['p2p']['ip']['self']['addrs']:
            self.client.exec_cmd('%scd %s && ./%s %s"network address -i %s %s -f"%s' %
                                 (docker_pre, self.node_dir, self.chain_name, ipc, ip.split(' ')[0], ip.split(' ')[1],
                                  docker_suf))

    def ipc_address_delete(self, info):
        docker_pre = ""
        docker_suf = ""
        if self.name != "":
            docker_pre = "docker exec -d %s bash -c '" % self.name
            docker_suf = "'"
        for ip in info['p2p']['ip']['self']['addrs']:
            self.client.exec_cmd('%scd %s && ./%s %s"network address -d %s %s"%s' %
                                 (docker_pre, self.node_dir, self.chain_name, ipc, ip.split(' ')[0], ip.split(' ')[1],
                                  docker_suf))

    def ipc_topograph(self):
        docker_pre = ""
        docker_suf = ""
        if self.name != "":
            docker_pre = "docker exec %s bash -c '" % self.name
            docker_suf = "'"
        _, stdout, stderr = self.client.exec_cmd_wait(
            '%scd %s && ./%s %s"network topograph -http=%s"%s' %
            (docker_pre, self.node_dir, self.chain_name, ipc, str(9000 + self.id), docker_suf))
        if stdout == "":
            result = stderr.read().decode()
        else:
            result = stdout
        lines = result.split('\n')
        conns = {}
        for line in lines:
            if "node" in line:
                conn = line.split("                 ")
                conns[conn[0]] = []
                for item in conn[1].split(" "):
                    if len(item) > 0:
                        conns[conn[0]].append(item)
        return conns

    def ipc_path(self, host):
        docker_pre = ""
        docker_suf = ""
        if self.name != "":
            docker_pre = "docker exec %s bash -c '" % self.name
            docker_suf = "'"
        _, stdout, stderr = self.client.exec_cmd_wait(
            '%scd %s && ./%s %s"network path %s"%s' %
            (docker_pre, self.node_dir, self.chain_name, ipc, host, docker_suf))
        if stdout != "":
            print(stdout)
            paths = []
            for path in stdout.split("\n"):
                paths.append(path.split(" --> "))
            return paths
        print(bytes.decode(stderr.read()))
        return None

    def ns_start(self, namespace):
        self.client.exec_cmd('cd %s && ./%s %s"namespace start %s"' % (self.node_dir, self.chain_name, ipc, namespace))

    def ns_stop(self, namespace):
        # self.client.exec_cmd('cd %s && ./%s %s"namespace stop %s"' % (self.node_dir, self.chain_name, ipc, namespace))
        #     'cd %s && ./%s %s"namespace stop %s"' % (self.node_dir, self.chain_name, ipc, namespace))

        start = time.time()
        _, stdout, stderr = self.client.exec_cmd_wait(
            'cd %s && ./%s %s"namespace stop %s"' % (self.node_dir, self.chain_name, ipc, namespace))
        if stdout != "":
            print(stdout)
        else:
            print(bytes.decode(stderr.read()).replace("\x1b[0m", "").strip())
        if time.time() - start > 65:
            print("Stop ns spend %d s" % (time.time() - start))
            # assert False

    def cvp_enable(self):
        self.client.exec_cmd_wait('cd %s && ./%s %s"cvp enable"' % (self.node_dir, self.chain_name, ipc))

    def cvp_disable(self):
        self.client.exec_cmd_wait('cd %s && ./%s %s"cvp disable"' % (self.node_dir, self.chain_name, ipc))

    def cvp_status(self):
        _, stdout, stderr = self.client.exec_cmd_wait(
            'cd %s && ./%s %s"cvp status"' % (self.node_dir, self.chain_name, ipc))
        print(stdout)
        if stdout != "" and "abnormal" in stdout:
            return False
        return True

    def get_nodes(self):
        response = web.post_RPC(self.url, "node_getNodes", [], timeout=3, ns=self.namespace)
        return response
