# coding=UTF-8
import json
import time
import math
import copy
import logging
import utils.util as util
from concurrent import futures
from classes.blockchain_node import BlockchainNode


class Blockchain(object):
    def __init__(self, configs):
        self.config = configs
        self.chain_name = self.config["blockchain"]["name"]
        self.ips = self.config["blockchain"]["server"]["ips"]
        self.nodes = []
        self.nvps = []
        self.nvp_ips = self.config["nvp"]["ips"]
        self.cvps = []
        self.cvp_ips = self.config["cvp"]["ips"]
        self.namespaces = self.config["blockchain"]["namespaces"]
        self.logger = logging.getLogger("frigateDynamic." + self.chain_name)

        def  connect(self, i, ip, type="node"):
            node_id = i + 1
            user_name = self.config["blockchain"]["server"]["user_name"][i] if len(
                self.config["blockchain"]["server"]["user_name"]) > i else "hyperchain"
            password = self.config["blockchain"]["server"]["password"][i] if len(
                self.config["blockchain"]["server"]["password"]) > i else "hyperchain"
            try:
                user_name = self.config["blockchain"]["server"]["user_name"][i] if len(
                    self.config["blockchain"]["server"]["user_name"]) > i else "hyperchain"
                password = self.config["blockchain"]["server"]["password"][i] if len(
                    self.config["blockchain"]["server"]["password"]) > i else "hyperchain"
                name = self.config["blockchain"]["docker"]["names"][i] if \
                    self.config["blockchain"]["env"] == "docker" else ""
                remote_dir = self.config["blockchain"]["remote_workspace"] + "/" + type + str(node_id)
                block_node = BlockchainNode(ip=ip, id=node_id, remote_dir=remote_dir, chain_name=self.chain_name,
                                            node_type=type, username=user_name, password=password, name=name,jsonrpc_start=self.config["blockchain"]["jsonrpc_start"],grpc_start=self.config["blockchain"]["grpc_start"])
                if type == "node":
                    self.nodes.append(block_node)
                if type == "nvp":
                    self.nvps.append(block_node)
                    # 节点id用于标志端口次序
                    block_node.id += len(self.config["blockchain"]["server"]["ips"])
                    block_node.jsonrpc_port+=len(self.config["blockchain"]["server"]["ips"])
                    block_node.grpc_port+=len(self.config["blockchain"]["server"]["ips"])
                    block_node.set_url()

                if type == "cvp":
                    self.cvps.append(block_node)
                    block_node.id += len(self.config["blockchain"]["server"]["ips"]) + len(self.config["nvp"]["ips"])
                    block_node.jsonrpc_port+=len(self.config["blockchain"]["server"]["ips"])+ len(self.config["nvp"]["ips"])
                    block_node.grpc_port+=len(self.config["blockchain"]["server"]["ips"])+ len(self.config["nvp"]["ips"])
                    block_node.set_url()
                return self
            except Exception as e :
                print(e)
                print("用户名%s,密码%s"%(user_name,password))
                print("连接%s发生异常"%node_id)
                # return connect(self,i, ip, type) #如果一次性连接30个节点，需要加上重连，否则部分节点连接会有问题


        with futures.ThreadPoolExecutor(len(self.ips) + len(self.nvp_ips) + len(self.cvp_ips)) as executor:
            self.logger.info("正在连接vp节点，个数%s" % len(self.ips))
            for i, ip in enumerate(self.ips):
                executor.submit(connect, self, i, ip, "node")
            self.logger.info("正在连接nvp节点,个数%s" % len(self.nvp_ips))
            for j, ip2 in enumerate(self.nvp_ips):
                executor.submit(connect, self, j, ip2, "nvp")
            self.logger.info("正在连接cvp节点,个数%s" % len(self.cvp_ips))
            for s, ip in enumerate(self.cvp_ips):
                executor.submit(connect, self, s, ip, "cvp")
        self.nodes.sort()
        self.nvps.sort()

        # 优化了一下，由于对于一个blockchain对象，config文件总是固定的，故一个blockchain对象只准备一次，之后都用这个去部署

    # def clean_prepare_dir(self):
    #     # 清除本地节点目录
    #     # self.logger.debug("#执行结束，清除本地节点目录")
    #     print("#执行结束，清除本地节点目录")
    #     prepare = self.config["blockchain"]["local"]["prepare_dir"]
    #     os.system("rm -rf " + prepare + "*")

    def prepare_nodes_locally(self):
        self.logger.info("正在本地准备节点...")
        # 各个blockchain应该实现自己的prepare方法

    def thread_pool_run_all_nodes(self, method, nodes):
        with futures.ThreadPoolExecutor(len(nodes)) as executor:
            for node in nodes:
                executor.submit(method, node)

    def upload_nodes(self):
        '''
            将本地准备好的节点分别上传到对应服务器
            :return:
        '''

        def upload(node):
            local_node_dir = self.config["blockchain"]["local"]["prepare_dir"] + "/" + node.host  # 本地准备好的节点目录
            self.logger.debug("正在上传节点文件夹...  dir %s" % (local_node_dir))
            self.logger.debug("remote node_dir: %s" % node.node_dir)
            node.client.exec_cmd_wait("mkdir -p " + node.node_dir)  # 新建目录
            node.client.sftp_put_dir(local_node_dir, node.node_dir)  # 上传

        self.logger.info("正在上传节点到服务器...")
        self.thread_pool_run_all_nodes(upload, self.nodes + self.nvps + self.cvps)

    def start_nodes(self):
        '''
            启动所有节点
        :return:
        '''
        self.stop_nodes()

        if self.nodes[0].name != "":
            for node in self.nodes:
                node.restart_docker()
        #单机部署
        for node in (self.nodes + self.nvps + self.cvps):
            node.start()
            time.sleep(1)

    def change_nodes_config(self, config_tests):
        if len(config_tests) == 0:
            self.logger.debug("没有需要修改的配置")
        for config in config_tests:
            with futures.ThreadPoolExecutor(len(self.nodes + self.nvps + self.cvps)) as executor:
                for node in self.nodes:
                    p = self.config["blockchain"]["local"]["prepare_dir"] + "/" + node.host + "/" + config.path
                    executor.submit(util.change_config, p, config.k, config.v)

    def stop_nodes(self):
        '''
            停止所有节点
        :return:
        '''
        self.logger.info("正在停止所有节点...")
        fs = []
        with futures.ThreadPoolExecutor(len(self.nodes + self.nvps + self.cvps)) as executor:
            for node in (self.nodes + self.nvps + self.cvps):
                fs.append(executor.submit(node.stop))

    def clean_env(self):
        '''
            清除远程运行目录和本地节点目录
        :return:
        '''
        self.stop_nodes()
        self.logger.info("正在清理远程目录")

        def clean(node):
            node.client.exec_cmd_wait(" rm -rf " + node.node_dir)

        self.thread_pool_run_all_nodes(clean, self.nodes + self.nvps + self.cvps)

    def back_up(self):
        '''
        :return:
        '''
        now = time.strftime('%Y-%m-%d_%H:%M:%S', time.localtime(time.time()))
        self.stop_nodes()

        def backup(node: BlockchainNode):
            backup_dir = self.config["blockchain"]["remote_workspace"] + self.config["blockchain"]["server"][
                "backup_dir"] + "/" + node.host + "_" + now
            for ns in self.namespaces:
                node.namespace = ns
                node.delete_data()
            node.backup(backup_dir)

        self.thread_pool_run_all_nodes(backup, self.nodes + self.nvps + self.cvps)

    def __get_node_states(self, id=1, nmsp="global"):
        """
            调用node_getNodeStates接口，获取集群状态
        :param id: 查询的节点id
        :return:
        """
        # 1、如果开启tcert或https,则默认为True
        if self.config["config"]["tcert"] or self.config["config"]["https"]:
            self.logger.warning("开启了https or tcert ,无法获取集群状态，忽略状态检查")
            time.sleep(10)
            return True, []
        # 2、如果未开启
        response = self.nodes[id - 1].get_states(30, nmsp)
        status_arr = []
        flag = True
        for state in response['result']:
            if state['status'] != 'NORMAL':
                flag = False
            status_arr.append(state['status'])
        return flag, status_arr

    def get_cluster_states(self, timeout, delta=5, recovery=180, namespace="global"):
        f = int(math.floor((len(self.nodes) - 1) / 3.0))
        start = time.time()
        if recovery == -1:
            self.logger.info("等待节点状态恢复，恢复时间为：%ds" % timeout)

        while time.time() - start <= timeout:
            abnormal = 0
            for node in self.nodes:
                normal, _ = self.__get_node_states(id=node.id, nmsp=namespace)
                if not normal:
                    abnormal += 1

            if abnormal >= 2:
                self.logger.info("节点状态异常，等待后重新查询...")
                if recovery > 0:
                    # 若节点状态未在指定时间内恢复，直接返回False
                    if not self.get_cluster_states(recovery, 1, -1, namespace):
                        return False
                    else:
                        self.logger.info("集群状态恢复正常！")
                else:
                    time.sleep(delta)
                    continue

            if len(self.nvps) != 0:
                return self.check_nvp_status(namespace=namespace)
            if len(self.cvps) != 0:
                return self.check_cvp_status()
            else:
                return True
        return False

    def destroy(self):
        '''
            清除集群、有异常则备份
        :return:
        '''
        self.logger.info("清除集群")
        backup = self.config["blockchain"]["server"]["backup"]
        if backup == "error":
            if not self.check_status_all_ns(retry_times=600):  # 超时时间 600*5s=50min 有时候节点在做stateUpdate 也会
                self.logger.warning("集群状态存在异常,进行备份...")
                msg = "测试完成后集群状态存在异常,服务器ip:" + str(self.ips) + "\n 节点目录:" + self.config["blockchain"][
                    "remote_workspace"]
                self.back_up()
        if backup == "all":
            self.back_up()
        self.clean_env()

    def get_blockchain_msg(self, block_msg=True):
        '''
            获取版本、节点1 recovery次数、vc次数等信息
        :return:
        '''
        results = {}
        self.logger.debug("#1、获取节点版本")
        node1 = self.nodes[0]
        code, out, err = node1.client.exec_cmd_wait("cd " + node1.node_dir + " && head -5 node1.log|grep HEAD |tail -1")
        results["flato_version"] = out
        msg = {}

        def get_node_msg(node: BlockchainNode):
            node_msg = {}
            recovery_times = "cd " + node.node_dir + " && grep 'finished recovery' " + node.host + ".log | wc -l"
            vc_times = "cd " + node.node_dir + " && grep 'finished viewChange' " + node.host + ".log | wc -l"
            erro_log = "cd " + node.node_dir + " && grep 'ERRO' " + node.host + ".log"
            self.logger.debug("#2、获取%s压测后的vc次数和recovery次数" % node.host)
            cmds = {"recovery_times": recovery_times, "vc_times": vc_times,"erro_log":erro_log}
            for key in cmds:
                code, out, err = node.client.exec_cmd_wait(cmds[key])
                node_msg[key] = out
                self.logger.error("当前key:%s" % key)
                if key=="erro_log" and out :
                    self.logger.error("检测到erro日志如下\n:%s"%out)
            self.logger.debug("#3、获取%s压测后的节点高度" % node.host)
            height = node.block_getChainHeight()
            node_msg["height"] = height
            self.logger.debug("#4、获取%s压测后的交易条数" % node.host)
            tx_count = node.tx_getTransactionsCount()
            node_msg["tx_count"] = tx_count
            self.logger.debug("#5、获取%s数据大小 " % node.host)
            size = node.get_data_size()
            node_msg["size"] = size
            msg[node.host] = node_msg

        if block_msg:
            self.thread_pool_run_all_nodes(get_node_msg, self.nodes + self.nvps)
        results["node_msgs"] = json.dumps(msg)
        return results

    def check_status_all_ns(self, retry_times=10, id=1, namespaces=[]):
        if len(namespaces) == 0:
            namespaces = self.namespaces
        for ns in namespaces:
            i = 0
            while True:
                i += 1
                logging.debug("第%s次获取集群状态,ns=%s..." % (str(i), ns))
                status, detail = self.__get_node_states(id=id, nmsp=ns)
                if status:
                    break
                time.sleep(5)  # 每隔5s钟获取一次集群状态
                if i >= retry_times:
                    self.logger.warning("ERROR: 集群状态恢复超时，超时时间:%s秒" % str(i * 5))
                    self.logger.warning("ERROR: namespace:%s,集群状态为:%s" % (ns, detail))
                    return False
            if len(self.nvps) != 0:
                if not self.check_nvp_status(namespace=ns):
                    self.logger.debug("nvp状态异常，请检查")
                    return False
        self.logger.critical("集群部署成功...")
        return True

    def deploy(self, config_tests=None, retry_times=20):
        '''
            远程部署
        :return:
        '''
        self.clean_env()
        # 由于prepare在init中执行，因此只能在deploy前修改配置
        if config_tests != None:
            self.change_nodes_config(config_tests)
        self.prepare_nodes_locally()
        self.upload_nodes()
        self.start_nodes()
        return self.check_status_all_ns(retry_times=retry_times)

    def delete_data_and_restart(self):
        self.stop_nodes()
        with futures.ThreadPoolExecutor(len(self.nodes)) as executor:
            for node in self.nodes:
                executor.submit(node.delete_data)
        self.start_nodes()

    def specify_node_to_syncchain(self, node_id, namespaces=["global"], timeout=3600 * 24):
        '''
        指定要syncChain的节点
        :param node_id:
        :return: syncChain的时间（minutes）和tps
        '''
        if len(namespaces) == 0:
            namespaces = self.namespaces
        util.check_id(node_id, len(self.nodes))
        node = self.nodes[node_id - 1]
        node.stop()
        with futures.ThreadPoolExecutor(len(namespaces)) as executor:
            for ns in namespaces:
                # 必须copy一份，否则两个线程共用一个对象的namespace
                node_temp = self.get_namespace_node(node, ns)
                executor.submit(node_temp.delete_data)
        node.start()
        sync_chain_results = []
        fs = []
        pool = futures.ThreadPoolExecutor(len(namespaces))

        for ns in namespaces:
            node_temp = self.get_namespace_node(node, ns)
            fs.append(pool.submit(node_temp.sync_chain_return_time, timeout))
        for f in futures.as_completed(fs):
            sync_chain_results.append(f.result())
        self.logger.debug(sync_chain_results)
        return sync_chain_results

    def get_namespace_node(self, node, ns):
        '''
        返回namespace下的节点
        '''
        node_temp = copy.copy(node)
        node_temp.namespace = ns
        return node_temp

    def check_nvp_status(self, timeout=180, namespace="global"):
        start = time.time()
        height = self.nodes[0].block_getChainHeight()
        while time.time() - start <= timeout:
            abnormal = 0
            for i, nvp in enumerate(self.nvps):
                node_tmp = self.get_namespace_node(nvp, namespace)
                if height != node_tmp.block_getChainHeight():
                    abnormal += 1
            if abnormal != 0:
                time.sleep(3)
            else:
                return True
        return False

    def check_cvp_status(self, timeout=180):
        start = time.time()
        while time.time() - start <= timeout:
            abnormal = 0
            for i, vp in enumerate(self.nodes):
                if not vp.cvp_status():
                    abnormal += 1
            if abnormal != 0:
                time.sleep(3)
            else:
                return True
        return False


    def get_all_nodes_in_blockchain(self):
        vps={}
        nvps={}
        for node in self.nodes:
            response=node.get_nodes()
            # response['result'].sort(key="hostname")
            for node in response['result']:
                if node['isvp']:
                    vps[node["hostname"]]=node
                else:
                    nvps[node["hostname"]]=node
        return vps,nvps



# if __name__ == "__main__":
#     init_log()
#     config=util.load_global_conf("conf/2124.toml")
#     blockchain=Blockchain(config)
#     blockchain.specify_node_to_syncchain(node_id=1,namespaces=["global","ns1"])
#
