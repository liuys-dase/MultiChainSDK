# coding=UTF-8
import logging
import utils.util as util
import toml
import os
from concurrent import futures
from classes.blockchain import Blockchain

from log.Logger import init_log


class Hyperchain(Blockchain):
    def __init__(self, configs):
        super().__init__(configs)
        self.logger = logging.getLogger("frigateDynamic.Hyperchain")

    def prepare_nodes_locally(self):
        '''
             本地准备好所有节点
        :return:
        '''
        super().prepare_nodes_locally()
        certs=""
        prepare_dir = self.config["blockchain"]["local"]["prepare_dir"]
        if self.config["config"]["tcert"]:
                self.logger.debug("hpc tcert开启，需要替换节点证书，否则没有办法与skdcert配套...")
                url = "http://nexus.hyperchain.cn/repository/hyper-test/certs/hyperchain_certs.tar.gz"
                certs = util.wgetSource(url, prepare_dir, "hyperchain_certs")
                # 修改节点配置
        with futures.ThreadPoolExecutor(len(self.nodes) + len(self.nvps) + len(self.cvps)) as executor:
            for node in self.nodes + self.nvps + self.cvps:
                executor.submit(self.prepare, node, certs)

    def prepare(self,node,certs=""):
        node_id = str(node.id)
        node_dir = self.config["blockchain"]["local"]["prepare_dir"] + "/" + node.host  # 本地准备好的节点目录
        self.logger.debug("prepare node dir :%s", node_dir)
        # 1、创建节点i
        util.mkdir(node_dir)
        source_dir = self.config["blockchain"]["local"]["source_dir"]
        cmd = "cp -r " + source_dir + " " + node_dir
        os.system(cmd)

        self.logger.debug("2、修改 global.toml")

        # 2、修改 global.toml
        global_toml_path = node_dir + "/global.toml"
        global_toml = util.load_conf(global_toml_path)
        # params["self"] = host_name

        global_toml["hypervm"]["jvm"] = False
        global_toml["port"]["jsonrpc"]=self.config["blockchain"]["jsonrpc_start"]+node.id
        # params["port"]["restful"]=9000+(i + 1)
        global_toml["port"]["websocket"]=self.config["blockchain"]["websocket_start"]+node.id
        global_toml["port"]["jvm"]=self.config["blockchain"]["jvm_start"]+node.id
        global_toml["port"]["ledger"]=self.config["blockchain"]["ledger_start"]+node.id
        global_toml["port"]["grpc"]=self.config["blockchain"]["grpc_start"]+node.id
        global_toml["flow"]["control"]["ratelimit"]["enable"] = False
        global_toml["log"]["module"]["p2p"] = "NOTICE"
        global_toml["log"]["module"]["consensus"] = "NOTICE"
        global_toml["log"]["module"]["executor"] = "NOTICE"
        global_toml["log"]["module"]["private"] = "NOTICE"
        global_toml["log"]["module"]["state"] = "NOTICE"
        with open(global_toml_path, 'w') as conf:
            toml.dump(global_toml, conf)
        self.logger.debug("3、修改 addr.toml")

        # 3、修改 addr.toml
        ns_addr_toml = node_dir + "/addr.toml"
        ns_addr = util.load_conf(ns_addr_toml)
        ns_addr["domain"] = "domain1"
        ns_addr["self"] = node.host
        ns_addr["addrs"] = ["domain1 " + node.ip +":" + str(self.config["blockchain"]["grpc_start"]+node.id)]
        with open(ns_addr_toml, 'w') as conf:
            toml.dump(ns_addr, conf)

        #修改 host.toml
        self.logger.debug("4、修改 host.toml")

        hosts_toml_path = node_dir+"/hosts.toml"
        hosts_toml = util.load_conf(hosts_toml_path)
        hosts_toml["hosts"] = []
        hosts_config = []
        if node.type=="nvp":
            if node.id==8:
                print("nvp4")
            vp_ids = self.config[node.type]["conns"][node.id - len(self.ips) - 1]
            nvp_cont = "%s %s:%s" % (node.host, node.ip, str(self.config["blockchain"]["grpc_start"] + node.id))
            hosts_config.append(nvp_cont)
            for vp_id in vp_ids:
                vp_ip = self.ips[vp_id - 1]
                vp_content = "%s %s:%s" % ("node" + str(vp_id), vp_ip, str(self.config["blockchain"]["grpc_start"] + vp_id))
                hosts_config.append(vp_content)
        else:
            for j, ip2 in enumerate(self.ips):
                content = "node" + str(j + 1) + " " + ip2 + ":" + str(self.config["blockchain"]["grpc_start"]+j + 1)
                hosts_config.append(content)
        hosts_toml["hosts"]=hosts_config

        with open(hosts_toml_path, "w") as conf:
            toml.dump(hosts_toml,conf)

        # 修改 peerconfig
        peerconfig_toml_path = node_dir+ "/namespaces/global/config/peerconfig.toml"
        peerconfig_toml = util.load_conf(peerconfig_toml_path)
        peerconfig_toml["self"]["n"] = len(self.ips)
        peerconfig_toml["self"]["hostname"] = node.host
        peers=[]
        peerconfig_toml["nodes"]=[]
        if node.type=="nvp" :
            if node.id==8:
                print("nvp4")
            peerconfig_toml["self"]["hostname"] = node.host
            peerconfig_toml["self"]["vp"] = False

            vp_ids = self.config[node.type]["conns"][node.id - len(self.ips) - 1]
            peerconfig_toml["self"]["n"] = len(vp_ids)
            for vp_id in vp_ids:
                peerconfig_toml["nodes"].append({"hostname": "node" + str(vp_id), "score": 10})
        else:
            for k in range(1, len(self.ips) + 1):
                peerconfig_toml["nodes"].append({"hostname": "node"+str(k), "score": 10})
        with open(peerconfig_toml_path, 'w') as conf:
            toml.dump(peerconfig_toml, conf)
        # 修改namespace.toml
        namespace_toml_path=node_dir+"/namespaces/global/config/namespace.toml"
        namespace_toml = util.load_conf(namespace_toml_path)
        modules=["p2p","namespace","consensus","executor","hypernet","private","state"]
        for m in modules:
            namespace_toml["log"]["module"][m]="NOTICE"
        namespace_toml["duplicate"]["remove"]["bloomfilter"]["interval"]="5m"
        namespace_toml["duplicate"]["remove"]["bloomfilter"]["active_time"]="5m"
        namespace_toml["flow"]["control"]["ratelimit"]["enable"]=False
        namespace_toml["encryption"]["check"]["enableT"] = self.config["config"]["tcert"]

        with open(namespace_toml_path, 'w') as conf:
            toml.dump(namespace_toml, conf)

        if self.config["config"]["tcert"]:
            self.logger.info(" tcert开启，需要替换hpc节点证书 ")
            self.logger.debug("node.type: %s",node.type)
            self.logger.debug(" node_id: %s",node_id,)
            self.logger.debug(" node_dir: %s",node_dir)
            cp_certs_cmd = "cp -r " + certs + "/"+node.type + node_id + "/* " + node_dir + "/namespaces/global/config/certs"
            self.logger.debug("放置节点证书: %s" % cp_certs_cmd)
            os.system(cp_certs_cmd)

if __name__ == '__main__':
    init_log()
    config = util.load_global_conf("/Users/guopenglin/PycharmProjects/frigateDynamic/conf/lgp_wd_demo_hyperchain.toml")
    # config = util.load_global_conf("/Users/zxj/frigateDynamic/conf/zxj_hyperchain.toml")
    hyperchain = Hyperchain(config)
    # hyperchain.pprof("./")
    hyperchain.deploy()

