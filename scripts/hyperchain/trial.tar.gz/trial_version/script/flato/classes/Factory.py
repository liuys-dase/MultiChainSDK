# coding=UTF-8
from classes.Hyperchain import Hyperchain
from classes.flato import Flato

from classes.flato import Blockchain
from termcolor import colored


def get_platform(configs) -> Blockchain:
    name = configs["blockchain"]["name"].lower()
#    print("远程部署当前最新版本的%s.." % name)
#    print("远程部署路径为%s.." % configs["blockchain"]["remote_workspace"])
#    print(colored("远程部署ip为%s.." % configs["blockchain"]["server"]["ips"], 'green'))
    b_map = {"hyperchain": "Hyperchain",
             "hpc": "Hyperchain",
             "flato": "Flato",
             "flato-solo": "Flato_solo",
             "flato_solo": "Flato_solo",
             "solo": "Flato_solo",
             "SOLO": "Flato_solo"}
    if name not in b_map.keys():
        assert "unsupport platoform %s " % configs["blockchain"]["name"]
    else:
        return eval(b_map[name] + "(configs)")
