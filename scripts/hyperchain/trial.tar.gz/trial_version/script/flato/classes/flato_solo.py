# coding=UTF-8
import utils.util as util
import logging
from classes.flato import Flato
from log.Logger import init_log
from termcolor import colored
class Flato_solo(Flato):
    def __init__(self, configs):
        configs["blockchain"]["name"]="flato"
        self.logger = logging.getLogger("frigateDynamic.flato_solo")
        if len(configs["blockchain"]["server"]["ips"]) != 1:
            print(colored("SOLO only support 1 node , use ip 1 ",'red'))
            configs["blockchain"]["server"]["ips"]=configs["blockchain"]["server"]["ips"][0:1]
        super().__init__(configs)

    def prepare_nodes_locally(self):
        super().prepare_nodes_locally()

    def prepare_node(self, node, certs, SOLO=True):
        super().prepare_node(node,certs,True)

if __name__ == '__main__':
    init_log()
    config = util.load_global_conf("conf/31_solo.toml")
    float = Flato_solo(config)
    float.prepare_nodes_locally()
