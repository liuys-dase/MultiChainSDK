# coding=UTF-8

import os
import toml
import copy
import random
import logging
import dijkstra
import utils.util as util

from concurrent import futures
from log.Logger import init_log
from classes.blockchain import Blockchain
'''
适用于1.0.3及以后版本，如果需要回归老版本用git checkout completeConfig
'''

class Flato(Blockchain):
    def __init__(self, configs):
        super().__init__(configs)
        self.logger = logging.getLogger("frigateDynamic.flato")

    def prepare_nodes_locally(self):
        super().prepare_nodes_locally()
        prepare_dir = self.config["blockchain"]["local"]["prepare_dir"]

        # 拉取节点证书，flato0.0.7?以后特有
        certs = ""
        if self.config["blockchain"]["local"]["certs"]:
            if "certs_path" in self.config["blockchain"]["local"]:
                certs = self.config["blockchain"]["local"]["certs_path"]
            else:
                self.logger.debug("拉取节点证书（0.0.6及以上）...")
                url = "http://nexus.hyperchain.cn/repository/hyper-test/certs/certs.tar.gz"
                certs = util.wgetSource(url, prepare_dir, "certs")
        # 修改source
        self.prepare_source()

        # 修改节点配置
        with futures.ThreadPoolExecutor(len(self.nodes) + len(self.nvps) + len(self.cvps)) as executor:
            for node in self.nodes + self.nvps + self.cvps:
                executor.submit(self.prepare_node, node, certs)

    def prepare_source(self):
        '''
        修改所有节点公共部分，例如日志级别修改，特殊配置修改，主要为global.toml(system.toml)和ns_static.toml
        :return:
        '''
        source_dir = self.config["blockchain"]["local"]["source_dir"]
        source_dir = source_dir[:-1]
        self.logger.info("prepare source dir ")

        global_toml = source_dir + "configuration/system.toml"
        self.logger.info("1、修改" + global_toml)
        util.change_config(global_toml, "flow.control.ratelimit.enable", False)
        util.change_config(global_toml, "p2p.enableTLS", False)
        util.change_config(global_toml, "http.request.max_content_length", "500kb")
        util.change_config(global_toml, "p2p.grpc.maxRecvMessageSize", "1000mb")
        util.change_config(global_toml, "p2p.grpc.maxSendMessageSize", "1000mb")
        util.change_config(global_toml, "http.security", self.config["config"]["https"])


        self.logger.info("2、修改debug.toml")
        debug_toml = source_dir + "/configuration/debug.toml"
        util.change_config(debug_toml, "pprof.enable", self.config["config"]["debug"]["enable"])
        util.change_config(debug_toml, "pprof.detail", self.config["config"]["debug"]["enable"])
        util.change_config(debug_toml, "pprof.duration", self.config["config"]["debug"]["duration"])
        util.change_config(debug_toml, "metrics.enable", self.config["config"]["debug"]["metrics"])
        util.change_config(debug_toml, "metrics.enable_expensive", self.config["config"]["debug"]["metrics_exp"])

        self.logger.info("3、修改ns_static.toml")
        ns_static_toml = source_dir + "/configuration/global/ns_static.toml"
        util.change_config(ns_static_toml, "encryption.check.enable", False)
        util.change_config(ns_static_toml, "rpc.qps.flowCtrl.enable", False)
        util.change_config(ns_static_toml, "duplicate.tx_drift_time", "1s")
        util.change_config(ns_static_toml, "database.indexdb.layer1.enable", self.config["config"]["indexdb"]["enable"])
        util.change_config(ns_static_toml, "database.indexdb.layer2.active", self.config["config"]["indexdb"]["active"])
        util.change_config(ns_static_toml, "executor.filemgr.enable", self.config["config"]["file_mgr"])
        util.change_config(ns_static_toml, "encryption.check.enableT",self.config["config"]["tcert"])
        util.change_config(ns_static_toml, "encryption.security.algo","pure")

        # 修改其它diy配置
        diy_configs = util.load_diy_configs_from_dict(self.config)
        for conf in diy_configs:
            path = source_dir + conf.path
            util.change_config(path, conf.k, conf.v)

    def prepare_node(self, node, certs, solo=False):
        '''
             修改单个节点特有配置，主要为dynamic.toml和ns_dynamic.toml
             i：节点序号
        :return:
        '''
        self.logger.info("1、创建节点")
        node_dir = self.config["blockchain"]["local"]["prepare_dir"] + "/" + node.host
        self.logger.info("prepare node dir :%s", node_dir)
        source_dir = self.config["blockchain"]["local"]["source_dir"]
        node_id = str(node.id)
        if os.path.exists(node_dir):
            self.logger.info("部署节点已存在，跳过")
            return
        util.mkdir(node_dir)
        cmd = "cp -r " + source_dir + " " + node_dir
        os.system(cmd)

        #需要修改的配置文件路径
        dynamic_toml_path = node_dir + "/configuration/dynamic.toml"
        ns_dynamic_path = node_dir + "/configuration/global/ns_dynamic.toml"

    #2、修改dynamic.toml
        self.logger.info("2、修改dynamic.toml")
        util.change_config(dynamic_toml_path, "self", node.host)
        util.change_config(dynamic_toml_path, "port.jsonrpc", self.config["blockchain"]["jsonrpc_start"] + node.id)
        util.change_config(dynamic_toml_path, "port.grpc", self.config["blockchain"]["grpc_start"] + node.id)
        util.change_config(dynamic_toml_path, "port.grpcApi", self.config["blockchain"]["grpcapi_start"] + node.id)
        util.change_config(dynamic_toml_path, "p2p.ip.self.domain", "domain" + str(self.config["blockchain"]["network"][node.host]["domain"]))
        # 准备addrs
        addrs = self.config["blockchain"]["network"][node.host]["addrs"]
        addrs_arr=[]
        for key in addrs.keys():
            addrs_arr.append("domain" + key + " " + addrs[key])
            util.change_config(dynamic_toml_path, "p2p.ip.self.addrs", addrs_arr)

        # 准备hosts_config内容
        hosts_config=[]
        if node.type == "node":
            domain = str(self.config["blockchain"]["network"][node.host]["domain"])
            for node_tmp in self.nodes:
                content = node_tmp.host + " " + self.config["blockchain"]["network"][node_tmp.host]["addrs"][domain]
                hosts_config.append(content)
            # 如果有cvp 还需要在dynamic.toml中设置cvp enable = true
            if len(self.config["cvp"]["ips"]) > 0:
                util.change_config(dynamic_toml_path, "cvp.enable", True)
        elif node.type == "nvp" or node.type == "cvp":
            vp_id = self.config[node.type]["conns"][node.id - len(self.ips) - 1]
            vp_ip = self.ips[vp_id - 1]
            nvp_cont = "%s %s:%s" % (node.host, node.ip, str(self.config["blockchain"]["grpc_start"] + node.id))
            vp_cont = "%s %s:%s" % ("node" + str(vp_id), vp_ip, str(self.config["blockchain"]["grpc_start"] + vp_id))
            hosts_config=[nvp_cont, vp_cont]
            if node.type == "cvp":
                # 如果是cvp 需要在dynamic.toml中设置cvp及其相连vp的信息
                util.change_config(dynamic_toml_path, "cvp", {"enable": True, "node_type": "cvp", "remote": ["node" + str(vp_id)+" "+vp_ip]})
        dynamic_toml = util.load_conf(dynamic_toml_path)
        if "remote" in dynamic_toml["p2p"]["ip"]: #1.0.7及以前
            util.change_config(dynamic_toml_path, "p2p.ip.remote.hosts", hosts_config)
    #3、修改ns_dynamic.toml
        self.logger.info("3、修改ns_dynamic.toml")
        ns_dynamic = util.load_conf(ns_dynamic_path)
        if "p2p" in ns_dynamic: #1.0.8及以后分区扁平化后hosts_config挪到ns配置中
            util.change_config(ns_dynamic_path, "p2p.ip.remote.hosts", hosts_config)
        #准备nodes_config
        nodes_config = []
        n=len(self.ips)
        if node.type=="node":
            for k in range(1, len(self.ips) + 1):
                nodes_config.append({"hostname": "node" + str(k), "score": 10})
        elif node.type=="nvp" or node.type=="vp":
            n=1
            util.change_config(ns_dynamic_path, node.type, [{"hostname": node.host}])
            vp_id = self.config[node.type]["conns"][node.id - len(self.ips) - 1]
            if node.type == "nvp":
                nodes_config=[{"hostname": "node" + str(vp_id)}]
            if node.type == "cvp":
                nodes_config=[{"hostname": node.host}]
        node_type="vp" if node.type=="node" else node.type
        util.change_config(ns_dynamic_path, "self", {"type":node_type,"new":False,"n":n,"hostname":node.host})
        util.change_config(ns_dynamic_path, "nodes",nodes_config)
        # 修改日志级别
        for key in self.config["config"]["log_level"]:
            util.change_config(ns_dynamic_path, "log.module." + key, self.config["config"]["log_level"][key])
        # solo的特殊配置
        if node.type=="vp" and solo:
            util.change_config(ns_dynamic_path, "consensus.algo", "SOLO")
            util.change_config(ns_dynamic_path, "nodes",  [{"hostname": "node1", "score": 10,"type":"vp","n":1}])

        # 放置节点证书（0.0.6及以上）
        self.logger.info("4、放置节点证书（0.0.6及以上）")
        if self.config["blockchain"]["local"]["certs"]:
            self.logger.debug("node.host: %s", node.host)
            self.logger.debug(" node_dir: %s", node_dir)
            cp_certs_cmd = "cp -r " + certs + "/" + node.host + "/* " + node_dir + "/namespaces/global/certs"
            self.logger.debug("放置节点证书: %s" % cp_certs_cmd)
            os.system(cp_certs_cmd)

        # 适配多个NS的情况
        new_namespaces = self.config["blockchain"]["namespaces"][1:]
        self.logger.info("5、适配多个ns，新增ns个数:%s" % len(new_namespaces))
        dynamic_toml_path = node_dir + "/configuration/dynamic.toml"
        dynamic_toml = util.load_conf(dynamic_toml_path)
        for ns_name in new_namespaces:
            self.logger.info("为%s准备配置文件" % ns_name)
            cp_ns = "cp -r " + node_dir + "/namespaces/global " + node_dir + "/namespaces/" + ns_name
            os.system(cp_ns)
            cp_config = "cp -r " + node_dir + "/configuration/global " + node_dir + "/configuration/" + ns_name
            os.system(cp_config)
            self.logger.info("在Dynamic.toml中为节点增加%s" % ns_name)
            dynamic_toml["namespace"].append({"name": ns_name, "start": True})
        with open(dynamic_toml_path, 'w') as conf:
            toml.dump(dynamic_toml, conf)

    def switch_discover_mode(self, type="random"):
        N = len(self.nodes)
        graph = util.gen_conn_graph(list(range(N)), type=type)

        bef = []
        for i, node in enumerate(self.nodes):
            node_dir = self.config["blockchain"]["local"]["prepare_dir"] + "/" + node.host
            dynamic_toml_path = node_dir + "/configuration/dynamic.toml"
            params = util.load_conf(dynamic_toml_path)
            bef.append(copy.deepcopy(params))

            conn = []
            for id in graph[i].keys():
                conn.append(self.nodes[id])
            hosts_config=[]
            # params["p2p"]["ip"]["remote"]["hosts"] = []
            domain = str(self.config["blockchain"]["network"][node.host]["domain"])
            for tmp in conn:
                content = tmp.host + " " + self.config["blockchain"]["network"][tmp.host]["addrs"][domain]
                hosts_config.append(content)
            self.logger.debug('params["p2p"]["ip"]["remote"]["hosts"]:%s'% hosts_config)
            util.change_config(dynamic_toml_path, "p2p.ip.remote.hosts" , hosts_config)

            global_toml_path = node_dir + "/configuration/global.toml"
            if not os.path.exists(global_toml_path):
                global_toml_path = node_dir + "/configuration/system.toml"
            util.change_config(global_toml_path, "p2p.mode" ,  "discover")
        return bef

    def switch_relay_mode(self, type="random", rel=-1):
        net = {}
        for node in self.nodes:
            d = str(self.config["blockchain"]["network"][node.host]["domain"])
            if d not in net.keys():
                net[d] = []
            net[d].append(node)

        bef = []
        domains = list(net.keys())
        graph = util.gen_conn_graph(domains, type, rel)  # 生成各域之间的关系图

        # 指明key域中哪些节点能连接目标域
        for key in net.keys():
            if key not in graph:
                graph[key] = {}
            conns = graph[key]
            conns[key] = 1  # 加上自己所在的域，为非转发连接
            for d in conns.keys():
                if conns[d] == 1:
                    conns[d] = net[key]  # 非转发连接为全部节点
                else:
                    conns[d] = [random.choice(net[key])]  # 转发连接为单个节点
                    self.logger.debug("domain%s中连接domain%s的跨域节点为：%s" % (key, d, conns[d][0].host))

        ngraph = dijkstra.Graph()
        for key in net.keys():  # 以域为单位进行遍历
            nodes = net[key]  # 当前域的所有节点列表
            conns = graph[key]  # 当前域去连接的所有域
            for i, node in enumerate(nodes):
                node_dir = self.config["blockchain"]["local"]["prepare_dir"] + "/" + node.host
                dynamic_toml_path = node_dir + "/configuration/dynamic.toml"
                params = util.load_conf(dynamic_toml_path)
                bef.append(copy.deepcopy(params))

                hosts = []
                addrs = []
                self_domain = str(self.config["blockchain"]["network"][node.host]["domain"])

                for domain in net.keys():
                    if domain in conns.keys():  # 某域为需要去连接的域
                        if node in conns[domain]:  # 当前节点需要连接该域
                            for n in net[domain]:  # 对于可连接域中的每一个节点
                                content = n.host + " " + \
                                          self.config["blockchain"]["network"][n.host]["addrs"][domain]
                                hosts.append(content)
                                if node != n:
                                    ngraph.add_edge(node.host, n.host, 1)
                            addrs.append("domain" + domain + " " +
                                         self.config["blockchain"]["network"][node.host]["addrs"][domain])
                    elif domain in graph and self_domain in graph[domain]:  # 某域需要连接当前域的节点
                        # 添加某域的可连接节点到当前节点的hosts中
                        for n in graph[domain][self_domain]:
                            content = n.host + " " + self.config["blockchain"]["network"][n.host]["addrs"][self_domain]
                            hosts.append(content)
                            ngraph.add_edge(node.host, n.host, 1)
                        # 添加当前节点在某域的addrs
                        addrs.append(
                            "domain" + domain + " " + self.config["blockchain"]["network"][node.host]["addrs"][domain])


                self.logger.debug('params["p2p"]["ip"]["remote"]["hosts"] %s'%hosts)
                self.logger.debug('params["p2p"]["ip"]["self"]["addrs"]%s'%addrs)
                util.change_config(dynamic_toml_path, "p2p.ip.remote.hosts", hosts)
                util.change_config(dynamic_toml_path, "p2p.ip.self.addrs", addrs)


                global_toml_path = node_dir + "/configuration/global.toml"
                if not os.path.exists(global_toml_path):
                    global_toml_path = node_dir + "/configuration/system.toml"
                util.change_config(global_toml_path, "p2p.mode", "relay")
        return bef, ngraph

    def check_network_status(self, graph, stop=[]):
        for node in self.nodes:
            if node in stop:
                continue
            conns = node.ipc_topograph()
            for key in conns.keys():
                self.logger.debug(key)
                tmp = list(graph.get_adjacent_nodes(key))
                tmp.sort()
                conns[key].sort()
                self.logger.debug(tmp)
                self.logger.debug(conns[key])
                assert tmp == conns[key]

            dij = dijkstra.DijkstraSPF(graph, node.host)
            for n in self.nodes:
                if n != node:
                    try:
                        tmp = dij.get_path(n.host)
                        self.logger.debug(tmp)
                        paths = node.ipc_path(n.host)
                        self.logger.debug(paths)

                        flag = False
                        for path in paths:
                            if tmp == path:
                                flag = True
                                break
                        assert flag
                    except KeyError:
                        paths = node.ipc_path(n.host)
                        assert paths is None


if __name__ == '__main__':
    init_log()
    config = util.load_global_conf("conf/64_195.toml")
    flato = Flato(config)
    flato.prepare_nodes_locally()
