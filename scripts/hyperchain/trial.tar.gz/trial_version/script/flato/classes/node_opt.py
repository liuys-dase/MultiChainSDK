# coding=UTF-8
from obj.node import Node
import datetime


def getTime():
    return datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S')

class ssh_opt:
    def __init__(self, configs):
        self.config = configs
        self.ips = self.config["blockchain"]["server"]["ips"]
        self.nodes = []

        for i, ip in enumerate(self.ips):
            user_name = self.config["blockchain"]["server"]["user_name"][i]
            password = self.config["blockchain"]["server"]["password"][i]
            node_id = len(self.nodes) + 1
            remote_dir = self.config["remote_workspace"] + self.config["blockchain"]["server"]["remote_dir"] + str(node_id)
            self.nodes.append(Node(ip=ip, id=node_id, remote_dir=remote_dir, username=user_name, password=password))


    def reboot(self,idx):
        pass


    def check_ip(self,ip):
        pass

    def back_up(self,src,dec):
        pass

    def exec_cmd(self,idx,cmd):
        node = self.nodes[idx]
        node.client.exec_cmd(cmd)




if __name__ == '__main__':
    # 启动节点
    ssh = ssh_opt("")
    ssh.exec_cmd(0,"sh /home/hyperchain/start_ns_wd.sh")
    ssh.exec_cmd(0,"sudo reboot")
    ssh.exec_cmd(0,"cp -r ")