import threading
import logging.config
import os
import logging.handlers
import colorlog
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
log_path = os.path.join(BASE_DIR, 'log','logging.conf')  # 存放log文件的路径

def get_frigateDynamic_abs_path():
    pass

def init_log(config_path=log_path):
    logging.config.fileConfig(config_path)
    logger = logging.getLogger("frigateDynamic.log")
    # 配置文件里 在源码里没看到可以通过配置文件自定义控制台颜色 所以只能在加载完成后改属性
    # The available color names are black, red, green, yellow, blue, purple, cyan and white.
    logging.root.handlers[0].formatter.log_colors={'DEBUG': 'black', 'INFO': 'green', 'WARNING': 'yellow', 'ERROR': 'red', 'CRITICAL': 'purple'}
    return logger


if __name__ == '__main__':
    logger=init_log()
    logger.debug("dddd")