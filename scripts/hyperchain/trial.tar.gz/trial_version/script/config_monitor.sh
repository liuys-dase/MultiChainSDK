#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh

rootdir="$(pwd)"

cd docker/baas-go/monitor/conf || exit 0

replace_line_in_toml cfg.toml etcd.host "[\"http://etcd:2379\"]" --no-quoto

replace_line_in_toml cfg.toml grpc.port "$(get_properity 'monitor.grpc.port')" --no-quoto

replace_line_in_toml cfg.toml grpc.host "$(get_properity 'monitor.grpc.host')" --quoto

replace_line_in_toml cfg.toml http.port "$(get_properity 'monitor.http.port')" --no-quoto

replace_line_in_toml cfg.toml http.host "$(get_properity 'monitor.http.host')" --quoto

replace_line_in_toml cfg.toml email.from "$(get_properity 'monitor.email.from')" --quoto

