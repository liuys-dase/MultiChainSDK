#!/usr/bin/env bash

set -e

# shellcheck disable=SC1091
source script/function/function.sh


# 读取模板
docker_compose_production=$(cat ./docker/baas-go/docker-compose.yaml)

# 参数替换
# chainctl
docker_compose_production=$(replace_bracket "${docker_compose_production}" CHAINCTL_HTTP_PORT "$(get_properity 'chainctl.http.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" CHAINCTL_GRPC_PORT "$(get_properity 'chainctl.grpc.port')")

# core
docker_compose_production=$(replace_bracket "${docker_compose_production}" CORE_HTTP_PORT "$(get_properity 'core.http.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" CORE_GRPC_PORT "$(get_properity 'core.grpc.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" CORE_WS_PORT "$(get_properity 'core.websocket.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" LICENSE_PORT "$(get_properity 'core.license.verifier_port')")

# dbproxy
docker_compose_production=$(replace_bracket "${docker_compose_production}" DBPROXY_HTTP_PORT "$(get_properity 'dbproxy.http.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" DBPROXY_GRPC_PORT "$(get_properity 'dbproxy.grpc.port')")

# docset
docker_compose_production=$(replace_bracket "${docker_compose_production}" DOCSET_HTTP_PORT "$(get_properity 'docset.http.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" DOCSET_GRPC_PORT "$(get_properity 'docset.grpc.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" DOCSET_GIN_PORT "$(get_properity 'docset.gin.port')")

# gateway
docker_compose_production=$(replace_bracket "${docker_compose_production}" GATEWAY_HTTP_PORT "$(get_properity 'gateway.http.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" GATEWAY_GRPC_PORT "$(get_properity 'gateway.grpc.port')")

# logger
docker_compose_production=$(replace_bracket "${docker_compose_production}" LOGGER_HTTP_PORT "$(get_properity 'logger.http.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" LOGGER_GRPC_PORT "$(get_properity 'logger.grpc.port')")

# monitor
docker_compose_production=$(replace_bracket "${docker_compose_production}" MONITOR_HTTP_PORT "$(get_properity 'monitor.http.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" MONITOR_GRPC_PORT "$(get_properity 'monitor.grpc.port')")

# hostagent
docker_compose_production=$(replace_bracket "${docker_compose_production}" HOSTAGENT_HTTP_PORT "$(get_properity 'hostagent.http.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" HOSTAGENT_GRPC_PORT "$(get_properity 'hostagent.grpc.port')")

docker_compose_production=$(replace_bracket "${docker_compose_production}" HOSTAGENT_METRICS_PORT "$(get_properity 'hostagent.metrics.port')")

# 镜像替换
docker_compose_production=$(replace_bracket "${docker_compose_production}" BAAS_IMAGE "$(getImage image_version baas-go)")

# 生成最终运行文件
echo "${docker_compose_production}" > ./docker/baas-go/docker-compose-production.yaml

docker-compose -f ./docker/baas-go/docker-compose-production.yaml up -d

