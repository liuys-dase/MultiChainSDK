#!/usr/bin/env bash

# shellcheck disable=SC1091
source script/function/function.sh

for file in docker/baas-go/*; do
  {
    if [ -d "$file" ]; then
      server="${file##*/}"
      rm -rf docker/baas-go/"$server"/*
      print_blue 清理"$server"配置成功!
    fi
  } 
done
rm docker/baas-go/docker-compose-production.yaml
wait
print_green 清理完成!
